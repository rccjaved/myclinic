<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* C:\xampp\htdocs\myclinic\themes/myclinic/partials/components/specialtiesViewAll-ar.htm */
class __TwigTemplate_25ff14c66aa0efdec24986793b84f3a6 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield "<section class=\"section-py-100 pb-0\">
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-12 text-center\">
                <h1 class=\"py-60 pt-0\">حدد موقعك</h1>
            </div>
        </div>
        <div class=\"row btn-city\">
            <div class=\"col-12 text-center\">
                <div class=\"btn-mc-city-group revers\">
                    ";
        // line 11
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["locations"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["location"]) {
            // line 12
            yield "                    ";
            if ((Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["location"], "id", [], "any", false, false, true, 12) == 1)) {
                // line 13
                yield "                    <a target=\"";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["location"], "id", [], "any", false, false, true, 13), 13, $this->source), "html", null, true);
                yield "\" class=\"btn-mc-city showLocation active\">";
                yield $this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["location"], "title_ar", [], "any", false, false, true, 13), 13, $this->source);
                yield "</a>
                    ";
            } else {
                // line 15
                yield "                    <a target=\"";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["location"], "id", [], "any", false, false, true, 15), 15, $this->source), "html", null, true);
                yield "\" class=\"btn-mc-city showLocation\">";
                yield $this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["location"], "title_ar", [], "any", false, false, true, 15), 15, $this->source);
                yield "</a>
                    ";
            }
            // line 17
            yield "                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['location'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 18
        yield "                </div>
            </div>
        </div>

        <div class=\"row mt-4\">
            <div class=\"col-12\">
                <div class=\"home-demo\">
                    <div class=\"owl-carousel owl-theme\">
                        <a class=\"special-letter showSpecial\" target=\"28\">ي</a>
                        <a class=\"special-letter showSpecial\" target=\"27\">و</a>
                        <a class=\"special-letter showSpecial\" target=\"26\">هـ</a>
                        <a class=\"special-letter showSpecial\" target=\"25\">ن</a>
                        <a class=\"special-letter showSpecial\" target=\"24\">م</a>
                        <a class=\"special-letter showSpecial\" target=\"23\">ل</a>
                        <a class=\"special-letter showSpecial\" target=\"22\">ك</a>
                        <a class=\"special-letter showSpecial\" target=\"21\">ق</a>
                        <a class=\"special-letter showSpecial\" target=\"20\">ف</a>
                        <a class=\"special-letter showSpecial\" target=\"19\">غ</a>
                        <a class=\"special-letter showSpecial\" target=\"18\">ع</a>
                        <a class=\"special-letter showSpecial\" target=\"17\">ظ</a>
                        <a class=\"special-letter showSpecial\" target=\"16\">ط</a>
                        <a class=\"special-letter showSpecial\" target=\"15\">ض</a>
                        <a class=\"special-letter showSpecial\" target=\"14\">ص</a>
                        <a class=\"special-letter showSpecial\" target=\"13\">ش</a>
                        <a class=\"special-letter showSpecial\" target=\"12\">س</a>
                        <a class=\"special-letter showSpecial\" target=\"11\">ز</a>
                        <a class=\"special-letter showSpecial\" target=\"10\">ر</a>
                        <a class=\"special-letter showSpecial\" target=\"9\">ذ</a>
                        <a class=\"special-letter showSpecial\" target=\"8\">د</a>
                        <a class=\"special-letter showSpecial\" target=\"7\">خ</a>
                        <a class=\"special-letter showSpecial\" target=\"6\">ح</a>
                        <a class=\"special-letter showSpecial\" target=\"5\">ج</a>
                        <a class=\"special-letter showSpecial\" target=\"4\">ث</a>
                        <a class=\"special-letter showSpecial\" target=\"3\">ت</a>
                        <a class=\"special-letter showSpecial\" target=\"2\">ب</a>
                        <a class=\"special-letter showSpecial\" target=\"1\">أ</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<section>
    <div class=\"container\">
        <div class=\"row section-py-100\">
            <div class=\"col-12\">

                <div class=\"row g-3 g-sm-4\" id=\"specialtyCard\">

                    ";
        // line 69
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["specialties"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 70
            yield "                    <div class=\"col-12 col-md-6 col-lg-4 col-xl-3 mc-specl\">
                        <div class=\"speciality-box\">
                            <a href=\"/ar/specialty-detail/";
            // line 72
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "slug", [], "any", false, false, true, 72), 72, $this->source), "html", null, true);
            yield "/1\"> <img src=\"";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "specialty_image", [], "any", false, false, true, 72), "path", [], "any", false, false, true, 72), 72, $this->source), "html", null, true);
            yield "\"
                                    class=\"img-fluid\" alt=\"\">
                                <button class=\"btn btn-light btn-specilty\">";
            // line 74
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "name_ar", [], "any", false, false, true, 74), 74, $this->source), "html", null, true);
            yield "</button>
                            </a>
                        </div>
                    </div>

                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['item'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 80
        yield "

                </div>
            </div>
        </div>
    </div>
</section>

";
        // line 88
        $this->env->getExtension(\Cms\Twig\Extension::class)->yieldBlock('scripts'        , function() use ($context, $blocks, $macros) {
        // line 89
        yield "

<script>
    document.addEventListener('DOMContentLoaded', function () {
        function setCookie(name, value, days) {
            var expires = \"\";
            if (days) {
                var date = new Date();
                date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
                expires = \"; expires=\" + date.toUTCString();
            }
            document.cookie = name + \"=\" + (value || \"\") + expires + \"; path=/\";
        }

        function getCookie(name) {
            var nameEQ = name + \"=\";
            var ca = document.cookie.split(';');
            for (var i = 0; i < ca.length; i++) {
                var c = ca[i];
                while (c.charAt(0) == ' ') c = c.substring(1, c.length);
                if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length, c.length);
            }
            return null;
        }

        function eraseCookie(name) {
            document.cookie = name + '=; Max-Age=-99999999;';
        }

        var locationCookie = getCookie('userLocation');

        if (!locationCookie) {
            if (navigator.geolocation) {

                navigator.geolocation.getCurrentPosition(function (position) {
                    var latitude = position.coords.latitude;
                    var longitude = position.coords.longitude;
                    // var latitude = '21.5756';
                    // var longitude = '39.2080'

                    \$.ajax({
                        url: '/get-locations?longitude=' + longitude + '&latitude=' + latitude,
                        type: 'GET',
                        dataType: 'json',
                        success: function (data) {
                            \$('.btn-mc-city-group a').removeClass('active');
                            \$('.btn-mc-city-group a[target=\"' + data.location + '\"]').click()
                        },
                        error: function (jqXHR, textStatus, errorThrown) {
                            // Handle errors
                            console.error('API request failed:', textStatus, errorThrown);
                        }
                    });
                });
            } else {
                alert('Geolocation is not supported by this browser.');
            }
        }
    });
</script>


<script>
    var activeLocation = null;

    \$('.btn-mc-city-group').on('click', 'a', function () {
        // Remove the 'active' class from all buttons and add it to the clicked button
        \$('.btn-mc-city-group a.active').removeClass('active');
        \$(this).addClass('active');

        // Get the target attribute value of the clicked button (locationId)
        var locationId = \$(this).attr('target');

        // Make an AJAX request to fetch specialties for the selected location
        \$.ajax({
            url: '/location-specialties/' + locationId,
            type: 'GET',
            dataType: 'json',
            success: function (data) {
                // Get the container for specialties
                var specialtiesContainer = \$('#specialtyCard');

                // Clear the existing content
                specialtiesContainer.empty();

                // Check if there are specialties in the response
                if (data.specialties.length > 0) {
                    // Iterate through specialties and append them to the container
                    data.specialties.forEach(function (item) {
                        var specialtyHtml = `
                        <div class=\"col-12 col-md-6 col-lg-4 col-xl-3 mc-specl\" style=\"display: block;\">
                        <div class=\"speciality-box\">
                            <a href=\"/ar/specialty-detail/\${item.slug}/\${locationId}\"> <img src=\"\${item.image_path}\"
                                    class=\"img-fluid\" alt=\"\">
                                <button class=\"btn btn-light btn-specilty\">\${item.name_ar}</button>
                            </a>
                            </div>
                        </div>
                    `;
                        specialtiesContainer.append(specialtyHtml);
                    });
                } else {
                    // Handle the case when there are no specialties
                    specialtiesContainer.html('<p>No specialties available for this location.</p>');
                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                // Handle errors
                console.error('API request failed:', textStatus, errorThrown);
            }
        });

        activeLocation = \$(this).attr('target');
        \$('.home-demo a.active').removeClass('active');


    });


    \$('.home-demo').on('click', 'a', function () {

        // Get the target attribute value of the clicked button (locationId)
        var alphabet = \$(this).attr('target');
        var activeLocationValue = activeLocation ? activeLocation : 1;

        \$.ajax({
            url: '/location-specialties/' + activeLocationValue + '/alphabet/ar/' + alphabet,
            type: 'GET',
            dataType: 'json',
            success: function (data) {
                // Get the container for specialties
                var specialtiesContainer = \$('#specialtyCard');

                // Clear the existing content
                specialtiesContainer.empty();

                // Check if there are specialties in the response
                if (data.specialties.length > 0) {
                    // Iterate through specialties and append them to the container
                    data.specialties.forEach(function (item) {
                        var specialtyHtml = `
                        <div class=\"col-12 col-md-6 col-lg-4 col-xl-3 mc-specl\" style=\"display: block;\">
                        <div class=\"speciality-box\">
                            <a href=\"/ar/specialty-detail/\${item.slug}/\${activeLocation}\"> <img src=\"\${item.image_path}\"
                                    class=\"img-fluid\" alt=\"\">
                                <button class=\"btn btn-light btn-specilty\">\${item.name_ar}</button>
                            </a>
                            </div>
                        </div>
                    `;
                        specialtiesContainer.append(specialtyHtml);
                    });
                } else {
                    // Handle the case when there are no specialties
                    specialtiesContainer.html('<p>No specialties available for this location.</p>');
                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                // Handle errors
                console.error('API request failed:', textStatus, errorThrown);
            }
        });

    });


</script>

<script>
    var owl = \$('.owl-carousel');
    owl.owlCarousel({
        loop: false,
        nav: false,
        rtl: true,
        margin: 10,
        responsive: {
            0: {
                items: 7
            },
            600: {
                items: 12
            },
            960: {
                items: 16
            },
            1200: {
                items: 20
            },
            1600: {
                items: 24
            },
            1920: {
                items: 26
            }
        }
    });
    owl.on('mousewheel', '.owl-stage', function (e) {
        if (e.deltaY > 0) {
            owl.trigger('next.owl');
        } else {
            owl.trigger('prev.owl');
        }
        e.preventDefault();
    });

    \$(function () {
        if (window.matchMedia(\"(max-width: 700px)\").matches) {
            \$(\".mc-specl\").slice(0, 5).show();
            \$(\".mc-specl\").slice(0, 5).show();
            \$(\".mc-specl-2\").slice(0, 5).show();
            \$(\".mc-specl-3\").slice(0, 5).show();
            \$(\".mc-specl-4\").slice(0, 5).show();
            \$(\".mc-specl-5\").slice(0, 5).show();
            \$(\".mc-specl-6\").slice(0, 5).show();
            \$(\".mc-specl-7\").slice(0, 5).show();
            \$(\".mc-specl-8\").slice(0, 5).show();
            \$(\".mc-specl-9\").slice(0, 5).show();
            \$(\".mc-specl-10\").slice(0, 5).show();
            \$(\".mc-specl-11\").slice(0, 5).show();
            \$(\".mc-specl-12\").slice(0, 5).show();
            \$(\".mc-specl-13\").slice(0, 5).show();
            \$(\".mc-specl-14\").slice(0, 5).show();
            \$(\".mc-specl-15\").slice(0, 5).show();
            \$(\".mc-specl-16\").slice(0, 5).show();
            \$(\".mc-specl-17\").slice(0, 5).show();
            \$(\".mc-specl-18\").slice(0, 5).show();
            \$(\".mc-specl-19\").slice(0, 5).show();
            \$(\".mc-specl-20\").slice(0, 5).show();
            \$(\".mc-specl-21\").slice(0, 5).show();
            \$(\".mc-specl-22\").slice(0, 5).show();
            \$(\".mc-specl-23\").slice(0, 5).show();
            \$(\".mc-specl-24\").slice(0, 5).show();
            \$(\".mc-specl-25\").slice(0, 5).show();
            \$(\".mc-specl-26\").slice(0, 5).show();
        } else {
            \$(\".mc-specl\").slice(0, 30).show();
            \$(\".mc-specl-2\").slice(0, 30).show();
            \$(\".mc-specl-3\").slice(0, 30).show();
            \$(\".mc-specl-4\").slice(0, 30).show();
            \$(\".mc-specl-5\").slice(0, 30).show();
            \$(\".mc-specl-6\").slice(0, 30).show();
            \$(\".mc-specl-7\").slice(0, 30).show();
            \$(\".mc-specl-8\").slice(0, 30).show();
            \$(\".mc-specl-9\").slice(0, 30).show();
            \$(\".mc-specl-10\").slice(0, 30).show();
            \$(\".mc-specl-11\").slice(0, 30).show();
            \$(\".mc-specl-12\").slice(0, 30).show();
            \$(\".mc-specl-13\").slice(0, 30).show();
            \$(\".mc-specl-14\").slice(0, 30).show();
            \$(\".mc-specl-15\").slice(0, 30).show();
            \$(\".mc-specl-16\").slice(0, 30).show();
            \$(\".mc-specl-17\").slice(0, 30).show();
            \$(\".mc-specl-18\").slice(0, 30).show();
            \$(\".mc-specl-19\").slice(0, 30).show();
            \$(\".mc-specl-20\").slice(0, 30).show();
            \$(\".mc-specl-21\").slice(0, 30).show();
            \$(\".mc-specl-22\").slice(0, 30).show();
            \$(\".mc-specl-23\").slice(0, 30).show();
            \$(\".mc-specl-24\").slice(0, 30).show();
            \$(\".mc-specl-25\").slice(0, 30).show();
            \$(\".mc-specl-26\").slice(0, 30).show();
        }

        // \$(\"body\").on('click touchstart', '.btn-view-all-specl', function (e) {
        //     e.preventDefault();
        //     \$(\".mc-specl:hidden\").slice(0, 3).slideDown();
        //     if (\$(\".mc-specl:hidden\").length == 0) {
        //         \$(\".load-more\").css('visibility', 'hidden');
        //     }

        // });
    });

</script>

";
        // line 88
        return; yield '';}, true        );
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "C:\\xampp\\htdocs\\myclinic\\themes/myclinic/partials/components/specialtiesViewAll-ar.htm";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  454 => 88,  177 => 89,  175 => 88,  165 => 80,  153 => 74,  146 => 72,  142 => 70,  138 => 69,  85 => 18,  79 => 17,  71 => 15,  63 => 13,  60 => 12,  56 => 11,  44 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "C:\\xampp\\htdocs\\myclinic\\themes/myclinic/partials/components/specialtiesViewAll-ar.htm", "");
    }
    
    public function checkSecurity()
    {
        static $tags = ["for" => 11, "if" => 12, "put" => 88];
        static $filters = ["escape" => 13, "raw" => 13];
        static $functions = [];

        try {
            $this->sandbox->checkSecurity(
                ['for', 'if', 'put'],
                ['escape', 'raw'],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
