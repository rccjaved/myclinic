<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* C:\xampp\htdocs\myclinic\themes/myclinic/partials/components/testimonial-ar.htm */
class __TwigTemplate_188439322f37635e72ddee3442d021eb extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield "<style>
    .testimonial {
        width: 100%;
        /* height: 100vh; */
        display: flex;
        justify-content: center;
        align-items: center;
        /* background-color: #3d5a80; */
        color: #3d5a80;
    }

    .testimonial-slide {
        padding: 46px 20px;
    }

    .testimonial_box-top {
        /* background: url(\"assets/imgs/testimonial-bg.png\"); */
        background-repeat: no-repeat;
        background-size: cover;
        /* background-color: #003868; */
        padding: 60px;
        padding-top: 0px;
        /* border-radius: 15px; */
        display: flex;
        justify-content: center;
        align-items: center;
        flex-direction: column;
        text-align: center;
        /* box-shadow: 5px 5px 20px rgba(152, 193, 217, 0.493); */
    }

    @media only screen and (max-width: 991px) {}

    .testimonial_box-icon {
        padding: 10px 0;
    }

    .testimonial_box-icon i {
        font-size: 25px;
        color: #14213d;
    }

    .slick-next .slick-next-icon,
    .slick-next .slick-prev-icon,
    .slick-prev .slick-next-icon,
    .slick-prev .slick-prev-icon {
        display: block;
        color: #FFF;
        opacity: 1;
        font-size: 24px;
        line-height: 1;
        /* content: \"\\f054\"; */
        font-family: FontAwesome;
    }

    .slick-prev .slick-prev-icon::before {
        content: \"\\f053\";
    }

    .slick-next .slick-next-icon::before {
        content: \"\\f054\";
    }

    .testimonial_box-text {
        padding: 10px 0;
    }

    .testimonial_box-text p {
        color: #003868;
        font-size: 14px;
        line-height: 20px;
        margin-bottom: 0;
    }

    .testimonial_box-img {
        padding: 20px 0 10px;
        display: flex;
        justify-content: center;
    }

    .testimonial_box-img img {
        width: 70px;
        height: 70px;
        /* border-radius: 50px; */
        border: 2px solid #e5e5e5;
    }

    .testimonial_box-name {
        padding-top: 10px;
    }

    .testimonial_box-name h4 {
        font-size: 20px;
        line-height: 25px;
        color: #003868;
        margin-bottom: 0;
    }

    .testimonial_box-job p {
        color: #293241;
        font-size: 14px;
        text-transform: uppercase;
        letter-spacing: 3px;
        line-height: 20px;
        font-weight: 300;
        margin-bottom: 0;
    }

    .slick-autoplay-toggle-button {
        display: none;
    }

    .testimonial-slider .slick-list {
        margin: 0px 20px !important;
    }

    .slick-dots {
        direction: rtl;
        /* Set the direction to right-to-left */
    }
</style>
<section class=\"section-bg-2 section-py-100\">
    <div class=\"testimonial\">
        <div class=\"container\">
            <div class=\"row\">
                <div class=\"col-12 text-center\">
                    <h1>";
        // line 127
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["sectionHeading"] ?? null), "name_ar", [], "any", false, false, true, 127), 127, $this->source), "html", null, true);
        yield "</h1>
                </div>
            </div>
            <div class=\"testimonial__inner\">
                <div class=\"testimonial-slider\">

                    ";
        // line 133
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["testimonials"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 134
            yield "

                    <div class=\"testimonial-slide\">
                        <div class=\"testimonial_box\">
                            <div class=\"testimonial_box-inner\">
                                <div class=\"testimonial_box-top\">

                                    <div class=\"testimonial_box-text\">
                                        <p>";
            // line 142
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "testimonial_ar", [], "any", false, false, true, 142), 142, $this->source), "html", null, true);
            yield "</p>
                                    </div>
                                    <div class=\"testimonial_box-name\">
                                        <h4>";
            // line 145
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "name_ar", [], "any", false, false, true, 145), 145, $this->source), "html", null, true);
            yield "</h4>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>

                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['item'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 154
        yield "                </div>
            </div>
        </div>
    </div>
</section>
";
        // line 159
        $this->env->getExtension(\Cms\Twig\Extension::class)->yieldBlock('scripts'        , function() use ($context, $blocks, $macros) {
        // line 160
        yield "
<script>
    \$(document).ready(function () {
        \$('.testimonial-slider').slick({
            autoplay: true,
            autoplaySpeed: 1000,
            speed: 600,
            draggable: true,
            infinite: true,
            slidesToShow: 3,
            slidesToScroll: 1,
            arrows: true,
            dots: true,
            responsive: [
                {
                    breakpoint: 1680,
                    settings: {
                        slidesToShow: 2,
                        slidesToScroll: 1,
                    }
                },
                {
                    breakpoint: 575,
                    settings: {
                        slidesToShow: 1,
                        slidesToScroll: 1,
                    }
                }
            ]
        });
    });
</script>
";
        // line 159
        return; yield '';}, true        );
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "C:\\xampp\\htdocs\\myclinic\\themes/myclinic/partials/components/testimonial-ar.htm";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  259 => 159,  225 => 160,  223 => 159,  216 => 154,  201 => 145,  195 => 142,  185 => 134,  181 => 133,  172 => 127,  44 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "C:\\xampp\\htdocs\\myclinic\\themes/myclinic/partials/components/testimonial-ar.htm", "");
    }
    
    public function checkSecurity()
    {
        static $tags = ["for" => 133, "put" => 159];
        static $filters = ["escape" => 127];
        static $functions = [];

        try {
            $this->sandbox->checkSecurity(
                ['for', 'put'],
                ['escape'],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
