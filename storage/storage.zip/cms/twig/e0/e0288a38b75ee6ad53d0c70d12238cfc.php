<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* C:\xampp\htdocs\myclinic\themes/myclinic/pages/location-search-specialty-detail.htm */
class __TwigTemplate_c124d7b78dc51cd49e11c4bff5e1094e extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield "<!-- ======= BANNER START ======= -->
<section class=\"section-bg\">
    <div class=\"container-fluid\">
        <div class=\"row align-items-center\">
            <div class=\"col-12 col-sm-6 text-center text-sm-start px-0\">
                <div class=\"mc-block\">
                    <h1>";
        // line 7
        yield $this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["specialty"] ?? null), "name", [], "any", false, false, true, 7), 7, $this->source);
        yield "</h1>
                    <p>";
        // line 8
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["specialty"] ?? null), "tag_line", [], "any", false, false, true, 8), 8, $this->source), "html", null, true);
        yield "</p>
                </div>
            </div>
            <div class=\"col-12 col-sm-6 px-0\">
                <div class=\"position-relative search-doctor-list\">
                    <img src=\"";
        // line 13
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["specialty"] ?? null), "specialty_banner_image", [], "any", false, false, true, 13), "path", [], "any", false, false, true, 13), 13, $this->source), "html", null, true);
        yield "\" class=\"img-fluid\" alt=\"\">
                    <form class=\"row row-cols-2 g-2 g-lg-3 dr-search-form align-items-center\" id=\"search-form\">
                        <div class=\"col-12\">
                            <label class=\"visually-hidden\" for=\"autoSizingSelect\">Preference</label>
                            <select class=\"form-select form-select-lg select-mc\" id=\"location\">
                                ";
        // line 18
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["locations"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 19
            yield "                                ";
            if ((Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 19) == Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["location"] ?? null), "id", [], "any", false, false, true, 19))) {
                // line 20
                yield "                                <option value=\"";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["location"] ?? null), "id", [], "any", false, false, true, 20), 20, $this->source), "html", null, true);
                yield "\" selected>";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["location"] ?? null), "name", [], "any", false, false, true, 20), 20, $this->source), "html", null, true);
                yield "</option>
                                ";
            } else {
                // line 22
                yield "                                <option value=";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 22), 22, $this->source), "html", null, true);
                yield ">";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "name", [], "any", false, false, true, 22), 22, $this->source), "html", null, true);
                yield "</option>
                                ";
            }
            // line 24
            yield "                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['item'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 25
        yield "                            </select>
                        </div>


                        <div class=\"col\">
                            <label class=\"visually-hidden\" for=\"autoSizingSelect\">Preference</label>
                            <select class=\"form-select form-select-lg select-mc\" id=\"specialty\">
                                <option value=\"\"> Specialty </option>
                                ";
        // line 33
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["specialties"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 34
            yield "                                ";
            if ((Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "slug", [], "any", false, false, true, 34) == Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["specialty"] ?? null), "slug", [], "any", false, false, true, 34))) {
                // line 35
                yield "                                <option value=\"";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["specialty"] ?? null), "slug", [], "any", false, false, true, 35), 35, $this->source), "html", null, true);
                yield "\" selected>";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["specialty"] ?? null), "name", [], "any", false, false, true, 35), 35, $this->source), "html", null, true);
                yield "</option>
                                ";
            } else {
                // line 37
                yield "                                <option value=";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "slug", [], "any", false, false, true, 37), 37, $this->source), "html", null, true);
                yield ">";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "name", [], "any", false, false, true, 37), 37, $this->source), "html", null, true);
                yield "</option>
                                ";
            }
            // line 39
            yield "                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['item'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 40
        yield "                            </select>
                        </div>

                        <div class=\"col\">
                            <label class=\"visually-hidden\" for=\"autoSizingSelect\">Preference</label>
                            <select class=\"form-select form-select-lg select-mc\" id=\"doctor\">
                                <option value=\"\">Doctor’s Name</option>
                                ";
        // line 47
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["optionDoctorList"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 48
            yield "                                <option value=";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 48), 48, $this->source), "html", null, true);
            yield "><span>
                                        ";
            // line 49
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "designation", [], "any", false, false, true, 49), 49, $this->source), "html", null, true);
            yield "
                                    </span>";
            // line 50
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "name", [], "any", false, false, true, 50), 50, $this->source), "html", null, true);
            yield "</option>
                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['item'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 52
        yield "                            </select>
                        </div>


                        <div class=\"col-12\">
                            <button class=\"btn btn-primary btn-mc-search mc-search mb-4 mb-sm-0 mx-auto\"><svg
                                    xmlns=\"http://www.w3.org/2000/svg\" width=\"49\" height=\"48\" viewBox=\"0 0 49 48\"
                                    fill=\"none\">
                                    <ellipse cx=\"24.2\" cy=\"23.716\" rx=\"24.2\" ry=\"23.716\" fill=\"white\" />
                                    <path
                                        d=\"M22.8362 15.7266C26.0961 15.7266 28.735 18.3655 28.735 21.6253C28.735 24.8852 26.0961 27.5241 22.8362 27.5241C19.5764 27.5241 16.9375 24.8852 16.9375 21.6253C16.9375 19.3279 18.2476 17.341 20.1663 16.3661M32.6675 31.4566L27.2225 26.0116\"
                                        stroke=\"#003868\" stroke-width=\"1.452\" stroke-miterlimit=\"10\"
                                        stroke-linecap=\"round\" stroke-linejoin=\"round\" />
                                </svg>Search</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- ======= BANNER END ======= -->


<!-- ======= OUR DOCTORS  START ======= -->
<section class=\"mt-5\">
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-12 text-center section-py-100 pt-0\">
                <h1 class=\"\">Our Doctors</h1>
            </div>
        </div>

        <div class=\"row\">
            ";
        // line 86
        if (($context["hod"] ?? null)) {
            // line 87
            yield "
            <div class=\"col-12 col-sm-6 col-xl-4 col-xxl-3\">
                <a href=\"javascript:void(0)\" onclick=\"GoLinks(event,'/doctor-detail/'+'";
            // line 89
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "id", [], "any", false, false, true, 89), 89, $this->source), "html", null, true);
            yield "')\">
                    <div class=\"doctor-card\">

                        <a href=\"/doctor-detail/";
            // line 92
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "id", [], "any", false, false, true, 92), 92, $this->source), "html", null, true);
            yield "\">
                            <div class=\"doctor-img-001 text-center\">
                                <img src=\"";
            // line 94
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "doctor_image", [], "any", false, false, true, 94), "path", [], "any", false, false, true, 94), 94, $this->source), "html", null, true);
            yield "\" class=\"img-fluid\" alt=\"\"
                                    style=\"border-radius: 50%;\">
                            </div>
                        </a>

                        <a href=\"/doctor-detail/";
            // line 99
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "id", [], "any", false, false, true, 99), 99, $this->source), "html", null, true);
            yield "\" style=\"text-decoration: none;\">
                            <h3> <span>
                                    ";
            // line 101
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "designation", [], "any", false, false, true, 101), 101, $this->source), "html", null, true);
            yield "
                                </span>";
            // line 102
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "name", [], "any", false, false, true, 102), 102, $this->source), "html", null, true);
            yield "</h3>
                        </a>

                        <div class=\"dr-specialities drspecialty-truncate my-3\"><a href=\"/doctor-detail/";
            // line 105
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "id", [], "any", false, false, true, 105), 105, $this->source), "html", null, true);
            yield "\"
                                style=\"text-decoration: none;\"
                                class=\"dr-specialities drspecialty-truncate\">";
            // line 107
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "specialty_desc", [], "any", false, false, true, 107), 107, $this->source), "html", null, true);
            yield "</a></div>


                        <div class=\"row hide\">
                            <div class=\"col-12 text-center\">
                                <p style=\"margin-bottom: 0px;\"><a href=\"/doctor-detail/";
            // line 112
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "id", [], "any", false, false, true, 112), 112, $this->source), "html", null, true);
            yield "\"
                                        style=\"text-decoration: none; color: white;\">";
            // line 113
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "highest_degree", [], "any", false, false, true, 113), 113, $this->source), "html", null, true);
            yield "</a></p>
                            </div>
                        </div>

                        <div class=\"dr-calendar my-4\">
                            ";
            // line 118
            if (((($_v0 = ($context["availableDates"] ?? null)) && is_array($_v0) || $_v0 instanceof ArrayAccess ? ($_v0[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "id", [], "any", false, false, true, 118)] ?? null) : null) && (($_v1 = ($context["bookingLinks"] ?? null)) && is_array($_v1) || $_v1 instanceof ArrayAccess ? ($_v1[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "id", [], "any", false, false, true, 118)] ?? null) : null))) {
                // line 119
                yield "                            <div class=\"dr-calendar-text text-center\">
                                <p><strong>Earliest available appointment</strong></p>
                                <p style=\"font-size: 12px;\"><strong>";
                // line 121
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, (($_v2 = ($context["availableDates"] ?? null)) && is_array($_v2) || $_v2 instanceof ArrayAccess ? ($_v2[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "id", [], "any", false, false, true, 121)] ?? null) : null), "company_name", [], "any", false, false, true, 121), 121, $this->source), "html", null, true);
                yield "</strong></p>
                            </div>
                            <div class=\"dr-calendar-flex\">
                                <a class=\"dr-cale\">";
                // line 124
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Twig\Extension\CoreExtension']->formatDate($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, (($_v3 = ($context["availableDates"] ?? null)) && is_array($_v3) || $_v3 instanceof ArrayAccess ? ($_v3[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "id", [], "any", false, false, true, 124)] ?? null) : null), "latest_date", [], "any", false, false, true, 124), 124, $this->source), "j-M-Y"), "html", null, true);
                yield "</a>
                                <a class=\"dr-cale\">";
                // line 125
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Twig\Extension\CoreExtension']->formatDate($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, (($_v4 = ($context["availableDates"] ?? null)) && is_array($_v4) || $_v4 instanceof ArrayAccess ? ($_v4[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "id", [], "any", false, false, true, 125)] ?? null) : null), "latest_time", [], "any", false, false, true, 125), 125, $this->source), "h:i A"), "html", null, true);
                yield "</a>
                                <!-- <div class=\"slots\">";
                // line 126
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, (($_v5 = ($context["availableDates"] ?? null)) && is_array($_v5) || $_v5 instanceof ArrayAccess ? ($_v5[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "id", [], "any", false, false, true, 126)] ?? null) : null), "slots_available", [], "any", false, false, true, 126), 126, $this->source), "html", null, true);
                yield " Slots</div> -->

                            </div>
                            ";
            }
            // line 130
            yield "                        </div>

                        <div class=\"d-flex justify-content-around\">
                            <div class=\"";
            // line 133
            if ( !(($_v6 = ($context["bookingLinks"] ?? null)) && is_array($_v6) || $_v6 instanceof ArrayAccess ? ($_v6[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "id", [], "any", false, false, true, 133)] ?? null) : null)) {
                yield "w-100 mt-40";
            }
            yield "\">
                                <button href=\"javascript:void(0)\"
                                    onclick=\"GoLinks(event,'/doctor-detail/'+'";
            // line 135
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "id", [], "any", false, false, true, 135), 135, $this->source), "html", null, true);
            yield "')\"
                                    class=\"btn btn-light btn-dr-card ";
            // line 136
            if ( !(($_v7 = ($context["bookingLinks"] ?? null)) && is_array($_v7) || $_v7 instanceof ArrayAccess ? ($_v7[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "id", [], "any", false, false, true, 136)] ?? null) : null)) {
                yield "w-100";
            }
            yield "\">
                                    Profile
                                </button>
                            </div>

                            ";
            // line 141
            if (($context["canBook"] ?? null)) {
                // line 142
                yield "                            <div>
                                ";
                // line 143
                if (($context["isMobile"] ?? null)) {
                    // line 144
                    yield "                                <a href=\"/contact-us\"
                                    class=\"btn btn-dr-card-2 ";
                    // line 145
                    if ( !(($_v8 = ($context["bookingLinks"] ?? null)) && is_array($_v8) || $_v8 instanceof ArrayAccess ? ($_v8[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "id", [], "any", false, false, true, 145)] ?? null) : null)) {
                        yield "mt-40";
                    }
                    yield "\">
                                    <svg width=\"28\" height=\"27\" viewBox=\"0 0 28 27\" fill=\"none\"
                                        xmlns=\"http://www.w3.org/2000/svg\">
                                        <ellipse cx=\"13.7306\" cy=\"13.7772\" rx=\"13.4181\" ry=\"13.1913\" fill=\"white\" />
                                        <path class=\"arr-cl\"
                                            d=\"M14.9238 10.2812L18.565 13.781L14.9238 17.2807M12.8722 13.781H18.463M8.36719 13.781H14.7408\"
                                            stroke=\"#003868\" stroke-width=\"2\" stroke-miterlimit=\"10\"
                                            stroke-linecap=\"round\" stroke-linejoin=\"round\" />
                                    </svg>
                                    Ask Us
                                </a>
                                ";
                } else {
                    // line 157
                    yield "                                ";
                    if ((($_v9 = ($context["bookingLinks"] ?? null)) && is_array($_v9) || $_v9 instanceof ArrayAccess ? ($_v9[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "id", [], "any", false, false, true, 157)] ?? null) : null)) {
                        // line 158
                        yield "                                <button href=\"javascript:void(0)\" onclick=\"GoLinks(event, '";
                        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed((($_v10 = ($context["bookingLinks"] ?? null)) && is_array($_v10) || $_v10 instanceof ArrayAccess ? ($_v10[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "id", [], "any", false, false, true, 158)] ?? null) : null), 158, $this->source), "html", null, true);
                        yield "')\"
                                    class=\"btn btn-dr-card-2 ";
                        // line 159
                        if ( !(($_v11 = ($context["bookingLinks"] ?? null)) && is_array($_v11) || $_v11 instanceof ArrayAccess ? ($_v11[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "id", [], "any", false, false, true, 159)] ?? null) : null)) {
                            yield "mt-40";
                        }
                        yield "\">
                                    <svg width=\"28\" height=\"27\" viewBox=\"0 0 28 27\" fill=\"none\"
                                        xmlns=\"http://www.w3.org/2000/svg\">
                                        <ellipse cx=\"13.7306\" cy=\"13.7772\" rx=\"13.4181\" ry=\"13.1913\" fill=\"white\" />
                                        <path class=\"arr-cl\"
                                            d=\"M14.9238 10.2812L18.565 13.781L14.9238 17.2807M12.8722 13.781H18.463M8.36719 13.781H14.7408\"
                                            stroke=\"#003868\" stroke-width=\"2\" stroke-miterlimit=\"10\"
                                            stroke-linecap=\"round\" stroke-linejoin=\"round\" />
                                    </svg>
                                    Book Now
                                </button>
                                ";
                    } else {
                        // line 171
                        yield "                                <a href=\"https://bamc.myclinic.com.sa:8443\"
                                     class=\"btn btn-dr-card-2 ";
                        // line 172
                        if ( !(($_v12 = ($context["bookingLinks"] ?? null)) && is_array($_v12) || $_v12 instanceof ArrayAccess ? ($_v12[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "id", [], "any", false, false, true, 172)] ?? null) : null)) {
                            yield "mt-40";
                        }
                        yield "\">
                                    <svg width=\"28\" height=\"27\" viewBox=\"0 0 28 27\" fill=\"none\"
                                        xmlns=\"http://www.w3.org/2000/svg\">
                                        <ellipse cx=\"13.7306\" cy=\"13.7772\" rx=\"13.4181\" ry=\"13.1913\" fill=\"white\" />
                                        <path class=\"arr-cl\"
                                            d=\"M14.9238 10.2812L18.565 13.781L14.9238 17.2807M12.8722 13.781H18.463M8.36719 13.781H14.7408\"
                                            stroke=\"#003868\" stroke-width=\"2\" stroke-miterlimit=\"10\"
                                            stroke-linecap=\"round\" stroke-linejoin=\"round\" />
                                    </svg>
                                    Book Now
                                </a>
                                ";
                    }
                    // line 184
                    yield "                                ";
                }
                // line 185
                yield "                            </div>
                            ";
            }
            // line 187
            yield "                        </div>

                    </div>
                </a>
            </div>
            ";
        }
        // line 193
        yield "            ";
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["doctors"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 194
            yield "            <div class=\"col-12 col-sm-6 col-xl-4 col-xxl-3\">
                <a href=\"javascript:void(0)\" onclick=\"GoLinks(event,'/doctor-detail/'+'";
            // line 195
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 195), 195, $this->source), "html", null, true);
            yield "')\">
                    <div class=\"doctor-card\">
                        <a href=\"/doctor-detail/";
            // line 197
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 197), 197, $this->source), "html", null, true);
            yield "\">
                            <div class=\"doctor-img-001 text-center\">
                                <img src=\"";
            // line 199
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "doctor_image", [], "any", false, false, true, 199), "path", [], "any", false, false, true, 199), 199, $this->source), "html", null, true);
            yield "\" class=\"img-fluid\" alt=\"\"
                                    style=\"border-radius: 50%;\">
                            </div>
                        </a>

                        <a href=\"/doctor-detail/";
            // line 204
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 204), 204, $this->source), "html", null, true);
            yield "\" style=\"text-decoration: none;\">
                            <h3><span>";
            // line 205
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "designation", [], "any", false, false, true, 205), 205, $this->source), "html", null, true);
            yield "</span> ";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "name", [], "any", false, false, true, 205), 205, $this->source), "html", null, true);
            yield "</h3>
                        </a>

                        <div class=\"dr-specialities drspecialty-truncate my-3\">
                            <a href=\"/doctor-detail/";
            // line 209
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 209), 209, $this->source), "html", null, true);
            yield "\" style=\"text-decoration: none;\"
                                class=\"dr-specialities drspecialty-truncate\">";
            // line 210
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "specialty_desc", [], "any", false, false, true, 210), 210, $this->source), "html", null, true);
            yield "</a>
                        </div>

                        <div class=\"row hide\">
                            <div class=\"col-12 text-center\">
                                <p style=\"margin-bottom: -20px;\">
                                    <a href=\"/doctor-detail/";
            // line 216
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 216), 216, $this->source), "html", null, true);
            yield "\" style=\"text-decoration: none; color: white;\">";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "highest_degree", [], "any", false, false, true, 216), 216, $this->source), "html", null, true);
            yield "</a>
                                </p><br>
                               
                            </div>
                        </div>

                        
                        <div class=\"dr-calendar my-4\">
                           
                            ";
            // line 225
            if (((($_v13 = ($context["availableDates"] ?? null)) && is_array($_v13) || $_v13 instanceof ArrayAccess ? ($_v13[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 225)] ?? null) : null) && (($_v14 = ($context["bookingLinks"] ?? null)) && is_array($_v14) || $_v14 instanceof ArrayAccess ? ($_v14[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 225)] ?? null) : null))) {
                // line 226
                yield "                            <div class=\"dr-calendar-text text-center\">
                                <p><strong>Earliest available appointment</strong></p>
                                <p style=\"font-size: 12px;\"><strong>";
                // line 228
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, (($_v15 = ($context["availableDates"] ?? null)) && is_array($_v15) || $_v15 instanceof ArrayAccess ? ($_v15[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 228)] ?? null) : null), "company_name", [], "any", false, false, true, 228), 228, $this->source), "html", null, true);
                yield "</strong></p>
                            </div>
                            
                            <div class=\"dr-calendar-flex\">
                                <a class=\"dr-cale\">";
                // line 232
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Twig\Extension\CoreExtension']->formatDate($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, (($_v16 = ($context["availableDates"] ?? null)) && is_array($_v16) || $_v16 instanceof ArrayAccess ? ($_v16[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 232)] ?? null) : null), "latest_date", [], "any", false, false, true, 232), 232, $this->source), "j-M-Y"), "html", null, true);
                yield "</a>
                                <a class=\"dr-cale\">";
                // line 233
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Twig\Extension\CoreExtension']->formatDate($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, (($_v17 = ($context["availableDates"] ?? null)) && is_array($_v17) || $_v17 instanceof ArrayAccess ? ($_v17[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 233)] ?? null) : null), "latest_time", [], "any", false, false, true, 233), 233, $this->source), "h:i A"), "html", null, true);
                yield "</a>
                                <!-- <div class=\"slots\">";
                // line 234
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, (($_v18 = ($context["availableDates"] ?? null)) && is_array($_v18) || $_v18 instanceof ArrayAccess ? ($_v18[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 234)] ?? null) : null), "slots_available", [], "any", false, false, true, 234), 234, $this->source), "html", null, true);
                yield " Slots</div> -->
                            </div>
                            ";
            }
            // line 237
            yield "                        </div>
                          

                        <div class=\"d-flex justify-content-around\">
                            <div class=\"";
            // line 241
            if ( !(($_v19 = ($context["bookingLinks"] ?? null)) && is_array($_v19) || $_v19 instanceof ArrayAccess ? ($_v19[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 241)] ?? null) : null)) {
                yield "w-100 mt-40";
            }
            yield "\">
                                <button href=\"javascript:void(0)\"
                                    onclick=\"GoLinks(event,'/doctor-detail/'+'";
            // line 243
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 243), 243, $this->source), "html", null, true);
            yield "')\"
                                    class=\"btn btn-light btn-dr-card \">
                                    Profile
                                </button>
                            </div>
                            &nbsp;
                            ";
            // line 249
            if (($context["canBook"] ?? null)) {
                // line 250
                yield "                            <div>
                                ";
                // line 251
                if (($context["isMobile"] ?? null)) {
                    // line 252
                    yield "                                
                                <a href=\"/contact-us\"
                                    class=\"btn btn-dr-card-2 ";
                    // line 254
                    if ( !(($_v20 = ($context["bookingLinks"] ?? null)) && is_array($_v20) || $_v20 instanceof ArrayAccess ? ($_v20[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 254)] ?? null) : null)) {
                        yield "mt-40";
                    }
                    yield "\">
                                    <svg width=\"28\" height=\"27\" viewBox=\"0 0 28 27\" fill=\"none\"
                                        xmlns=\"http://www.w3.org/2000/svg\">
                                        <ellipse cx=\"13.7306\" cy=\"13.7772\" rx=\"13.4181\" ry=\"13.1913\" fill=\"white\" />
                                        <path class=\"arr-cl\"
                                            d=\"M14.9238 10.2812L18.565 13.781L14.9238 17.2807M12.8722 13.781H18.463M8.36719 13.781H14.7408\"
                                            stroke=\"#003868\" stroke-width=\"2\" stroke-miterlimit=\"10\"
                                            stroke-linecap=\"round\" stroke-linejoin=\"round\" />
                                    </svg>
                                    Ask Us
                                </a>
                                ";
                } else {
                    // line 266
                    yield "                                ";
                    if ((($_v21 = ($context["bookingLinks"] ?? null)) && is_array($_v21) || $_v21 instanceof ArrayAccess ? ($_v21[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 266)] ?? null) : null)) {
                        // line 267
                        yield "                                <button href=\"javascript:void(0)\"
                                    onclick=\"GoLinks(event, '";
                        // line 268
                        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed((($_v22 = ($context["bookingLinks"] ?? null)) && is_array($_v22) || $_v22 instanceof ArrayAccess ? ($_v22[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 268)] ?? null) : null), 268, $this->source), "html", null, true);
                        yield "')\" class=\"btn btn-dr-card-2\">
                                    <svg width=\"28\" height=\"27\" viewBox=\"0 0 28 27\" fill=\"none\"
                                        xmlns=\"http://www.w3.org/2000/svg\">
                                        <ellipse cx=\"13.7306\" cy=\"13.7772\" rx=\"13.4181\" ry=\"13.1913\" fill=\"white\" />
                                        <path class=\"arr-cl\"
                                            d=\"M14.9238 10.2812L18.565 13.781L14.9238 17.2807M12.8722 13.781H18.463M8.36719 13.781H14.7408\"
                                            stroke=\"#003868\" stroke-width=\"2\" stroke-miterlimit=\"10\"
                                            stroke-linecap=\"round\" stroke-linejoin=\"round\" />
                                    </svg>
                                    Book Now
                                </button>
                                ";
                    } else {
                        // line 280
                        yield "                                <a href=\"https://bamc.myclinic.com.sa:8443\"
                                     class=\"btn btn-dr-card-2 ";
                        // line 281
                        if ( !(($_v23 = ($context["bookingLinks"] ?? null)) && is_array($_v23) || $_v23 instanceof ArrayAccess ? ($_v23[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 281)] ?? null) : null)) {
                            yield "mt-40";
                        }
                        yield "\">
                                    <svg width=\"28\" height=\"27\" viewBox=\"0 0 28 27\" fill=\"none\"
                                        xmlns=\"http://www.w3.org/2000/svg\">
                                        <ellipse cx=\"13.7306\" cy=\"13.7772\" rx=\"13.4181\" ry=\"13.1913\" fill=\"white\" />
                                        <path class=\"arr-cl\"
                                            d=\"M14.9238 10.2812L18.565 13.781L14.9238 17.2807M12.8722 13.781H18.463M8.36719 13.781H14.7408\"
                                            stroke=\"#003868\" stroke-width=\"2\" stroke-miterlimit=\"10\"
                                            stroke-linecap=\"round\" stroke-linejoin=\"round\" />
                                    </svg>
                                    Book Now
                                </a>
                                ";
                    }
                    // line 293
                    yield "                                ";
                }
                // line 294
                yield "                            </div>
                            ";
            }
            // line 296
            yield "                        </div>

                    </div>
                </a>
            </div>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['item'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 302
        yield "


        </div>

    </div>
</section>
<!-- ======= OUR DOCTORS END ======= -->

<!-- ======= DOWNLOAD OUR APP START ======= -->
";
        // line 312
        $cmsPartialParams = [];
        yield $this->env->getExtension(\Cms\Twig\Extension::class)->partialFunction("components/appDownload"        , array_merge($context, ['__cms_partial_params' => $cmsPartialParams], $cmsPartialParams)        , true        );
        // line 313
        yield "<!-- ======= DOWNLOAD OUR APP END ======= -->

<script>
    document.getElementById('search-form').addEventListener('submit', function (e) {
        e.preventDefault();  // Prevent the default form submission

        // Get the user's input
        const specialty = document.getElementById('specialty').value;
        const doctor = document.getElementById('doctor').value;
        const location = document.getElementById('location').value;



        var detailPageURL = '';

        if (specialty && location && !doctor) {
            detailPageURL = `/search-specialty/\${location}/\${specialty}`;

        } else {
            detailPageURL = (doctor) ? `/doctor-detail/\${doctor}` : (specialty) ? `/search-specialty/\${specialty}` : `/location-doctors/\${location}`
        }

        // Determine the detail page URL based on the search type

        // Redirect to the appropriate detail page
        window.location.href = detailPageURL;
    });


    \$(document).ready(function () {
        \$('#specialty').change(function () {
            var countryId = \$(this).val();
            var location = document.getElementById('location').value;
            var doctor = document.getElementById('doctor').value;

            \$.ajax({
                url: '/specialty-doctors/' + countryId + '?location=' + location,
                type: 'GET',
                dataType: 'json',
                success: function (data) {
                    var statesSelect = \$('#doctor');


                    statesSelect.empty();
                    if (data.doctors.length) {
                        statesSelect.append('<option value=\"\"> Doctor </option>');
                        \$.each(data.doctors, function (key, state) {
                            var selected = (state.id == doctor) ? ' selected' : '';

                            statesSelect.append('<option value=\"' + state.id + '\"' + selected + '>' + (state.designation ? state.designation : null) + ' ' + state.name + '</option>');
                        });
                    } else {
                        statesSelect.append('<option value=\"\"> Doctor </option>');
                    }


                },
                error: function (jqXHR, textStatus, errorThrown) {
                    // Handle errors
                    console.error('API request failed:', textStatus, errorThrown);
                }
            });

        });

        \$('#location').change(function () {
            var countryId = \$(this).val();
            var specialty = document.getElementById('specialty').value;

            \$.ajax({
                url: '/location-specialties/' + countryId,
                type: 'GET',
                dataType: 'json',
                success: function (data) {
                    var statesSelect = \$('#specialty');
                    var doctorSelect = \$('#doctor');
                    var selectedSpecialtyDoctors = null;
                    statesSelect.empty();
                    if (data.specialties.length) {
                        statesSelect.append('<option value=\"\"> Specialty </option>');
                        \$.each(data.specialties, function (key, state) {
                            var selected = (state.slug === specialty) ? ' selected' : '';
                            selectedSpecialtyDoctors = (state.slug === specialty) ? state : null;
                            statesSelect.append('<option value=\"' + state.slug + '\"' + selected + '>' + state.name + '</option>');
                        });
                        \$('#specialty').change();

                    } else {
                        statesSelect.append('<option value=\"\"> Specialty </option>');
                    }

                    if (!selectedSpecialtyDoctors) {
                        doctorSelect.empty();
                        doctorSelect.append('<option value=\"\"> Doctor </option>');
                    }


                },
                error: function (jqXHR, textStatus, errorThrown) {
                    // Handle errors
                    console.error('API request failed:', textStatus, errorThrown);
                }
            });

        });
    });
    // function GoLinks(event, value) {

    //     event.stopPropagation();
    //     window.location = value;


    // }


    function GoLinks(event, bookingLink) {
        event.preventDefault();

        // If the booking link is not found (empty), redirect to the external site
        if (!bookingLink || bookingLink === '') {
            window.location.href = 'https://bamc.myclinic.com.sa:8443';
        } else {
            window.location.href = bookingLink;
        }
    }

</script>";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "C:\\xampp\\htdocs\\myclinic\\themes/myclinic/pages/location-search-specialty-detail.htm";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  628 => 313,  625 => 312,  613 => 302,  602 => 296,  598 => 294,  595 => 293,  578 => 281,  575 => 280,  560 => 268,  557 => 267,  554 => 266,  537 => 254,  533 => 252,  531 => 251,  528 => 250,  526 => 249,  517 => 243,  510 => 241,  504 => 237,  498 => 234,  494 => 233,  490 => 232,  483 => 228,  479 => 226,  477 => 225,  463 => 216,  454 => 210,  450 => 209,  441 => 205,  437 => 204,  429 => 199,  424 => 197,  419 => 195,  416 => 194,  411 => 193,  403 => 187,  399 => 185,  396 => 184,  379 => 172,  376 => 171,  359 => 159,  354 => 158,  351 => 157,  334 => 145,  331 => 144,  329 => 143,  326 => 142,  324 => 141,  314 => 136,  310 => 135,  303 => 133,  298 => 130,  291 => 126,  287 => 125,  283 => 124,  277 => 121,  273 => 119,  271 => 118,  263 => 113,  259 => 112,  251 => 107,  246 => 105,  240 => 102,  236 => 101,  231 => 99,  223 => 94,  218 => 92,  212 => 89,  208 => 87,  206 => 86,  170 => 52,  162 => 50,  158 => 49,  153 => 48,  149 => 47,  140 => 40,  134 => 39,  126 => 37,  118 => 35,  115 => 34,  111 => 33,  101 => 25,  95 => 24,  87 => 22,  79 => 20,  76 => 19,  72 => 18,  64 => 13,  56 => 8,  52 => 7,  44 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "C:\\xampp\\htdocs\\myclinic\\themes/myclinic/pages/location-search-specialty-detail.htm", "");
    }
    
    public function checkSecurity()
    {
        static $tags = ["for" => 18, "if" => 19, "partial" => 312];
        static $filters = ["raw" => 7, "escape" => 8, "date" => 124];
        static $functions = [];

        try {
            $this->sandbox->checkSecurity(
                ['for', 'if', 'partial'],
                ['raw', 'escape', 'date'],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
