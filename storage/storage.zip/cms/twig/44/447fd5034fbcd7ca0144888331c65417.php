<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* C:\xampp\htdocs\myclinic\themes/myclinic/pages/specialty-detail.htm */
class __TwigTemplate_8dea79b1d0ec38974a680899b1db3dd1 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield "<div class=\"swiper-container\">
    <!-- Additional required wrapper -->
    <div class=\"swiper-wrapper\">
        <!-- Slider -->
        ";
        // line 5
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["sliders"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 6
            yield "        <div class=\"swiper-slide\">
            <img src=\"";
            // line 7
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "slider_image_mobile", [], "any", false, false, true, 7), "path", [], "any", false, false, true, 7), 7, $this->source), "html", null, true);
            yield "\" class=\"slidemc\" alt=\"\">
            <img src=\"";
            // line 8
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "slider_image", [], "any", false, false, true, 8), "path", [], "any", false, false, true, 8), 8, $this->source), "html", null, true);
            yield "\" class=\"slidemc slidemc-m-home\" alt=\"\">
            <div class=\"slide-text\">
                <h1 class=\"mb-3\">";
            // line 10
            yield $this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "title", [], "any", false, false, true, 10), 10, $this->source);
            yield "</h1>
                <p class=\"mb-3 mb-sm-5\">";
            // line 11
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "tag_line", [], "any", false, false, true, 11), 11, $this->source), "html", null, true);
            yield "</p>
                ";
            // line 12
            if (Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "link_value", [], "any", false, false, true, 12)) {
                // line 13
                yield "                <a href=\"";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "link_value", [], "any", false, false, true, 13), 13, $this->source), "html", null, true);
                yield "\" class=\"btn btn-primary slide-s btn-mc-01 mb-6\"><svg
                        xmlns=\"http://www.w3.org/2000/svg\" width=\"40\" height=\"40\" viewBox=\"0 0 40 40\" fill=\"none\"
                        style=\"margin-right: 20px;\">
                        <ellipse cx=\"20\" cy=\"19.6\" rx=\"20\" ry=\"19.6\" fill=\"white\" />
                        <path d=\"M21.7727 14.3984L27.2 19.5984L21.7727 24.7984M27.048 19.5984H18.7148H12\"
                            stroke=\"#003868\" stroke-width=\"2\" stroke-miterlimit=\"10\" stroke-linecap=\"round\"
                            stroke-linejoin=\"round\" />
                    </svg>";
                // line 20
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "link_name", [], "any", false, false, true, 20), 20, $this->source), "html", null, true);
                yield "</a>
                ";
            }
            // line 22
            yield "            </div>
        </div>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['item'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 25
        yield "    </div>
    <!-- If we need pagination -->
    <div class=\"swiper-pagination\"></div>

    <!-- If we need navigation buttons -->
    <div class=\"swiper-button-prev\"><span></span></div>
    <div class=\"swiper-button-next\"><span></span></div>

    <!-- Search Form -->


</div>


<section class=\"section-py-100\">
    <div class=\"container section-bg\">
        <div class=\"row align-items-center\">
            <div class=\"col-12\">
                <div class=\"mc-block\">
                    <h1>Overview</h1>
                    <p>";
        // line 45
        yield $this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["specialty"] ?? null), "description", [], "any", false, false, true, 45), 45, $this->source);
        yield "</p>
                </div>
            </div>
            <!-- <div class=\"col-12 col-lg-6 text-center\">
                <img src=\"";
        // line 49
        yield $this->extensions['Cms\Twig\Extension']->themeFilter("assets/imgs/ob-gyn-dr.png");
        yield "\" class=\"img-fluid\" alt=\"\">
            </div> -->
        </div>
    </div>
</section>

<!-- ======= OUR DOCTORS  START ======= -->
<section>
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-12 text-center section-py-100 pt-0\">
                <h1 class=\"\">Our Doctors</h1>
            </div>
        </div>

        <div class=\"row\">
            ";
        // line 65
        if (($context["hod"] ?? null)) {
            // line 66
            yield "
            <div class=\"col-12 col-sm-6 col-xl-4 col-xxl-3\">
                <a href=\"javascript:void(0)\" onclick=\"GoLinks(event,'/doctor-detail/'+'";
            // line 68
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "id", [], "any", false, false, true, 68), 68, $this->source), "html", null, true);
            yield "')\">
                    <div class=\"doctor-card\">

                        <a href=\"/doctor-detail/";
            // line 71
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "id", [], "any", false, false, true, 71), 71, $this->source), "html", null, true);
            yield "\">
                            <div class=\"doctor-img-001 text-center\">
                                <img src=\"";
            // line 73
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "doctor_image", [], "any", false, false, true, 73), "path", [], "any", false, false, true, 73), 73, $this->source), "html", null, true);
            yield "\" class=\"img-fluid\" alt=\"\"
                                    style=\"border-radius: 50%;\">
                            </div>
                        </a>

                        <a href=\"/doctor-detail/";
            // line 78
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "id", [], "any", false, false, true, 78), 78, $this->source), "html", null, true);
            yield "\" style=\"text-decoration: none;\">
                            <h3> <span>
                                    ";
            // line 80
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "designation", [], "any", false, false, true, 80), 80, $this->source), "html", null, true);
            yield "
                                </span>";
            // line 81
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "name", [], "any", false, false, true, 81), 81, $this->source), "html", null, true);
            yield "</h3>
                        </a>

                        <div class=\"dr-specialities drspecialty-truncate my-3\"><a href=\"/doctor-detail/";
            // line 84
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "id", [], "any", false, false, true, 84), 84, $this->source), "html", null, true);
            yield "\"
                                style=\"text-decoration: none;\"
                                class=\"dr-specialities drspecialty-truncate\">";
            // line 86
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "specialty_desc", [], "any", false, false, true, 86), 86, $this->source), "html", null, true);
            yield "</a></div>


                        <div class=\" row hide\">
                            <div class=\"col-12 text-center\">
                                <p style=\"margin-bottom: 0px;\"><a href=\"/doctor-detail/";
            // line 91
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "id", [], "any", false, false, true, 91), 91, $this->source), "html", null, true);
            yield "\"
                                        style=\"text-decoration: none; color: white;\">";
            // line 92
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "highest_degree", [], "any", false, false, true, 92), 92, $this->source), "html", null, true);
            yield "</a></p>
                            </div>
                        </div>

                        <div class=\"dr-calendar my-4\">
                            ";
            // line 97
            if (((($_v0 = ($context["availableDates"] ?? null)) && is_array($_v0) || $_v0 instanceof ArrayAccess ? ($_v0[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "id", [], "any", false, false, true, 97)] ?? null) : null) && (($_v1 = ($context["bookingLinks"] ?? null)) && is_array($_v1) || $_v1 instanceof ArrayAccess ? ($_v1[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "id", [], "any", false, false, true, 97)] ?? null) : null))) {
                // line 98
                yield "                            <div class=\"dr-calendar-text text-center\">
                                <p><strong>Earliest available appointment</strong></p>
                                <p style=\"font-size: 12px;\"><strong>";
                // line 100
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, (($_v2 = ($context["availableDates"] ?? null)) && is_array($_v2) || $_v2 instanceof ArrayAccess ? ($_v2[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "id", [], "any", false, false, true, 100)] ?? null) : null), "company_name", [], "any", false, false, true, 100), 100, $this->source), "html", null, true);
                yield "</strong></p>
                            </div>
                            <div class=\"dr-calendar-flex\">
                                <a class=\"dr-cale\">";
                // line 103
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Twig\Extension\CoreExtension']->formatDate($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, (($_v3 = ($context["availableDates"] ?? null)) && is_array($_v3) || $_v3 instanceof ArrayAccess ? ($_v3[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "id", [], "any", false, false, true, 103)] ?? null) : null), "latest_date", [], "any", false, false, true, 103), 103, $this->source), "j-M-Y"), "html", null, true);
                yield "</a>
                                <a class=\"dr-cale\">";
                // line 104
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Twig\Extension\CoreExtension']->formatDate($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, (($_v4 = ($context["availableDates"] ?? null)) && is_array($_v4) || $_v4 instanceof ArrayAccess ? ($_v4[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "id", [], "any", false, false, true, 104)] ?? null) : null), "latest_time", [], "any", false, false, true, 104), 104, $this->source), "h:i A"), "html", null, true);
                yield "</a>
                                <!-- <div class=\"slots\">";
                // line 105
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, (($_v5 = ($context["availableDates"] ?? null)) && is_array($_v5) || $_v5 instanceof ArrayAccess ? ($_v5[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "id", [], "any", false, false, true, 105)] ?? null) : null), "slots_available", [], "any", false, false, true, 105), 105, $this->source), "html", null, true);
                yield " Slots</div> -->

                            </div>
                            ";
            }
            // line 109
            yield "                        </div>

                        <div class=\"d-flex justify-content-around\">
                            <div class=\"";
            // line 112
            if ( !(($_v6 = ($context["bookingLinks"] ?? null)) && is_array($_v6) || $_v6 instanceof ArrayAccess ? ($_v6[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "id", [], "any", false, false, true, 112)] ?? null) : null)) {
                yield "w-100 mt-40";
            }
            yield "\">
                                <button href=\"javascript:void(0)\"
                                    onclick=\"GoLinks(event,'/doctor-detail/'+'";
            // line 114
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "id", [], "any", false, false, true, 114), 114, $this->source), "html", null, true);
            yield "')\"
                                    class=\"btn btn-light btn-dr-card ";
            // line 115
            if ( !(($_v7 = ($context["bookingLinks"] ?? null)) && is_array($_v7) || $_v7 instanceof ArrayAccess ? ($_v7[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "id", [], "any", false, false, true, 115)] ?? null) : null)) {
                yield "w-100";
            }
            yield "\">
                                    Profile
                                </button>
                            </div>

                            ";
            // line 120
            if (($context["canBook"] ?? null)) {
                // line 121
                yield "                            <div>
                                ";
                // line 122
                if (($context["isMobile"] ?? null)) {
                    // line 123
                    yield "                                <a href=\"/contact-us\"
                                    class=\"btn btn-dr-card-2 ";
                    // line 124
                    if ( !(($_v8 = ($context["bookingLinks"] ?? null)) && is_array($_v8) || $_v8 instanceof ArrayAccess ? ($_v8[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "id", [], "any", false, false, true, 124)] ?? null) : null)) {
                        yield "mt-40";
                    }
                    yield "\">
                                    <svg width=\"28\" height=\"27\" viewBox=\"0 0 28 27\" fill=\"none\"
                                        xmlns=\"http://www.w3.org/2000/svg\">
                                        <ellipse cx=\"13.7306\" cy=\"13.7772\" rx=\"13.4181\" ry=\"13.1913\" fill=\"white\" />
                                        <path class=\"arr-cl\"
                                            d=\"M14.9238 10.2812L18.565 13.781L14.9238 17.2807M12.8722 13.781H18.463M8.36719 13.781H14.7408\"
                                            stroke=\"#003868\" stroke-width=\"2\" stroke-miterlimit=\"10\"
                                            stroke-linecap=\"round\" stroke-linejoin=\"round\" />
                                    </svg>
                                    Ask Us
                                </a>
                                ";
                } else {
                    // line 136
                    yield "                                ";
                    if ((($_v9 = ($context["bookingLinks"] ?? null)) && is_array($_v9) || $_v9 instanceof ArrayAccess ? ($_v9[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "id", [], "any", false, false, true, 136)] ?? null) : null)) {
                        // line 137
                        yield "                                <button href=\"javascript:void(0)\" onclick=\"GoLinks(event, '";
                        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed((($_v10 = ($context["bookingLinks"] ?? null)) && is_array($_v10) || $_v10 instanceof ArrayAccess ? ($_v10[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "id", [], "any", false, false, true, 137)] ?? null) : null), 137, $this->source), "html", null, true);
                        yield "')\"
                                    class=\"btn btn-dr-card-2\">
                                    <svg width=\"28\" height=\"27\" viewBox=\"0 0 28 27\" fill=\"none\"
                                        xmlns=\"http://www.w3.org/2000/svg\">
                                        <ellipse cx=\"13.7306\" cy=\"13.7772\" rx=\"13.4181\" ry=\"13.1913\" fill=\"white\" />
                                        <path class=\"arr-cl\"
                                            d=\"M14.9238 10.2812L18.565 13.781L14.9238 17.2807M12.8722 13.781H18.463M8.36719 13.781H14.7408\"
                                            stroke=\"#003868\" stroke-width=\"2\" stroke-miterlimit=\"10\"
                                            stroke-linecap=\"round\" stroke-linejoin=\"round\" />
                                    </svg>
                                    Book Now
                                </button>
                                ";
                    }
                    // line 150
                    yield "                                ";
                }
                // line 151
                yield "                            </div>
                            ";
            }
            // line 153
            yield "                        </div>

                    </div>
                </a>
            </div>
            ";
        }
        // line 159
        yield "            ";
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["doctors"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 160
            yield "            <div class=\"col-12 col-sm-6 col-xl-4 col-xxl-3\">
                <a href=\"javascript:void(0)\" onclick=\"GoLinks(event,'/doctor-detail/'+'";
            // line 161
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 161), 161, $this->source), "html", null, true);
            yield "')\">
                    <div class=\"doctor-card\">
                        <a href=\"/doctor-detail/";
            // line 163
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 163), 163, $this->source), "html", null, true);
            yield "\">
                            <div class=\"doctor-img-001 text-center\">
                                <img src=\"";
            // line 165
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "doctor_image", [], "any", false, false, true, 165), "path", [], "any", false, false, true, 165), 165, $this->source), "html", null, true);
            yield "\" class=\"img-fluid\" alt=\"\"
                                    style=\"border-radius: 50%;\">
                            </div>
                        </a>

                        <a href=\"/doctor-detail/";
            // line 170
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 170), 170, $this->source), "html", null, true);
            yield "\" style=\"text-decoration: none;\">
                            <h3><span>";
            // line 171
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "designation", [], "any", false, false, true, 171), 171, $this->source), "html", null, true);
            yield "</span> ";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "name", [], "any", false, false, true, 171), 171, $this->source), "html", null, true);
            yield "</h3>
                        </a>

                        <div class=\"dr-specialities drspecialty-truncate my-3\">
                            <a href=\"/doctor-detail/";
            // line 175
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 175), 175, $this->source), "html", null, true);
            yield "\" style=\"text-decoration: none;\"
                                class=\"dr-specialities drspecialty-truncate\">";
            // line 176
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "specialty_desc", [], "any", false, false, true, 176), 176, $this->source), "html", null, true);
            yield "</a>
                        </div>

                        <div class=\"row hide\">
                            <div class=\"col-12 text-center\">
                                <p style=\"margin-bottom: 0px;\"><a href=\"/doctor-detail/";
            // line 181
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 181), 181, $this->source), "html", null, true);
            yield "\"
                                        style=\"text-decoration: none; color: white;\">";
            // line 182
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "highest_degree", [], "any", false, false, true, 182), 182, $this->source), "html", null, true);
            yield "</a></p>
                            </div>
                        </div>

                        <div class=\"dr-calendar my-4\">
                            ";
            // line 187
            if (((($_v11 = ($context["availableDates"] ?? null)) && is_array($_v11) || $_v11 instanceof ArrayAccess ? ($_v11[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 187)] ?? null) : null) && (($_v12 = ($context["bookingLinks"] ?? null)) && is_array($_v12) || $_v12 instanceof ArrayAccess ? ($_v12[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 187)] ?? null) : null))) {
                // line 188
                yield "                            <div class=\"dr-calendar-text text-center\">
                                <p><strong>Earliest available appointment</strong></p>
                                <p style=\"font-size: 12px;\"><strong>";
                // line 190
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, (($_v13 = ($context["availableDates"] ?? null)) && is_array($_v13) || $_v13 instanceof ArrayAccess ? ($_v13[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 190)] ?? null) : null), "company_name", [], "any", false, false, true, 190), 190, $this->source), "html", null, true);
                yield "</strong></p>
                            </div>
                            <div class=\"dr-calendar-flex\">
                                <a class=\"dr-cale\">";
                // line 193
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Twig\Extension\CoreExtension']->formatDate($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, (($_v14 = ($context["availableDates"] ?? null)) && is_array($_v14) || $_v14 instanceof ArrayAccess ? ($_v14[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 193)] ?? null) : null), "latest_date", [], "any", false, false, true, 193), 193, $this->source), "j-M-Y"), "html", null, true);
                yield "</a>
                                <a class=\"dr-cale\">";
                // line 194
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Twig\Extension\CoreExtension']->formatDate($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, (($_v15 = ($context["availableDates"] ?? null)) && is_array($_v15) || $_v15 instanceof ArrayAccess ? ($_v15[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 194)] ?? null) : null), "latest_time", [], "any", false, false, true, 194), 194, $this->source), "h:i A"), "html", null, true);
                yield "</a>
                                <!-- <div class=\"slots\">";
                // line 195
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, (($_v16 = ($context["availableDates"] ?? null)) && is_array($_v16) || $_v16 instanceof ArrayAccess ? ($_v16[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 195)] ?? null) : null), "slots_available", [], "any", false, false, true, 195), 195, $this->source), "html", null, true);
                yield " Slots</div> -->
                            </div>
                            ";
            }
            // line 198
            yield "                        </div>

                        <div class=\"d-flex justify-content-around\">
                            <div class=\"";
            // line 201
            if ( !(($_v17 = ($context["bookingLinks"] ?? null)) && is_array($_v17) || $_v17 instanceof ArrayAccess ? ($_v17[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 201)] ?? null) : null)) {
                yield "w-100 mt-40";
            }
            yield "\">
                                <button href=\"javascript:void(0)\"
                                    onclick=\"GoLinks(event,'/doctor-detail/'+'";
            // line 203
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 203), 203, $this->source), "html", null, true);
            yield "')\"
                                    class=\"btn btn-light btn-dr-card\">
                                    Profile
                                </button>
                            </div>

                            ";
            // line 209
            if (($context["canBook"] ?? null)) {
                // line 210
                yield "                            <div>
                                ";
                // line 211
                if (($context["isMobile"] ?? null)) {
                    // line 212
                    yield "                                <a href=\"/contact-us\"
                                    class=\"btn btn-dr-card-2 ";
                    // line 213
                    if ( !(($_v18 = ($context["bookingLinks"] ?? null)) && is_array($_v18) || $_v18 instanceof ArrayAccess ? ($_v18[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 213)] ?? null) : null)) {
                        yield "mt-40";
                    }
                    yield "\">
                                    <svg width=\"28\" height=\"27\" viewBox=\"0 0 28 27\" fill=\"none\"
                                        xmlns=\"http://www.w3.org/2000/svg\">
                                        <ellipse cx=\"13.7306\" cy=\"13.7772\" rx=\"13.4181\" ry=\"13.1913\" fill=\"white\" />
                                        <path class=\"arr-cl\"
                                            d=\"M14.9238 10.2812L18.565 13.781L14.9238 17.2807M12.8722 13.781H18.463M8.36719 13.781H14.7408\"
                                            stroke=\"#003868\" stroke-width=\"2\" stroke-miterlimit=\"10\"
                                            stroke-linecap=\"round\" stroke-linejoin=\"round\" />
                                    </svg>
                                    Ask Us
                                </a>
                                ";
                } else {
                    // line 225
                    yield "                                ";
                    if ((($_v19 = ($context["bookingLinks"] ?? null)) && is_array($_v19) || $_v19 instanceof ArrayAccess ? ($_v19[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 225)] ?? null) : null)) {
                        // line 226
                        yield "                                <button href=\"javascript:void(0)\"
                                    onclick=\"GoLinks(event, '";
                        // line 227
                        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed((($_v20 = ($context["bookingLinks"] ?? null)) && is_array($_v20) || $_v20 instanceof ArrayAccess ? ($_v20[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 227)] ?? null) : null), 227, $this->source), "html", null, true);
                        yield "')\" class=\"btn btn-dr-card-2\">
                                    <svg width=\"28\" height=\"27\" viewBox=\"0 0 28 27\" fill=\"none\"
                                        xmlns=\"http://www.w3.org/2000/svg\">
                                        <ellipse cx=\"13.7306\" cy=\"13.7772\" rx=\"13.4181\" ry=\"13.1913\" fill=\"white\" />
                                        <path class=\"arr-cl\"
                                            d=\"M14.9238 10.2812L18.565 13.781L14.9238 17.2807M12.8722 13.781H18.463M8.36719 13.781H14.7408\"
                                            stroke=\"#003868\" stroke-width=\"2\" stroke-miterlimit=\"10\"
                                            stroke-linecap=\"round\" stroke-linejoin=\"round\" />
                                    </svg>
                                    Book Now
                                </button>
                                ";
                    } else {
                        // line 239
                        yield "                                <a href=\"https://bamc.myclinic.com.sa:8443\"
                                     class=\"btn btn-dr-card-2 ";
                        // line 240
                        if ( !(($_v21 = ($context["bookingLinks"] ?? null)) && is_array($_v21) || $_v21 instanceof ArrayAccess ? ($_v21[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 240)] ?? null) : null)) {
                            yield "mt-40";
                        }
                        yield "\">
                                    <svg width=\"28\" height=\"27\" viewBox=\"0 0 28 27\" fill=\"none\"
                                        xmlns=\"http://www.w3.org/2000/svg\">
                                        <ellipse cx=\"13.7306\" cy=\"13.7772\" rx=\"13.4181\" ry=\"13.1913\" fill=\"white\" />
                                        <path class=\"arr-cl\"
                                            d=\"M14.9238 10.2812L18.565 13.781L14.9238 17.2807M12.8722 13.781H18.463M8.36719 13.781H14.7408\"
                                            stroke=\"#003868\" stroke-width=\"2\" stroke-miterlimit=\"10\"
                                            stroke-linecap=\"round\" stroke-linejoin=\"round\" />
                                    </svg>
                                    Book Now
                                </a>
                                ";
                    }
                    // line 252
                    yield "                                ";
                }
                // line 253
                yield "                            </div>
                            ";
            }
            // line 255
            yield "                        </div>

                    </div>
                </a>
            </div>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['item'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 261
        yield "

        </div>

    </div>
</section>
<!-- ======= OUR DOCTORS END ======= -->

";
        // line 269
        $cmsPartialParams = [];
        yield $this->env->getExtension(\Cms\Twig\Extension::class)->partialFunction("components/appDownload"        , array_merge($context, ['__cms_partial_params' => $cmsPartialParams], $cmsPartialParams)        , true        );
        // line 270
        yield "
<script>
    var mySwiper = new Swiper('.swiper-container', {
        effect: '',
        loop: true,
        speed: 1000,
        slidesPerView: 1,
        navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev'
        },
        pagination: {
            el: '.swiper-pagination',
            type: 'bullets',
            clickable: 'true'
        },
        autoplay: {
            delay: 3000,
            disableOnInteraction: false,
        },



    });

    function GoLinks(event, value) {

        event.stopPropagation();
        window.location = value;
    }

</script>";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "C:\\xampp\\htdocs\\myclinic\\themes/myclinic/pages/specialty-detail.htm";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  537 => 270,  534 => 269,  524 => 261,  513 => 255,  509 => 253,  506 => 252,  489 => 240,  486 => 239,  471 => 227,  468 => 226,  465 => 225,  448 => 213,  445 => 212,  443 => 211,  440 => 210,  438 => 209,  429 => 203,  422 => 201,  417 => 198,  411 => 195,  407 => 194,  403 => 193,  397 => 190,  393 => 188,  391 => 187,  383 => 182,  379 => 181,  371 => 176,  367 => 175,  358 => 171,  354 => 170,  346 => 165,  341 => 163,  336 => 161,  333 => 160,  328 => 159,  320 => 153,  316 => 151,  313 => 150,  296 => 137,  293 => 136,  276 => 124,  273 => 123,  271 => 122,  268 => 121,  266 => 120,  256 => 115,  252 => 114,  245 => 112,  240 => 109,  233 => 105,  229 => 104,  225 => 103,  219 => 100,  215 => 98,  213 => 97,  205 => 92,  201 => 91,  193 => 86,  188 => 84,  182 => 81,  178 => 80,  173 => 78,  165 => 73,  160 => 71,  154 => 68,  150 => 66,  148 => 65,  129 => 49,  122 => 45,  100 => 25,  92 => 22,  87 => 20,  76 => 13,  74 => 12,  70 => 11,  66 => 10,  61 => 8,  57 => 7,  54 => 6,  50 => 5,  44 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "C:\\xampp\\htdocs\\myclinic\\themes/myclinic/pages/specialty-detail.htm", "");
    }
    
    public function checkSecurity()
    {
        static $tags = ["for" => 5, "if" => 12, "partial" => 269];
        static $filters = ["escape" => 7, "raw" => 10, "theme" => 49, "date" => 103];
        static $functions = [];

        try {
            $this->sandbox->checkSecurity(
                ['for', 'if', 'partial'],
                ['escape', 'raw', 'theme', 'date'],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
