<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* C:\xampp\htdocs\myclinic\themes/myclinic/pages/ar/specialty-detail.htm */
class __TwigTemplate_3823fc3927a80655605cf6d30c33616d extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield "<div class=\"swiper-container text-end\">
    <!-- Additional required wrapper -->
    <div class=\"swiper-wrapper\">
        <!-- Slider -->
        ";
        // line 5
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["sliders"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 6
            yield "        <div class=\"swiper-slide\">
            <img src=\"";
            // line 7
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "slider_image_ar_mobile", [], "any", false, false, true, 7), "path", [], "any", false, false, true, 7), 7, $this->source), "html", null, true);
            yield "\" class=\"slidemc\" alt=\"\">

            <img src=\"";
            // line 9
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "slider_image_ar", [], "any", false, false, true, 9), "path", [], "any", false, false, true, 9), 9, $this->source), "html", null, true);
            yield "\" class=\"slidemc slidemc-m-home\" alt=\"\">

            <div class=\"slide-text slide-text-arslide\">
                <h1 class=\"mb-3\">";
            // line 12
            yield $this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "title_ar", [], "any", false, false, true, 12), 12, $this->source);
            yield " </h1>
                <p class=\"mb-3 mb-sm-5\">";
            // line 13
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "tag_line_ar", [], "any", false, false, true, 13), 13, $this->source), "html", null, true);
            yield "</p>
                ";
            // line 14
            if (Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "link_value", [], "any", false, false, true, 14)) {
                // line 15
                yield "
                <a href=\"ar/";
                // line 16
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "link_value", [], "any", false, false, true, 16), 16, $this->source), "html", null, true);
                yield "\"
                    class=\"btn btn-primary slide-s btn-mc-01 btn-mc-01-ar mb-6 flex-row-reverse  \">

                    <svg class=\"ms-3\" xmlns=\"http://www.w3.org/2000/svg\" width=\"40\" height=\"40\" viewBox=\"0 0 40 40\"
                        fill=\"none\">
                        <ellipse cx=\"20\" cy=\"19.6\" rx=\"20\" ry=\"19.6\" fill=\"white\" />
                        <path d=\"M21.7727 14.3984L27.2 19.5984L21.7727 24.7984M27.048 19.5984H18.7148H12\"
                            stroke=\"#003868\" stroke-width=\"2\" stroke-miterlimit=\"10\" stroke-linecap=\"round\"
                            stroke-linejoin=\"round\" />
                    </svg> ";
                // line 25
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "link_name_ar", [], "any", false, false, true, 25), 25, $this->source), "html", null, true);
                yield " </a>
                ";
            }
            // line 27
            yield "            </div>
        </div>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['item'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 30
        yield "    </div>
    <!-- If we need pagination -->
    <div class=\"swiper-pagination\"></div>

    <!-- If we need navigation buttons -->
    <div class=\"swiper-button-prev\"><span></span></div>
    <div class=\"swiper-button-next\"><span></span></div>

    <!-- Search Form -->

    <!-- <section class=\"front-search z-1 d-none d-lg-block w-100\">
      <div class=\"container front-form-bg\">
        <div class=\"row \">
          <div class=\"col-12\">
            ";
        // line 44
        $cmsPartialParams = [];
        yield $this->env->getExtension(\Cms\Twig\Extension::class)->partialFunction("components/homePageSearch-ar"        , array_merge($context, ['__cms_partial_params' => $cmsPartialParams], $cmsPartialParams)        , true        );
        // line 45
        yield "          </div>
        </div>
      </div>
    </section> -->

</div>



<section class=\"section-py-100\">
    <div class=\"container section-bg\">
        <div class=\"row align-items-center\">
            <div class=\"col-12\">
                <div class=\"mc-block text-end\">
                    <h1>ملخص</h1>
                    <p>";
        // line 60
        yield $this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["specialty"] ?? null), "description_ar", [], "any", false, false, true, 60), 60, $this->source);
        yield "</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ======= OUR DOCTORS  START ======= -->
<section>
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-12 text-center section-py-100 pt-0\">
                <h1 class=\"\">أطباؤنا</h1>
            </div>
        </div>

        <div class=\"row\" dir=\"rtl\">
            ";
        // line 77
        if (($context["hod"] ?? null)) {
            // line 78
            yield "            <div class=\"col-12 col-sm-6 col-xl-4 col-xxl-3\">
                <a href=\"javascript:void(0)\" onclick=\"GoLinks(event,'/doctor-detail/'+'";
            // line 79
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "id", [], "any", false, false, true, 79), 79, $this->source), "html", null, true);
            yield "')\">
                    <div class=\"doctor-card\">

                        <a href=\"/ar/doctor-detail/";
            // line 82
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "id", [], "any", false, false, true, 82), 82, $this->source), "html", null, true);
            yield "\">
                            <div class=\"doctor-img-001 text-center\">
                                <img src=\"";
            // line 84
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "doctor_image", [], "any", false, false, true, 84), "path", [], "any", false, false, true, 84), 84, $this->source), "html", null, true);
            yield "\" class=\"img-fluid\" alt=\"\"
                                    style=\"border-radius: 50%;\">
                            </div>
                        </a>

                        <a href=\"/ar/doctor-detail/";
            // line 89
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "id", [], "any", false, false, true, 89), 89, $this->source), "html", null, true);
            yield "\" style=\"text-decoration: none;\">
                            <h3> <span>
                                    ";
            // line 91
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "designation_ar", [], "any", false, false, true, 91), 91, $this->source), "html", null, true);
            yield "
                                </span>";
            // line 92
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "name_ar", [], "any", false, false, true, 92), 92, $this->source), "html", null, true);
            yield "</h3>
                        </a>

                        <div class=\"dr-specialities drspecialty-truncate my-3\"><a href=\"/ar/doctor-detail/";
            // line 95
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "id", [], "any", false, false, true, 95), 95, $this->source), "html", null, true);
            yield "\"
                                style=\"text-decoration: none;\"
                                class=\"dr-specialities drspecialty-truncate\">";
            // line 97
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "specialty_desc_ar", [], "any", false, false, true, 97), 97, $this->source), "html", null, true);
            yield "</a></div>


                        <div class=\" row hide\">
                            <div class=\"col-12 text-center\">
                                <p style=\"margin-bottom: 0px;\"><a href=\"/ar/doctor-detail/";
            // line 102
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "id", [], "any", false, false, true, 102), 102, $this->source), "html", null, true);
            yield "\"
                                        style=\"text-decoration: none; color: white;\">";
            // line 103
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "highest_degree_ar", [], "any", false, false, true, 103), 103, $this->source), "html", null, true);
            yield "</a></p>
                            </div>
                        </div>
                        ";
            // line 107
            yield "                        ";
            $context["arabicNumbers"] = ["0" => "٠", "1" => "١", "2" => "٢", "3" => "٣", "4" => "٤", "5" => "٥", "6" => "٦", "7" => "٧", "8" => "٨", "9" => "٩", "AM" => "ص", "PM" => "م", "Jan" => "يناير", "Feb" => "فبراير", "Mar" => "مارس", "Apr" => "أبريل", "May" => "مايو", "Jun" => "يونيو", "Jul" => "يوليو", "Aug" => "أغسطس", "Sep" => "سبتمبر", "Oct" => "أكتوبر", "Nov" => "نوفمبر", "Dec" => "ديسمبر"];
            // line 113
            yield "                        


                        <div class=\"dr-calendar my-4\" style=\"direction: rtl;\">
                            ";
            // line 117
            if (((($_v0 = ($context["availableDates"] ?? null)) && is_array($_v0) || $_v0 instanceof ArrayAccess ? ($_v0[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "id", [], "any", false, false, true, 117)] ?? null) : null) && (($_v1 = ($context["bookingLinks"] ?? null)) && is_array($_v1) || $_v1 instanceof ArrayAccess ? ($_v1[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "id", [], "any", false, false, true, 117)] ?? null) : null))) {
                // line 118
                yield "                            <div class=\"dr-calendar-text text-center\">
                                <p><strong>أقرب موعد متاح</strong></p>
                                <p style=\"font-size: 12px;\"><strong>";
                // line 120
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, (($_v2 = ($context["availableDates"] ?? null)) && is_array($_v2) || $_v2 instanceof ArrayAccess ? ($_v2[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "id", [], "any", false, false, true, 120)] ?? null) : null), "company_name", [], "any", false, false, true, 120), 120, $this->source), "html", null, true);
                yield "</strong></p>
                            </div>
                            <div class=\"dr-calendar-flex\">
                                <a class=\"dr-cale\">";
                // line 123
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::replace($this->extensions['Twig\Extension\CoreExtension']->formatDate($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, (($_v3 = ($context["availableDates"] ?? null)) && is_array($_v3) || $_v3 instanceof ArrayAccess ? ($_v3[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "id", [], "any", false, false, true, 123)] ?? null) : null), "latest_date", [], "any", false, false, true, 123), 123, $this->source), "j-M-Y"), $this->sandbox->ensureToStringAllowed(                // line 124
($context["arabicNumbers"] ?? null), 124, $this->source)), "html", null, true);
                yield "</a>
                                <a class=\"dr-cale\">";
                // line 125
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::replace($this->extensions['Twig\Extension\CoreExtension']->formatDate($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, (($_v4 = ($context["availableDates"] ?? null)) && is_array($_v4) || $_v4 instanceof ArrayAccess ? ($_v4[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "id", [], "any", false, false, true, 125)] ?? null) : null), "latest_time", [], "any", false, false, true, 125), 125, $this->source), "h:i A"), $this->sandbox->ensureToStringAllowed(                // line 126
($context["arabicNumbers"] ?? null), 126, $this->source)), "html", null, true);
                yield "</a>
                                <!-- <div class=\"slots\">";
                // line 127
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, (($_v5 = ($context["availableDates"] ?? null)) && is_array($_v5) || $_v5 instanceof ArrayAccess ? ($_v5[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "id", [], "any", false, false, true, 127)] ?? null) : null), "slots_available", [], "any", false, false, true, 127), 127, $this->source), "html", null, true);
                yield " فتحات</div> -->

                            </div>
                            ";
            }
            // line 131
            yield "                        </div>

                        <div class=\"d-flex justify-content-around\">
                            <div class=\"";
            // line 134
            if ( !(($_v6 = ($context["bookingLinks"] ?? null)) && is_array($_v6) || $_v6 instanceof ArrayAccess ? ($_v6[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "id", [], "any", false, false, true, 134)] ?? null) : null)) {
                yield "w-100 mt-40";
            }
            yield "\">
                                <button href=\"javascript:void(0)\"
                                    onclick=\"GoLinks(event,'/ar/doctor-detail/'+'";
            // line 136
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "id", [], "any", false, false, true, 136), 136, $this->source), "html", null, true);
            yield "')\"
                                    class=\"btn btn-light btn-dr-card\">
                                    الحساب التعريفي
                                </button>
                            </div>

                            ";
            // line 142
            if (($context["canBook"] ?? null)) {
                // line 143
                yield "                            <div>
                                ";
                // line 144
                if (($context["isMobile"] ?? null)) {
                    // line 145
                    yield "                                <a href=\"/ar/contact-us\"
                                    class=\"btn btn-dr-card-2 ";
                    // line 146
                    if ( !(($_v7 = ($context["bookingLinks"] ?? null)) && is_array($_v7) || $_v7 instanceof ArrayAccess ? ($_v7[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "id", [], "any", false, false, true, 146)] ?? null) : null)) {
                        yield "mt-40";
                    }
                    yield "\">
                                    <svg width=\"28\" height=\"27\" viewBox=\"0 0 28 27\" fill=\"none\"
                                        xmlns=\"http://www.w3.org/2000/svg\">
                                        <ellipse cx=\"13.7306\" cy=\"13.7772\" rx=\"13.4181\" ry=\"13.1913\" fill=\"white\" />
                                        <path class=\"arr-cl\"
                                            d=\"M14.9238 10.2812L18.565 13.781L14.9238 17.2807M12.8722 13.781H18.463M8.36719 13.781H14.7408\"
                                            stroke=\"#003868\" stroke-width=\"2\" stroke-miterlimit=\"10\"
                                            stroke-linecap=\"round\" stroke-linejoin=\"round\" />
                                    </svg>
                                    اسألنا
                                </a>
                                ";
                } else {
                    // line 158
                    yield "                                ";
                    if ((($_v8 = ($context["bookingLinks"] ?? null)) && is_array($_v8) || $_v8 instanceof ArrayAccess ? ($_v8[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "id", [], "any", false, false, true, 158)] ?? null) : null)) {
                        // line 159
                        yield "                                <button href=\"javascript:void(0)\" onclick=\"GoLinks(event, '";
                        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed((($_v9 = ($context["bookingLinks"] ?? null)) && is_array($_v9) || $_v9 instanceof ArrayAccess ? ($_v9[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "id", [], "any", false, false, true, 159)] ?? null) : null), 159, $this->source), "html", null, true);
                        yield "')\"
                                    class=\"btn btn-dr-card-2\">
                                    <svg width=\"28\" height=\"27\" viewBox=\"0 0 28 27\" fill=\"none\"
                                        xmlns=\"http://www.w3.org/2000/svg\">
                                        <ellipse cx=\"13.7306\" cy=\"13.7772\" rx=\"13.4181\" ry=\"13.1913\" fill=\"white\" />
                                        <path class=\"arr-cl\"
                                            d=\"M14.9238 10.2812L18.565 13.781L14.9238 17.2807M12.8722 13.781H18.463M8.36719 13.781H14.7408\"
                                            stroke=\"#003868\" stroke-width=\"2\" stroke-miterlimit=\"10\"
                                            stroke-linecap=\"round\" stroke-linejoin=\"round\" />
                                    </svg>
                                    احجز الآن
                                </button>
                                ";
                    } else {
                        // line 172
                        yield "                                <a href=\"https://bamc.myclinic.com.sa:8443\"
                                    class=\"btn btn-dr-card-2 ";
                        // line 173
                        if ( !(($_v10 = ($context["bookingLinks"] ?? null)) && is_array($_v10) || $_v10 instanceof ArrayAccess ? ($_v10[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "id", [], "any", false, false, true, 173)] ?? null) : null)) {
                            yield "mt-40";
                        }
                        yield "\">
                                    <svg width=\"28\" height=\"27\" viewBox=\"0 0 28 27\" fill=\"none\"
                                        xmlns=\"http://www.w3.org/2000/svg\">
                                        <ellipse cx=\"13.7306\" cy=\"13.7772\" rx=\"13.4181\" ry=\"13.1913\" fill=\"white\" />
                                        <path class=\"arr-cl\"
                                            d=\"M14.9238 10.2812L18.565 13.781L14.9238 17.2807M12.8722 13.781H18.463M8.36719 13.781H14.7408\"
                                            stroke=\"#003868\" stroke-width=\"2\" stroke-miterlimit=\"10\"
                                            stroke-linecap=\"round\" stroke-linejoin=\"round\" />
                                    </svg>
                                    احجز الآن
                                </a>
                                ";
                    }
                    // line 185
                    yield "                                ";
                }
                // line 186
                yield "                            </div>
                            ";
            }
            // line 188
            yield "                        </div>

                    </div>
                </a>
            </div>
            ";
        }
        // line 194
        yield "            ";
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["doctors"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 195
            yield "            <div class=\"col-12 col-sm-6 col-xl-4 col-xxl-3\">
                <a href=\"javascript:void(0)\" onclick=\"GoLinks(event,'/ar/doctor-detail/'+'";
            // line 196
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 196), 196, $this->source), "html", null, true);
            yield "')\">
                    <div class=\"doctor-card\">

                        <a href=\"/ar/doctor-detail/";
            // line 199
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 199), 199, $this->source), "html", null, true);
            yield "\">
                            <div class=\"doctor-img-001 text-center\">
                                <img src=\"";
            // line 201
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "doctor_image", [], "any", false, false, true, 201), "path", [], "any", false, false, true, 201), 201, $this->source), "html", null, true);
            yield "\" class=\"img-fluid\" alt=\"\"
                                    style=\"border-radius: 50%;\">
                            </div>
                        </a>

                        <a href=\"/ar/doctor-detail/";
            // line 206
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 206), 206, $this->source), "html", null, true);
            yield "\" style=\"text-decoration: none;\">
                            <h3> <span>
                                    ";
            // line 208
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "designation_ar", [], "any", false, false, true, 208), 208, $this->source), "html", null, true);
            yield "
                                </span>";
            // line 209
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "name_ar", [], "any", false, false, true, 209), 209, $this->source), "html", null, true);
            yield "</h3>
                        </a>

                        <div class=\"dr-specialities drspecialty-truncate my-3\"><a href=\"/ar/doctor-detail/";
            // line 212
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 212), 212, $this->source), "html", null, true);
            yield "\"
                                style=\"text-decoration: none;\"
                                class=\"dr-specialities drspecialty-truncate\">";
            // line 214
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "specialty_desc_ar", [], "any", false, false, true, 214), 214, $this->source), "html", null, true);
            yield "</a></div>


                        <div class=\" row hide\">
                            <div class=\"col-12 text-center\">
                                <p style=\"margin-bottom: 0px;\"><a href=\"/ar/doctor-detail/";
            // line 219
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 219), 219, $this->source), "html", null, true);
            yield "\"
                                        style=\"text-decoration: none; color: white;\">";
            // line 220
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "highest_degree_ar", [], "any", false, false, true, 220), 220, $this->source), "html", null, true);
            yield "</a></p>
                            </div>
                        </div>
                        ";
            // line 224
            yield "                        ";
            $context["arabicNumbers"] = ["0" => "٠", "1" => "١", "2" => "٢", "3" => "٣", "4" => "٤", "5" => "٥", "6" => "٦", "7" => "٧", "8" => "٨", "9" => "٩", "AM" => "ص", "PM" => "م", "Jan" => "يناير", "Feb" => "فبراير", "Mar" => "مارس", "Apr" => "أبريل", "May" => "مايو", "Jun" => "يونيو", "Jul" => "يوليو", "Aug" => "أغسطس", "Sep" => "سبتمبر", "Oct" => "أكتوبر", "Nov" => "نوفمبر", "Dec" => "ديسمبر"];
            // line 230
            yield "                        


                        <div class=\"dr-calendar my-4\">
                            ";
            // line 234
            if (((($_v11 = ($context["availableDates"] ?? null)) && is_array($_v11) || $_v11 instanceof ArrayAccess ? ($_v11[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 234)] ?? null) : null) && (($_v12 = ($context["bookingLinks"] ?? null)) && is_array($_v12) || $_v12 instanceof ArrayAccess ? ($_v12[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 234)] ?? null) : null))) {
                // line 235
                yield "                            <div class=\"dr-calendar-text text-center\">
                                <p><strong>أقرب موعد متاح</strong></p>
                                <p style=\"font-size: 12px;\"><strong>";
                // line 237
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, (($_v13 = ($context["availableDates"] ?? null)) && is_array($_v13) || $_v13 instanceof ArrayAccess ? ($_v13[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 237)] ?? null) : null), "company_name", [], "any", false, false, true, 237), 237, $this->source), "html", null, true);
                yield "</strong></p>
                            </div>
                            <div class=\"dr-calendar-flex\">
                                <a class=\"dr-cale\">";
                // line 240
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::replace($this->extensions['Twig\Extension\CoreExtension']->formatDate($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, (($_v14 = ($context["availableDates"] ?? null)) && is_array($_v14) || $_v14 instanceof ArrayAccess ? ($_v14[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 240)] ?? null) : null), "latest_date", [], "any", false, false, true, 240), 240, $this->source), "j-M-Y"), $this->sandbox->ensureToStringAllowed(                // line 241
($context["arabicNumbers"] ?? null), 241, $this->source)), "html", null, true);
                yield "</a>
                                <a class=\"dr-cale\">";
                // line 242
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::replace($this->extensions['Twig\Extension\CoreExtension']->formatDate($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, (($_v15 = ($context["availableDates"] ?? null)) && is_array($_v15) || $_v15 instanceof ArrayAccess ? ($_v15[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 242)] ?? null) : null), "latest_time", [], "any", false, false, true, 242), 242, $this->source), "h:i A"), $this->sandbox->ensureToStringAllowed(                // line 243
($context["arabicNumbers"] ?? null), 243, $this->source)), "html", null, true);
                yield "</a>
                                <!-- <div class=\"slots\">";
                // line 244
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, (($_v16 = ($context["availableDates"] ?? null)) && is_array($_v16) || $_v16 instanceof ArrayAccess ? ($_v16[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 244)] ?? null) : null), "slots_available", [], "any", false, false, true, 244), 244, $this->source), "html", null, true);
                yield " فتحات</div> -->
                            </div>
                            ";
            }
            // line 247
            yield "                        </div>

                        <div class=\"d-flex justify-content-around\">
                            <div class=\"";
            // line 250
            if ( !(($_v17 = ($context["bookingLinks"] ?? null)) && is_array($_v17) || $_v17 instanceof ArrayAccess ? ($_v17[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 250)] ?? null) : null)) {
                yield "w-100 mt-40";
            }
            yield "\">
                                <button href=\"javascript:void(0)\"
                                    onclick=\"GoLinks(event,'/ar/doctor-detail/'+'";
            // line 252
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 252), 252, $this->source), "html", null, true);
            yield "')\"
                                    class=\"btn btn-light btn-dr-card\">
                                    الحساب التعريفي
                                </button>
                            </div>

                            ";
            // line 258
            if (($context["canBook"] ?? null)) {
                // line 259
                yield "                            <div>
                                ";
                // line 260
                if (($context["isMobile"] ?? null)) {
                    // line 261
                    yield "                                <a href=\"/ar/contact-us\"
                                    class=\"btn btn-dr-card-2 ";
                    // line 262
                    if ( !(($_v18 = ($context["bookingLinks"] ?? null)) && is_array($_v18) || $_v18 instanceof ArrayAccess ? ($_v18[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 262)] ?? null) : null)) {
                        yield "mt-40";
                    }
                    yield "\">
                                    <svg width=\"28\" height=\"27\" viewBox=\"0 0 28 27\" fill=\"none\"
                                        xmlns=\"http://www.w3.org/2000/svg\">
                                        <ellipse cx=\"13.7306\" cy=\"13.7772\" rx=\"13.4181\" ry=\"13.1913\" fill=\"white\" />
                                        <path class=\"arr-cl\"
                                            d=\"M14.9238 10.2812L18.565 13.781L14.9238 17.2807M12.8722 13.781H18.463M8.36719 13.781H14.7408\"
                                            stroke=\"#003868\" stroke-width=\"2\" stroke-miterlimit=\"10\"
                                            stroke-linecap=\"round\" stroke-linejoin=\"round\" />
                                    </svg>
                                    اسألنا
                                </a>
                                ";
                } else {
                    // line 274
                    yield "                                ";
                    if ((($_v19 = ($context["bookingLinks"] ?? null)) && is_array($_v19) || $_v19 instanceof ArrayAccess ? ($_v19[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 274)] ?? null) : null)) {
                        // line 275
                        yield "                                <button href=\"javascript:void(0)\"
                                    onclick=\"GoLinks(event, '";
                        // line 276
                        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed((($_v20 = ($context["bookingLinks"] ?? null)) && is_array($_v20) || $_v20 instanceof ArrayAccess ? ($_v20[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 276)] ?? null) : null), 276, $this->source), "html", null, true);
                        yield "')\" class=\"btn btn-dr-card-2\">
                                    <svg width=\"28\" height=\"27\" viewBox=\"0 0 28 27\" fill=\"none\"
                                        xmlns=\"http://www.w3.org/2000/svg\">
                                        <ellipse cx=\"13.7306\" cy=\"13.7772\" rx=\"13.4181\" ry=\"13.1913\" fill=\"white\" />
                                        <path class=\"arr-cl\"
                                            d=\"M14.9238 10.2812L18.565 13.781L14.9238 17.2807M12.8722 13.781H18.463M8.36719 13.781H14.7408\"
                                            stroke=\"#003868\" stroke-width=\"2\" stroke-miterlimit=\"10\"
                                            stroke-linecap=\"round\" stroke-linejoin=\"round\" />
                                    </svg>
                                    احجز الآن
                                </button>
                                ";
                    } else {
                        // line 288
                        yield "                                <a href=\"https://bamc.myclinic.com.sa:8443\"
                                    class=\"btn btn-dr-card-2 ";
                        // line 289
                        if ( !(($_v21 = ($context["bookingLinks"] ?? null)) && is_array($_v21) || $_v21 instanceof ArrayAccess ? ($_v21[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 289)] ?? null) : null)) {
                            yield "mt-40";
                        }
                        yield "\">
                                    <svg width=\"28\" height=\"27\" viewBox=\"0 0 28 27\" fill=\"none\"
                                        xmlns=\"http://www.w3.org/2000/svg\">
                                        <ellipse cx=\"13.7306\" cy=\"13.7772\" rx=\"13.4181\" ry=\"13.1913\" fill=\"white\" />
                                        <path class=\"arr-cl\"
                                            d=\"M14.9238 10.2812L18.565 13.781L14.9238 17.2807M12.8722 13.781H18.463M8.36719 13.781H14.7408\"
                                            stroke=\"#003868\" stroke-width=\"2\" stroke-miterlimit=\"10\"
                                            stroke-linecap=\"round\" stroke-linejoin=\"round\" />
                                    </svg>
                                    احجز الآن
                                </a>
                                ";
                    }
                    // line 301
                    yield "                                ";
                }
                // line 302
                yield "                            </div>
                            ";
            }
            // line 304
            yield "                        </div>

                    </div>
                </a>
            </div>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['item'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 310
        yield "

        </div>

    </div>
</section>
<!-- ======= OUR DOCTORS END ======= -->

";
        // line 318
        $cmsPartialParams = [];
        yield $this->env->getExtension(\Cms\Twig\Extension::class)->partialFunction("components/appDownload-ar"        , array_merge($context, ['__cms_partial_params' => $cmsPartialParams], $cmsPartialParams)        , true        );
        // line 319
        yield "

<script>
    var mySwiper = new Swiper('.swiper-container', {
        effect: '',
        loop: true,
        speed: 1000,
        slidesPerView: 1,
        navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev'
        },
        pagination: {
            el: '.swiper-pagination',
            type: 'bullets',
            clickable: 'true'
        },
        autoplay: {
            delay: 3000,
            disableOnInteraction: false,
        },



    });

    function GoLinks(event, value) {

        event.stopPropagation();
        window.location = value;
    }

</script>

<style>
    .mc-block ul li {
        text-align: right;
        list-style: none;
    }

    .mc-block ul li::after {
        content: '.';
        font-size: 30px;
        line-height: 0px;
        position: relative;
        top: -2px;
        margin-left: 8px;
    }
</style>";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "C:\\xampp\\htdocs\\myclinic\\themes/myclinic/pages/ar/specialty-detail.htm";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  587 => 319,  584 => 318,  574 => 310,  563 => 304,  559 => 302,  556 => 301,  539 => 289,  536 => 288,  521 => 276,  518 => 275,  515 => 274,  498 => 262,  495 => 261,  493 => 260,  490 => 259,  488 => 258,  479 => 252,  472 => 250,  467 => 247,  461 => 244,  457 => 243,  456 => 242,  452 => 241,  451 => 240,  445 => 237,  441 => 235,  439 => 234,  433 => 230,  430 => 224,  424 => 220,  420 => 219,  412 => 214,  407 => 212,  401 => 209,  397 => 208,  392 => 206,  384 => 201,  379 => 199,  373 => 196,  370 => 195,  365 => 194,  357 => 188,  353 => 186,  350 => 185,  333 => 173,  330 => 172,  313 => 159,  310 => 158,  293 => 146,  290 => 145,  288 => 144,  285 => 143,  283 => 142,  274 => 136,  267 => 134,  262 => 131,  255 => 127,  251 => 126,  250 => 125,  246 => 124,  245 => 123,  239 => 120,  235 => 118,  233 => 117,  227 => 113,  224 => 107,  218 => 103,  214 => 102,  206 => 97,  201 => 95,  195 => 92,  191 => 91,  186 => 89,  178 => 84,  173 => 82,  167 => 79,  164 => 78,  162 => 77,  142 => 60,  125 => 45,  122 => 44,  106 => 30,  98 => 27,  93 => 25,  81 => 16,  78 => 15,  76 => 14,  72 => 13,  68 => 12,  62 => 9,  57 => 7,  54 => 6,  50 => 5,  44 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "C:\\xampp\\htdocs\\myclinic\\themes/myclinic/pages/ar/specialty-detail.htm", "");
    }
    
    public function checkSecurity()
    {
        static $tags = ["for" => 5, "if" => 14, "partial" => 44, "set" => 107];
        static $filters = ["escape" => 7, "raw" => 12, "replace" => 124, "date" => 123];
        static $functions = [];

        try {
            $this->sandbox->checkSecurity(
                ['for', 'if', 'partial', 'set'],
                ['escape', 'raw', 'replace', 'date'],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
