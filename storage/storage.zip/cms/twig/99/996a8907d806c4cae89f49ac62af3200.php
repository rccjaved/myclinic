<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* C:\xampp\htdocs\myclinic\themes/myclinic/pages/ar/our-specialities.htm */
class __TwigTemplate_a8e23ed082aefd0ca6a4aba541af5b99 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield "<div class=\"swiper-container resize-slider\">
    <!-- Additional required wrapper -->
    <div class=\"swiper-wrapper\">
        <!-- Slider -->
        ";
        // line 5
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["sliders"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 6
            yield "        <div class=\"swiper-slide\">
            <img src=\"";
            // line 7
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "slider_image_ar_mobile", [], "any", false, false, true, 7), "path", [], "any", false, false, true, 7), 7, $this->source), "html", null, true);
            yield "\" class=\"slidemc\" alt=\"\">
       
            <img src=\"";
            // line 9
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "slider_image_ar", [], "any", false, false, true, 9), "path", [], "any", false, false, true, 9), 9, $this->source), "html", null, true);
            yield "\" class=\"slidemc slidemc-m-home\" alt=\"\">
                <div class=\" slide-text w-100 text-end\">
            <h1 class=\"mb-3\">";
            // line 11
            yield $this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "title_ar", [], "any", false, false, true, 11), 11, $this->source);
            yield "</h1>
            <p class=\"mb-3 mb-sm-5\">";
            // line 12
            yield $this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "tag_line_ar", [], "any", false, false, true, 12), 12, $this->source);
            yield "</p>
            ";
            // line 13
            if (Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "link_value", [], "any", false, false, true, 13)) {
                // line 14
                yield "            <a href=\"/ar/";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "link_value", [], "any", false, false, true, 14), 14, $this->source), "html", null, true);
                yield "\" class=\"btn btn-primary slide-s btn-mc-01 mb-6\"><svg
                    xmlns=\"http://www.w3.org/2000/svg\" width=\"40\" height=\"40\" viewBox=\"0 0 40 40\" fill=\"none\"
                    style=\"margin-right: 20px;\">
                    <ellipse cx=\"20\" cy=\"19.6\" rx=\"20\" ry=\"19.6\" fill=\"white\" />
                    <path d=\"M21.7727 14.3984L27.2 19.5984L21.7727 24.7984M27.048 19.5984H18.7148H12\" stroke=\"#003868\"
                        stroke-width=\"2\" stroke-miterlimit=\"10\" stroke-linecap=\"round\" stroke-linejoin=\"round\" />
                </svg>";
                // line 20
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "link_name_ar", [], "any", false, false, true, 20), 20, $this->source), "html", null, true);
                yield "</a>
            ";
            }
            // line 22
            yield "        </div>
    </div>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['item'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 25
        yield "</div>
<!-- If we need pagination -->
<div class=\"swiper-pagination\"></div>

<!-- If we need navigation buttons -->
<div class=\"swiper-button-prev\"><span></span></div>
<div class=\"swiper-button-next\"><span></span></div>




</div>




";
        // line 41
        if (($context["overview"] ?? null)) {
            // line 42
            yield "
<section class=\"mt-5\">
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-12 text-center\">
                <h1 class=\"\">";
            // line 47
            yield $this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["overview"] ?? null), "title_ar", [], "any", false, false, true, 47), 47, $this->source);
            yield "</h1>
                <p class=\"overview text-justy\">";
            // line 48
            yield $this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["overview"] ?? null), "description_ar", [], "any", false, false, true, 48), 48, $this->source);
            yield "</p>
            </div>

        </div>
    </div>
</section>
";
        }
        // line 55
        yield "

";
        // line 57
        $cmsPartialParams = [];
        yield $this->env->getExtension(\Cms\Twig\Extension::class)->partialFunction("components/specialtiesViewAll-ar"        , array_merge($context, ['__cms_partial_params' => $cmsPartialParams], $cmsPartialParams)        , true        );
        // line 58
        yield "
";
        // line 59
        $cmsPartialParams = [];
        $cmsPartialParams['testimonials'] = ($context["testimonials"] ?? null)        ;
        yield $this->env->getExtension(\Cms\Twig\Extension::class)->partialFunction("components/testimonial-ar"        , array_merge($context, ['__cms_partial_params' => $cmsPartialParams], $cmsPartialParams)        , true        );
        // line 60
        yield "

";
        // line 62
        $cmsPartialParams = [];
        yield $this->env->getExtension(\Cms\Twig\Extension::class)->partialFunction("components/appDownload-ar"        , array_merge($context, ['__cms_partial_params' => $cmsPartialParams], $cmsPartialParams)        , true        );
        // line 63
        yield "

<script>

    // ------------- New Slider ----------

    // swiper    
    var mySwiper = new Swiper('.swiper-container', {
        effect: '',
        loop: false,
        speed: 1000,
        slidesPerView: 1,
        navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev'
        },
        pagination: {
            el: '.swiper-pagination',
            type: 'bullets',
            clickable: 'true'
        },
        autoplay: {
            delay: 3000,
            disableOnInteraction: false,
        },



    });



</script>";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "C:\\xampp\\htdocs\\myclinic\\themes/myclinic/pages/ar/our-specialities.htm";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  162 => 63,  159 => 62,  155 => 60,  151 => 59,  148 => 58,  145 => 57,  141 => 55,  131 => 48,  127 => 47,  120 => 42,  118 => 41,  100 => 25,  92 => 22,  87 => 20,  77 => 14,  75 => 13,  71 => 12,  67 => 11,  62 => 9,  57 => 7,  54 => 6,  50 => 5,  44 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "C:\\xampp\\htdocs\\myclinic\\themes/myclinic/pages/ar/our-specialities.htm", "");
    }
    
    public function checkSecurity()
    {
        static $tags = ["for" => 5, "if" => 13, "partial" => 57];
        static $filters = ["escape" => 7, "raw" => 11];
        static $functions = [];

        try {
            $this->sandbox->checkSecurity(
                ['for', 'if', 'partial'],
                ['escape', 'raw'],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
