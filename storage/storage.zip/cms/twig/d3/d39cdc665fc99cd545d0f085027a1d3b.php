<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* C:\xampp\htdocs\myclinic\themes/myclinic/layouts/master.htm */
class __TwigTemplate_4568fa9bd1f8501663066e9cdca9d445 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield "<!DOCTYPE html>
<html>

<head>
    ";
        // line 5
        $cmsPartialParams = [];
        yield $this->env->getExtension(\Cms\Twig\Extension::class)->partialFunction("site/meta"        , array_merge($context, ['__cms_partial_params' => $cmsPartialParams], $cmsPartialParams)        , true        );
        // line 6
        yield "    
  </head>

<body class=\"";
        // line 9
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(("page-" . $this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["this"] ?? null), "page", [], "any", false, false, true, 9), "id", [], "any", false, false, true, 9), 9, $this->source)), "html", null, true);
        yield "\">
";
        // line 10
        $context['__cms_component_params'] = [];
        yield $this->env->getExtension(\Cms\Twig\Extension::class)->componentFunction("googleTracker"        , $context['__cms_component_params']        );
        unset($context['__cms_component_params']);
        // line 11
        yield "<!-- Google Tag Manager (noscript) -->
<noscript><iframe src=\"https://www.googletagmanager.com/ns.html?id=GTM-NHS8GLVG\"
height=\"0\" width=\"0\" style=\"display:none;visibility:hidden\"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src=\"https://www.googletagmanager.com/ns.html?id=GTM-T733M5M9\"
height=\"0\" width=\"0\" style=\"display:none;visibility:hidden\"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
    <a id=\"topbutton\"></a>
    <!-- 
    <ul id=\"floatmenu\" class=\"menu slideInLeft\">
        <li title=\"My Clinic\"><a href=\"/myclinic/\" class=\"home\">My Clinic</a></li>
        <li title=\"Doctors\"><a href=\"/myclinic/find-doctor\" class=\"doctors\">Doctor's</a></li>
        <li title=\"Specialty\"><a href=\"/myclinic/our-programs\" class=\"special1\">Specialties</a></li>
        <li title=\"Book Now\"><a href=\"/myclinic/our-specialities\" class=\"booknow\">Book Now</a></li>
        <li title=\"Contact Us\"><a href=\"/myclinic/contact-us\" class=\"contactcall\">contact</a></li>
              
    </ul> -->
    <!-- Header -->
    ";
        // line 30
        $cmsPartialParams = [];
        yield $this->env->getExtension(\Cms\Twig\Extension::class)->partialFunction("site/header"        , array_merge($context, ['__cms_partial_params' => $cmsPartialParams], $cmsPartialParams)        , true        );
        // line 31
        yield "
    <!-- Content -->
    ";
        // line 33
        yield $this->env->getExtension(\Cms\Twig\Extension::class)->pageFunction($context);
        // line 34
        yield "
    <!-- Footer -->
    ";
        // line 36
        $cmsPartialParams = [];
        yield $this->env->getExtension(\Cms\Twig\Extension::class)->partialFunction("site/footer"        , array_merge($context, ['__cms_partial_params' => $cmsPartialParams], $cmsPartialParams)        , true        );
        // line 37
        yield "
    ";
        // line 38
        $cmsPartialParams = [];
        yield $this->env->getExtension(\Cms\Twig\Extension::class)->partialFunction("site/script"        , array_merge($context, ['__cms_partial_params' => $cmsPartialParams], $cmsPartialParams)        , true        );
        // line 39
        yield "


    <script src=\"https://unpkg.com/swiper/swiper-bundle.min.js\"></script>
    <script>
      document.addEventListener('DOMContentLoaded', function () {
        var mySwiper = new Swiper('.swiper-container', {
          autoplay: {
            delay: 20000,
            disableOnInteraction: false,
          },
          navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
          },
          pagination: {
            el: '.swiper-pagination',
            type: 'bullets',
            clickable: true,
          },
        });
    
        var swiperVideos = document.querySelectorAll('.swiper-video');
    
        swiperVideos.forEach(function (video) {
          video.addEventListener('play', function () {
            mySwiper.autoplay.stop();
          });
    
          video.addEventListener('pause', function () {
            mySwiper.autoplay.start();
          });
        });
      });
    </script>
</body>

</html>";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "C:\\xampp\\htdocs\\myclinic\\themes/myclinic/layouts/master.htm";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  109 => 39,  106 => 38,  103 => 37,  100 => 36,  96 => 34,  94 => 33,  90 => 31,  87 => 30,  66 => 11,  62 => 10,  58 => 9,  53 => 6,  50 => 5,  44 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "C:\\xampp\\htdocs\\myclinic\\themes/myclinic/layouts/master.htm", "");
    }
    
    public function checkSecurity()
    {
        static $tags = ["partial" => 5, "component" => 10, "page" => 33];
        static $filters = ["escape" => 9];
        static $functions = [];

        try {
            $this->sandbox->checkSecurity(
                ['partial', 'component', 'page'],
                ['escape'],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
