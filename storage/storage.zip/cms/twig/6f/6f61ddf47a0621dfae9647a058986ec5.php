<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* C:\xampp\htdocs\myclinic\themes/myclinic/pages/location-doctors.htm */
class __TwigTemplate_482e678334d0049ef4375c0eafc693d9 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield "<!-- ======= BANNER START ======= -->
<section class=\"section-bg\">
    <div class=\"container-fluid\">
        <div class=\"row align-items-center\">
            <div class=\"col-md-6 text-center text-sm-start px-0 d-none d-md-block\">
                <div class=\"mc-block\">
                    <h1>";
        // line 7
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["location"] ?? null), "name", [], "any", false, false, true, 7), 7, $this->source), "html", null, true);
        yield "</h1>
                </div>
            </div>
            <div class=\"col-md-6 px-0\">
                <div class=\"position-relative\">
                    <h1 class=\"d-md-none location-in-mobile\">";
        // line 12
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["location"] ?? null), "name", [], "any", false, false, true, 12), 12, $this->source), "html", null, true);
        yield "</h1>
                    <img src=\"";
        // line 13
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["location"] ?? null), "location_image", [], "any", false, false, true, 13), "path", [], "any", false, false, true, 13), 13, $this->source), "html", null, true);
        yield "\" class=\"img-fluid location-img\" alt=\"\">
                    <form class=\"row row-cols-2 g-2 g-lg-3 dr-search-form align-items-center\" id=\"search-form\">

                        <div class=\"col-12\">
                            <label class=\"visually-hidden\" for=\"autoSizingSelect\">Preference</label>
                            <select class=\"form-select form-select-lg select-mc\" id=\"location\">
                                ";
        // line 19
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["locations"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 20
            yield "                                ";
            if ((Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 20) == Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["location"] ?? null), "id", [], "any", false, false, true, 20))) {
                // line 21
                yield "                                <option value=\"";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["location"] ?? null), "id", [], "any", false, false, true, 21), 21, $this->source), "html", null, true);
                yield "\" selected>";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["location"] ?? null), "name", [], "any", false, false, true, 21), 21, $this->source), "html", null, true);
                yield "</option>
                                ";
            } else {
                // line 23
                yield "                                <option value=";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 23), 23, $this->source), "html", null, true);
                yield ">";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "name", [], "any", false, false, true, 23), 23, $this->source), "html", null, true);
                yield "</option>
                                ";
            }
            // line 25
            yield "                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['item'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 26
        yield "                            </select>
                        </div>



                        <div class=\"col\">
                            <label class=\"visually-hidden\" for=\"autoSizingSelect\">Preference</label>
                            <select class=\"form-select form-select-lg select-mc\" id=\"specialty\">
                                <option value=\"\"> Specialty </option>
                                ";
        // line 35
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["specialties"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 36
            yield "                                <option value=";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "slug", [], "any", false, false, true, 36), 36, $this->source), "html", null, true);
            yield ">";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "name", [], "any", false, false, true, 36), 36, $this->source), "html", null, true);
            yield "</option>
                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['item'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 38
        yield "                            </select>
                        </div>

                        <div class=\"col\">
                            <label class=\"visually-hidden\" for=\"autoSizingSelect\">Preference</label>
                            <select class=\"form-select form-select-lg select-mc\" id=\"doctor\">
                                <option value=\"\">Doctor’s Name</option>
                                ";
        // line 45
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["doctors"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 46
            yield "                                <option value=";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 46), 46, $this->source), "html", null, true);
            yield "><span>
                                        ";
            // line 47
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "designation", [], "any", false, false, true, 47), 47, $this->source), "html", null, true);
            yield "
                                    </span>";
            // line 48
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "name", [], "any", false, false, true, 48), 48, $this->source), "html", null, true);
            yield "</option>
                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['item'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 50
        yield "                            </select>
                        </div>

                        <div class=\"col-12\">
                            <button class=\"btn btn-primary btn-mc-search mc-search mb-4 mb-sm-0 mx-auto\"><svg
                                    xmlns=\"http://www.w3.org/2000/svg\" width=\"49\" height=\"48\" viewBox=\"0 0 49 48\"
                                    fill=\"none\">
                                    <ellipse cx=\"24.2\" cy=\"23.716\" rx=\"24.2\" ry=\"23.716\" fill=\"white\" />
                                    <path
                                        d=\"M22.8362 15.7266C26.0961 15.7266 28.735 18.3655 28.735 21.6253C28.735 24.8852 26.0961 27.5241 22.8362 27.5241C19.5764 27.5241 16.9375 24.8852 16.9375 21.6253C16.9375 19.3279 18.2476 17.341 20.1663 16.3661M32.6675 31.4566L27.2225 26.0116\"
                                        stroke=\"#003868\" stroke-width=\"1.452\" stroke-miterlimit=\"10\"
                                        stroke-linecap=\"round\" stroke-linejoin=\"round\" />
                                </svg>Search</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- ======= BANNER END ======= -->





<!-- ======= OUR DOCTORS  START ======= -->
<section>
    <div class=\"container mt-5\">
        <div class=\"row\">
            <div class=\"col-12 text-center section-py-100 pt-0\">
                <h1 class=\"\">Our Doctors</h1>
            </div>
        </div>

        <div class=\"row\">

            ";
        // line 87
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["doctors"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 88
            yield "            <div class=\"col-12 col-sm-6 col-xl-4 col-xxl-3 mc-hide-2\">
                <div class=\"doctor-card\">
                    <a href=\"/doctor-detail/";
            // line 90
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 90), 90, $this->source), "html", null, true);
            yield "\">
                        <div class=\"doctor-img-001 text-center\">
                            <img src=\"";
            // line 92
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "doctor_image", [], "any", false, false, true, 92), "path", [], "any", false, false, true, 92), 92, $this->source), "html", null, true);
            yield "\" class=\"img-fluid\" alt=\"\" style=\"border-radius: 50%;\">
                        </div>
                    </a>

                    <a href=\"/doctor-detail/";
            // line 96
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 96), 96, $this->source), "html", null, true);
            yield "\" style=\"text-decoration: none;\">
                        <h3><span>";
            // line 97
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "designation", [], "any", false, false, true, 97), 97, $this->source), "html", null, true);
            yield "</span> ";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "name", [], "any", false, false, true, 97), 97, $this->source), "html", null, true);
            yield "</h3>
                    </a>

                    <div class=\"dr-specialities drspecialty-truncate my-3\">
                        <a href=\"/doctor-detail/";
            // line 101
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 101), 101, $this->source), "html", null, true);
            yield "\" style=\"text-decoration: none;\"
                            class=\"dr-specialities drspecialty-truncate\">";
            // line 102
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "specialty_desc", [], "any", false, false, true, 102), 102, $this->source), "html", null, true);
            yield "</a>
                    </div>

                    <div class=\"row hide\">
                        <div class=\"col-12 text-center\">
                            <p style=\"margin-bottom: 0px\"><a href=\"/doctor-detail/";
            // line 107
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 107), 107, $this->source), "html", null, true);
            yield "\"
                                    style=\"text-decoration: none; color: white;\">";
            // line 108
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "highest_degree", [], "any", false, false, true, 108), 108, $this->source), "html", null, true);
            yield "</a></p>
                        </div>
                    </div>


                    <div class=\"dr-calendar my-4\">
                        ";
            // line 114
            if (((($_v0 = ($context["availableDates"] ?? null)) && is_array($_v0) || $_v0 instanceof ArrayAccess ? ($_v0[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 114)] ?? null) : null) && (($_v1 = ($context["bookingLinks"] ?? null)) && is_array($_v1) || $_v1 instanceof ArrayAccess ? ($_v1[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 114)] ?? null) : null))) {
                // line 115
                yield "                        <div class=\"dr-calendar-text text-center\">
                            <p><strong>Earliest available appointment</strong></p>
                            <p style=\"font-size: 12px;\"><strong>";
                // line 117
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, (($_v2 = ($context["availableDates"] ?? null)) && is_array($_v2) || $_v2 instanceof ArrayAccess ? ($_v2[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 117)] ?? null) : null), "company_name", [], "any", false, false, true, 117), 117, $this->source), "html", null, true);
                yield "</strong></p>

                        </div>
                        <div class=\"dr-calendar-flex\">
                            <a class=\"dr-cale\">";
                // line 121
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Twig\Extension\CoreExtension']->formatDate($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, (($_v3 = ($context["availableDates"] ?? null)) && is_array($_v3) || $_v3 instanceof ArrayAccess ? ($_v3[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 121)] ?? null) : null), "latest_date", [], "any", false, false, true, 121), 121, $this->source), "j-M-Y"), "html", null, true);
                yield "</a>
                            <a class=\"dr-cale\">";
                // line 122
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Twig\Extension\CoreExtension']->formatDate($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, (($_v4 = ($context["availableDates"] ?? null)) && is_array($_v4) || $_v4 instanceof ArrayAccess ? ($_v4[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 122)] ?? null) : null), "latest_time", [], "any", false, false, true, 122), 122, $this->source), "h:i A"), "html", null, true);
                yield "</a>
                            <!-- <div class=\"slots\">";
                // line 123
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, (($_v5 = ($context["availableDates"] ?? null)) && is_array($_v5) || $_v5 instanceof ArrayAccess ? ($_v5[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 123)] ?? null) : null), "slots_available", [], "any", false, false, true, 123), 123, $this->source), "html", null, true);
                yield " Slots</div> -->
                        </div>
                        ";
            }
            // line 126
            yield "                    </div>

                    <div class=\"d-flex justify-content-around\">
                        <div class=\"";
            // line 129
            if ( !(($_v6 = ($context["bookingLinks"] ?? null)) && is_array($_v6) || $_v6 instanceof ArrayAccess ? ($_v6[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 129)] ?? null) : null)) {
                yield "w-100 mt-40";
            }
            yield "\">
                            <button href=\"javascript:void(0)\" onclick=\"GoLinks(event,'/doctor-detail/'+'";
            // line 130
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 130), 130, $this->source), "html", null, true);
            yield "')\"
                                class=\"btn btn-light btn-dr-card\">
                                Profile
                            </button>
                        </div>

                        &nbsp;
                        <div>
                            ";
            // line 138
            if (Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "isHaveAskUsSpecialty", [], "any", false, false, true, 138)) {
                // line 139
                yield "                            <a href=\"/contact-us\"
                                class=\"btn btn-dr-card-2 ";
                // line 140
                if ( !(($_v7 = ($context["bookingLinks"] ?? null)) && is_array($_v7) || $_v7 instanceof ArrayAccess ? ($_v7[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 140)] ?? null) : null)) {
                    yield "mt-40";
                }
                yield "\">
                                <svg width=\"28\" height=\"27\" viewBox=\"0 0 28 27\" fill=\"none\"
                                    xmlns=\"http://www.w3.org/2000/svg\">
                                    <ellipse cx=\"13.7306\" cy=\"13.7772\" rx=\"13.4181\" ry=\"13.1913\" fill=\"white\" />
                                    <path class=\"arr-cl\"
                                        d=\"M14.9238 10.2812L18.565 13.781L14.9238 17.2807M12.8722 13.781H18.463M8.36719 13.781H14.7408\"
                                        stroke=\"#003868\" stroke-width=\"2\" stroke-miterlimit=\"10\" stroke-linecap=\"round\"
                                        stroke-linejoin=\"round\" />
                                </svg>
                                Ask Us
                            </a>
                            ";
            } else {
                // line 152
                yield "                            ";
                if ((($_v8 = ($context["bookingLinks"] ?? null)) && is_array($_v8) || $_v8 instanceof ArrayAccess ? ($_v8[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 152)] ?? null) : null)) {
                    // line 153
                    yield "                            <button href=\"javascript:void(0)\" onclick=\"GoLinks(event, '";
                    yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed((($_v9 = ($context["bookingLinks"] ?? null)) && is_array($_v9) || $_v9 instanceof ArrayAccess ? ($_v9[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 153)] ?? null) : null), 153, $this->source), "html", null, true);
                    yield "')\"
                                class=\"btn btn-dr-card-2\">
                                <svg width=\"28\" height=\"27\" viewBox=\"0 0 28 27\" fill=\"none\"
                                    xmlns=\"http://www.w3.org/2000/svg\">
                                    <ellipse cx=\"13.7306\" cy=\"13.7772\" rx=\"13.4181\" ry=\"13.1913\" fill=\"white\" />
                                    <path class=\"arr-cl\"
                                        d=\"M14.9238 10.2812L18.565 13.781L14.9238 17.2807M12.8722 13.781H18.463M8.36719 13.781H14.7408\"
                                        stroke=\"#003868\" stroke-width=\"2\" stroke-miterlimit=\"10\" stroke-linecap=\"round\"
                                        stroke-linejoin=\"round\" />
                                </svg>
                                Book Now
                            </button>
                            ";
                } else {
                    // line 166
                    yield "                            <a href=\"https://bamc.myclinic.com.sa:8443\" 
                                class=\"btn btn-dr-card-2 ";
                    // line 167
                    if ( !(($_v10 = ($context["bookingLinks"] ?? null)) && is_array($_v10) || $_v10 instanceof ArrayAccess ? ($_v10[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 167)] ?? null) : null)) {
                        yield "mt-40";
                    }
                    yield "\">
                                <svg width=\"28\" height=\"27\" viewBox=\"0 0 28 27\" fill=\"none\"
                                    xmlns=\"http://www.w3.org/2000/svg\">
                                    <ellipse cx=\"13.7306\" cy=\"13.7772\" rx=\"13.4181\" ry=\"13.1913\" fill=\"white\" />
                                    <path class=\"arr-cl\"
                                        d=\"M14.9238 10.2812L18.565 13.781L14.9238 17.2807M12.8722 13.781H18.463M8.36719 13.781H14.7408\"
                                        stroke=\"#003868\" stroke-width=\"2\" stroke-miterlimit=\"10\" stroke-linecap=\"round\"
                                        stroke-linejoin=\"round\" />
                                </svg>
                                Book Now
                            </a>
                            ";
                }
                // line 179
                yield "                            ";
            }
            // line 180
            yield "                        </div>

                    </div>


                </div>
            </div>

            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['item'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 189
        yield "
            <div class=\"col-12 mt-3\">
                <a href=\"#\" class=\"btn btn-view-all btn-outline-dark view-more-dr\"><svg
                        xmlns=\"http://www.w3.org/2000/svg\" width=\"40\" height=\"40\" viewBox=\"0 0 40 40\" fill=\"none\">
                        <ellipse cx=\"20\" cy=\"19.6\" rx=\"20\" ry=\"19.6\" fill=\"#003868\" />
                        <path
                            d=\"M24.7969 21.7727L19.5969 27.2L14.3969 21.7727M19.5969 18.7148L19.5969 27.048M19.5969 12L19.5969 21.5\"
                            stroke=\"white\" stroke-width=\"2\" stroke-miterlimit=\"10\" stroke-linecap=\"round\"
                            stroke-linejoin=\"round\" />
                    </svg>View more doctors</a>
            </div>

        </div>

    </div>
</section>
<!-- ======= OUR DOCTORS END ======= -->

";
        // line 207
        $cmsPartialParams = [];
        yield $this->env->getExtension(\Cms\Twig\Extension::class)->partialFunction("components/appDownload"        , array_merge($context, ['__cms_partial_params' => $cmsPartialParams], $cmsPartialParams)        , true        );
        // line 208
        yield "

<script>
    document.getElementById('search-form').addEventListener('submit', function (e) {
        e.preventDefault();  // Prevent the default form submission

        // Get the user's input
        const specialty = document.getElementById('specialty').value;
        const doctor = document.getElementById('doctor').value;
        const location = document.getElementById('location').value;

        var detailPageURL = '';

        if (specialty && location) {
            detailPageURL = `/search-specialty/\${location}/\${specialty}`;

        } else {
            detailPageURL = (doctor) ? `/doctor-detail/\${doctor}` : (specialty) ? `/search-specialty/\${specialty}` : `/location-doctors/\${location}`;

        }
        // Determine the detail page URL based on the search type

        // Redirect to the appropriate detail page
        window.location.href = detailPageURL;
    });


    \$(document).ready(function () {
        \$('#specialty').change(function () {
            var countryId = \$(this).val();
            var location = document.getElementById('location').value;
            var doctor = document.getElementById('doctor').value;

            \$.ajax({
                url: '/specialty-doctors/' + countryId + '?location=' + location,
                type: 'GET',
                dataType: 'json',
                success: function (data) {
                    var statesSelect = \$('#doctor');
                    statesSelect.empty();
                    if (data.doctors.length) {
                        statesSelect.append('<option value=\"\"> Doctor </option>');
                        \$.each(data.doctors, function (key, state) {
                            var selected = (state.id == doctor) ? ' selected' : '';
                            statesSelect.append('<option value=\"' + state.id + '\"' + selected + '>' + state.designation + ' ' + state.name + '</option>');
                        });
                    } else {
                        statesSelect.append('<option value=\"\"> Doctor </option>');
                    }
                },
                error: function (jqXHR, textStatus, errorThrown) {
                    // Handle errors
                    console.error('API request failed:', textStatus, errorThrown);
                }
            });

        });

        \$('#location').change(function () {
            var countryId = \$(this).val();
            var specialty = document.getElementById('specialty').value;

            \$.ajax({
                url: '/location-specialties/' + countryId,
                type: 'GET',
                dataType: 'json',
                success: function (data) {
                    var statesSelect = \$('#specialty');
                    var doctorSelect = \$('#doctor');
                    var selectedSpecialtyDoctors = null;
                    statesSelect.empty();
                    if (data.specialties.length) {
                        statesSelect.append('<option value=\"\"> Specialty </option>');
                        \$.each(data.specialties, function (key, state) {
                            var selected = (state.slug === specialty) ? ' selected' : '';
                            selectedSpecialtyDoctors = (state.slug === specialty) ? state : null;
                            statesSelect.append('<option value=\"' + state.slug + '\"' + selected + '>' + state.name + '</option>');
                        });
                        \$('#specialty').change();

                    } else {
                        statesSelect.append('<option value=\"\"> Specialty </option>');
                    }

                    if (!selectedSpecialtyDoctors) {
                        doctorSelect.empty();
                        doctorSelect.append('<option value=\"\"> Doctor </option>');
                    }


                },
                error: function (jqXHR, textStatus, errorThrown) {
                    // Handle errors
                    console.error('API request failed:', textStatus, errorThrown);
                }
            });

        });
    });

    function GoLinks(event, bookingLink) {
        event.preventDefault();

        // If the booking link is not found (empty), redirect to the external site
        if (!bookingLink || bookingLink === '') {
            window.location.href = 'https://bamc.myclinic.com.sa:8443';
        } else {
            window.location.href = bookingLink;
        }
    }

</script>";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "C:\\xampp\\htdocs\\myclinic\\themes/myclinic/pages/location-doctors.htm";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  406 => 208,  403 => 207,  383 => 189,  369 => 180,  366 => 179,  349 => 167,  346 => 166,  329 => 153,  326 => 152,  309 => 140,  306 => 139,  304 => 138,  293 => 130,  287 => 129,  282 => 126,  276 => 123,  272 => 122,  268 => 121,  261 => 117,  257 => 115,  255 => 114,  246 => 108,  242 => 107,  234 => 102,  230 => 101,  221 => 97,  217 => 96,  210 => 92,  205 => 90,  201 => 88,  197 => 87,  158 => 50,  150 => 48,  146 => 47,  141 => 46,  137 => 45,  128 => 38,  117 => 36,  113 => 35,  102 => 26,  96 => 25,  88 => 23,  80 => 21,  77 => 20,  73 => 19,  64 => 13,  60 => 12,  52 => 7,  44 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "C:\\xampp\\htdocs\\myclinic\\themes/myclinic/pages/location-doctors.htm", "");
    }
    
    public function checkSecurity()
    {
        static $tags = ["for" => 19, "if" => 20, "partial" => 207];
        static $filters = ["escape" => 7, "date" => 121];
        static $functions = [];

        try {
            $this->sandbox->checkSecurity(
                ['for', 'if', 'partial'],
                ['escape', 'date'],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
