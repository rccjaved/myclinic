<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* C:\xampp\htdocs\myclinic\themes/myclinic/pages/doctor-detail.htm */
class __TwigTemplate_678d9308d9913503f0e8fb0873029f83 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield "<!-- ======= BANNER START ======= -->
<section class=\"doctor-detail-bg detail-padding pb-0\">
    <div class=\"container\">
        <div class=\"row align-items-center\">
            <div class=\"col-12 col-sm-6\">
                <img src=\"";
        // line 6
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["doctor"] ?? null), "doctor_detail_image", [], "any", false, false, true, 6), "path", [], "any", false, false, true, 6), 6, $this->source), "html", null, true);
        yield "\" class=\"img-fluid doc-img-detail\" alt=\"";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["doctor"] ?? null), "name", [], "any", false, false, true, 6), 6, $this->source), "html", null, true);
        yield "\">
            </div>
            <div class=\"col-12 col-sm-6\">
                <div class=\"description-wrap\">
                    ";
        // line 10
        if (Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["doctor"] ?? null), "designation", [], "any", false, false, true, 10)) {
            // line 11
            yield "                        <h1 class=\"pt-3 pt-md-0\">
                            <span>";
            // line 12
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["doctor"] ?? null), "designation", [], "any", false, false, true, 12), 12, $this->source), "html", null, true);
            yield "</span>&nbsp;";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["doctor"] ?? null), "name", [], "any", false, false, true, 12), 12, $this->source), "html", null, true);
            yield "
                        </h1>
                    ";
        } else {
            // line 15
            yield "                        <h1 class=\"pt-3 pt-md-0\">";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["doctor"] ?? null), "name", [], "any", false, false, true, 15), 15, $this->source), "html", null, true);
            yield "</h1>
                    ";
        }
        // line 17
        yield "                    <p class=\"doc-specialty\">";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["doctor"] ?? null), "specialty_desc", [], "any", false, false, true, 17), 17, $this->source), "html", null, true);
        yield "</p>

                    <div class=\"edu-wrap\">
                        <div class=\"edu-tag\">Education</div>
                        <h2>";
        // line 21
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["doctor"] ?? null), "highest_degree", [], "any", false, false, true, 21), 21, $this->source), "html", null, true);
        yield "</h2>
                    </div>

                    <ul class=\"dr-pro-list dr-pro-list-en\">
                        <li>Location : <span class=\"fw-light\">";
        // line 25
        yield $this->sandbox->ensureToStringAllowed(($context["doctor_locations"] ?? null), 25, $this->source);
        yield "</span></li>
                        <li>Languages : <span class=\"fw-light\">";
        // line 26
        yield $this->sandbox->ensureToStringAllowed(($context["doctor_language"] ?? null), 26, $this->source);
        yield "</span> </li>
                    </ul>
                    ";
        // line 28
        if (($context["isButtonVisible"] ?? null)) {
            // line 29
            yield "                        ";
            if (($context["isBookNow"] ?? null)) {
                // line 30
                yield "                        ";
                if ((($_v0 = ($context["bookingLinks"] ?? null)) && is_array($_v0) || $_v0 instanceof ArrayAccess ? ($_v0[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["doctor"] ?? null), "doctor_app_id", [], "any", false, false, true, 30)] ?? null) : null)) {
                    // line 31
                    yield "                        <a href=\"";
                    yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed((($_v1 = ($context["bookingLinks"] ?? null)) && is_array($_v1) || $_v1 instanceof ArrayAccess ? ($_v1[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["doctor"] ?? null), "doctor_app_id", [], "any", false, false, true, 31)] ?? null) : null), 31, $this->source), "html", null, true);
                    yield "\"class=\"btn btn-primary btn-mc-01\"><svg
                            xmlns=\"http://www.w3.org/2000/svg\" width=\"40\" height=\"40\" viewBox=\"0 0 40 40\" fill=\"none\">
                            <ellipse cx=\"20\" cy=\"19.6\" rx=\"20\" ry=\"19.6\" fill=\"white\" />
                            <path
                                d=\"M21.7727 14.3984L27.2 19.5984L21.7727 24.7984M18.7148 19.5984H27.048M12 19.5984H21.5\"
                                stroke=\"#003868\" stroke-width=\"2\" stroke-miterlimit=\"10\" stroke-linecap=\"round\"
                                stroke-linejoin=\"round\" />
                        </svg>Book Now</a>
                        ";
                } else {
                    // line 40
                    yield "                                <a href=\"https://bamc.myclinic.com.sa:8443\"
                                     class=\"btn btn-primary btn-mc-01\">
                                    <svg width=\"28\" height=\"27\" viewBox=\"0 0 28 27\" fill=\"none\"
                                        xmlns=\"http://www.w3.org/2000/svg\">
                                        <ellipse cx=\"13.7306\" cy=\"13.7772\" rx=\"13.4181\" ry=\"13.1913\" fill=\"white\" />
                                        <path class=\"arr-cl\"
                                            d=\"M14.9238 10.2812L18.565 13.781L14.9238 17.2807M12.8722 13.781H18.463M8.36719 13.781H14.7408\"
                                            stroke=\"#003868\" stroke-width=\"2\" stroke-miterlimit=\"10\"
                                            stroke-linecap=\"round\" stroke-linejoin=\"round\" />
                                    </svg>
                                    Book Now
                                </a>
                        ";
                }
                // line 53
                yield "                        ";
            } else {
                // line 54
                yield "                        <a href=\"/contact-us\" class=\"btn btn-primary btn-mc-01\"><svg
                            xmlns=\"http://www.w3.org/2000/svg\" width=\"40\" height=\"40\" viewBox=\"0 0 40 40\" fill=\"none\">
                            <ellipse cx=\"20\" cy=\"19.6\" rx=\"20\" ry=\"19.6\" fill=\"white\" />
                            <path
                                d=\"M21.7727 14.3984L27.2 19.5984L21.7727 24.7984M18.7148 19.5984H27.048M12 19.5984H21.5\"
                                stroke=\"#003868\" stroke-width=\"2\" stroke-miterlimit=\"10\" stroke-linecap=\"round\"
                                stroke-linejoin=\"round\" />
                        </svg>Ask Us</a>
                        ";
            }
            // line 63
            yield "                    ";
        }
        // line 64
        yield "                </div>
            </div>
        </div>
    </div>
    <img class=\"img-doc-background-tec\" src=\"";
        // line 68
        yield $this->extensions['Cms\Twig\Extension']->themeFilter("assets/imgs/ask-us.png");
        yield "\">
</section>
<!-- ======= BANNER END ======= -->

";
        // line 72
        $cmsPartialParams = [];
        $cmsPartialParams['testimonials'] = ($context["testimonials"] ?? null)        ;
        yield $this->env->getExtension(\Cms\Twig\Extension::class)->partialFunction("components/testimonial"        , array_merge($context, ['__cms_partial_params' => $cmsPartialParams], $cmsPartialParams)        , true        );
        // line 73
        yield "
<!-- ======= OUR DOCTORS START ======= -->
<section class=\"section-py-120\">
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-12 text-center py-60 pt-0\">
                <h1 class=\"\">Similar Doctors</h1>
            </div>
        </div>
        <div class=\"row similar-doctors-container\">
            ";
        // line 83
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["similar_doctor"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 84
            yield "            <div class=\"col-12 col-sm-6 col-xl-4 col-xxl-3 mc-hide-2\">
                <div class=\"doctor-card\">
                    <div class=\"doctor-img-2 text-center\">
                        <img src=\"";
            // line 87
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "doctor_image", [], "any", false, false, true, 87), "path", [], "any", false, false, true, 87), 87, $this->source), "html", null, true);
            yield "\" class=\"img-fluid\" alt=\"\" style=\"border-radius: 50%;\">
                    </div>
                    <h3><span>";
            // line 89
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "designation", [], "any", false, false, true, 89), 89, $this->source), "html", null, true);
            yield "</span>&nbsp;";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "name", [], "any", false, false, true, 89), 89, $this->source), "html", null, true);
            yield "</h3>
                    <div class=\"dr-specialities\">";
            // line 90
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "specialty_desc", [], "any", false, false, true, 90), 90, $this->source), "html", null, true);
            yield "</div>

                    <div class=\"row hide\">
                        <div class=\"col-12 text-center\">
                            <p style=\"margin-bottom: -20px;\">
                                <a href=\"/doctor-detail/";
            // line 95
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 95), 95, $this->source), "html", null, true);
            yield "\" style=\"text-decoration: none; color: white;\">";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "highest_degree", [], "any", false, false, true, 95), 95, $this->source), "html", null, true);
            yield "</a>
                            </p><br>
                           
                        </div>
                    </div>
                
                    <div class=\"dr-calendar my-4\" id=\"doctor-availability-";
            // line 101
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 101), 101, $this->source), "html", null, true);
            yield "\">
                        <!-- This will be loaded via AJAX -->
                        <div class=\"loading-spinner text-center py-3\">
                            <div class=\"spinner-border text-primary\" role=\"status\">
                                <span class=\"sr-only\">Loading...</span>
                            </div>
                        </div>
                    </div>
                
                    <div class=\"d-flex justify-content-around\">
                        <div class=\"w-100 mt-50\">
                            <a href=\"/doctor-detail/";
            // line 112
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 112), 112, $this->source), "html", null, true);
            yield "\" class=\"btn btn-light btn-dr-card w-100\">Profile</a>
                        </div>
                    </div>
                </div>
            </div>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['item'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 118
        yield "            <div class=\"col-12 mt-3\">
                <a href=\"#\" class=\"btn btn-view-all btn-outline-dark view-more-dr\"><svg
                        xmlns=\"http://www.w3.org/2000/svg\" width=\"40\" height=\"40\" viewBox=\"0 0 40 40\" fill=\"none\">
                        <ellipse cx=\"20\" cy=\"19.6\" rx=\"20\" ry=\"19.6\" fill=\"#003868\" />
                        <path
                            d=\"M24.7969 21.7727L19.5969 27.2L14.3969 21.7727M19.5969 18.7148L19.5969 27.048M19.5969 12L19.5969 21.5\"
                            stroke=\"white\" stroke-width=\"2\" stroke-miterlimit=\"10\" stroke-linecap=\"round\"
                            stroke-linejoin=\"round\" />
                    </svg>View more doctors</a>
            </div>
        </div>
    </div>
</section>
<!-- ======= OUR DOCTORS END ======= -->

<style>
.loading-spinner {
    min-height: 120px;
    display: flex;
    align-items: center;
    justify-content: center;
}

.spinner-border {
    width: 2rem;
    height: 2rem;
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Get all similar doctor cards
    const doctorCards = document.querySelectorAll('.similar-doctors-container .doctor-card');
    
    // Load availability for each doctor with a delay
    doctorCards.forEach((card, index) => {
        const doctorId = card.querySelector('.dr-calendar').id.replace('doctor-availability-', '');
        
        // Set a timeout with increasing delay (e.g., 500ms between each request)
        setTimeout(() => {
            fetchAvailability(doctorId);
        }, index * 500);
    });
    
    function fetchAvailability(doctorId) {
        const container = document.getElementById('doctor-availability-' + doctorId);
        
        fetch(window.location.href, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-Requested-With': 'XMLHttpRequest',
                'X-OCTOBER-REQUEST-HANDLER': 'onSimilarDoctorsAvailability',
                'X-OCTOBER-REQUEST-PARTIALS': ''
            },
            body: JSON.stringify({
                doctor_id: doctorId
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.availableDates) {
                const date = new Date(data.availableDates.latest_date.date);
                const time = data.availableDates.latest_time;
                
                // Format the time to 12-hour format
                const timeParts = time.split(':');
                let hours = parseInt(timeParts[0]);
                const minutes = timeParts[1];
                const ampm = hours >= 12 ? 'PM' : 'AM';
                hours = hours % 12;
                hours = hours ? hours : 12; // the hour '0' should be '12'
                const formattedTime = hours + ':' + minutes + ' ' + ampm;
                
                // Format the date (e.g., \"15-Jan-2023\")
                const formattedDate = date.toLocaleDateString('en-US', {
                    day: 'numeric',
                    month: 'short',
                    year: 'numeric'
                }).replace(/,/g, '');
                
                container.innerHTML = `
                    <div class=\"dr-calendar-text text-center\">
                        <p><strong>Earliest available appointment</strong></p>
                        <p style=\"font-size: 12px;\"><strong>\${data.availableDates.company_name}</strong></p>
                    </div>
                    <div class=\"dr-calendar-flex\">
                        <a class=\"dr-cale\">\${formattedDate}</a>
                        <a class=\"dr-cale\">\${formattedTime}</a>
                    </div>
                `;
                
                // Add the Book Now button
                const buttonsContainer = container.closest('.doctor-card').querySelector('.d-flex.justify-content-around');
                buttonsContainer.innerHTML = `
                    <div>
                        <a href=\"/doctor-detail/\${doctorId}\" class=\"btn btn-light btn-dr-card\">Profile</a>
                    </div>
                    <div>
                        <a href=\"\${data.bookingLink}\" class=\"btn btn-dr-card-2\">
                            <svg width=\"28\" height=\"27\" viewBox=\"0 0 28 27\" fill=\"none\"
                                        xmlns=\"http://www.w3.org/2000/svg\">
                                        <ellipse cx=\"13.7306\" cy=\"13.7772\" rx=\"13.4181\" ry=\"13.1913\" fill=\"white\" />
                                        <path class=\"arr-cl\"
                                            d=\"M14.9238 10.2812L18.565 13.781L14.9238 17.2807M12.8722 13.781H18.463M8.36719 13.781H14.7408\"
                                            stroke=\"#003868\" stroke-width=\"2\" stroke-miterlimit=\"10\"
                                            stroke-linecap=\"round\" stroke-linejoin=\"round\" />
                                    </svg>Book Now</a>
                    </div>
                `;
            } else {
                container.innerHTML = '<p class=\"text-center\"></p>';
                // Update buttons container if no availability
                const buttonsContainer = container.closest('.doctor-card').querySelector('.d-flex.justify-content-around');
                buttonsContainer.innerHTML = `
                    <div class=\"w-100 mt-50\">
                        <a href=\"/doctor-detail/\${doctorId}\" class=\"btn btn-light btn-dr-card w-100\">Profile</a>
                    </div>
                `;
            }
        })
        .catch(error => {
            console.error('Error fetching availability:', error);
            container.innerHTML = '<p class=\"text-center py-3\">Error loading availability</p>';
        });
    }
});
</script>";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "C:\\xampp\\htdocs\\myclinic\\themes/myclinic/pages/doctor-detail.htm";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  250 => 118,  238 => 112,  224 => 101,  213 => 95,  205 => 90,  199 => 89,  194 => 87,  189 => 84,  185 => 83,  173 => 73,  169 => 72,  162 => 68,  156 => 64,  153 => 63,  142 => 54,  139 => 53,  124 => 40,  111 => 31,  108 => 30,  105 => 29,  103 => 28,  98 => 26,  94 => 25,  87 => 21,  79 => 17,  73 => 15,  65 => 12,  62 => 11,  60 => 10,  51 => 6,  44 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "C:\\xampp\\htdocs\\myclinic\\themes/myclinic/pages/doctor-detail.htm", "");
    }
    
    public function checkSecurity()
    {
        static $tags = ["if" => 10, "partial" => 72, "for" => 83];
        static $filters = ["escape" => 6, "raw" => 25, "theme" => 68];
        static $functions = [];

        try {
            $this->sandbox->checkSecurity(
                ['if', 'partial', 'for'],
                ['escape', 'raw', 'theme'],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
