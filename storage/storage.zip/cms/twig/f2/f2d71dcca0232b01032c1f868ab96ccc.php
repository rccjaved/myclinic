<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* C:\xampp\htdocs\myclinic\themes/myclinic/partials/site/script.htm */
class __TwigTemplate_c5863de5abeee007e9882257e4a254cc extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield "<!-- Bootstrap JavaScript Libraries -->

<script src=\"";
        // line 3
        yield $this->extensions['Cms\Twig\Extension']->themeFilter("assets/vendors/bootstrap/js/bootstrap.js");
        yield "\"></script>
<script src=\"";
        // line 4
        yield $this->extensions['Cms\Twig\Extension']->themeFilter("assets/vendors/bootstrap/js/bootstrap.min.js");
        yield "\"></script>
<script src=\"";
        // line 5
        yield $this->extensions['Cms\Twig\Extension']->themeFilter("assets/vendors/bootstrap/js/bootstrap.bundle.min.js");
        yield "\"></script>
<script src=\"";
        // line 6
        yield $this->extensions['Cms\Twig\Extension']->themeFilter("assets/vendors/slick/slick.js");
        yield "\"></script>
<script src=\"";
        // line 7
        yield $this->extensions['Cms\Twig\Extension']->themeFilter("assets/js/custom.js");
        yield "\"></script>
<script src=\"";
        // line 8
        yield $this->extensions['Cms\Twig\Extension']->themeFilter("assets/vendors/select2/select2.js");
        yield "\"></script>

<script>
    var btn = \$('#topbutton');

    \$(window).scroll(function () {
        if (\$(window).scrollTop() > 300) {
            btn.addClass('show');
        } else {
            btn.removeClass('show');
        }
    });

    btn.on('click', function (e) {
        e.preventDefault();
        \$('html, body').animate({ scrollTop: 0 }, '300');
    });
</script>

<script>
\$(document).ready(function() {
  var topOfDivScroll = \$(\".grecaptcha-badge\").offset().top - \$(window).height();

  \$(window).scroll(function() {
    if (\$(window).scrollTop() > topOfDivScroll) {
      \$(\".grecaptcha-badge\").hide();
    } else \$(\".grecaptcha-badge\").show();
  });
});
</script>

<script>
\$(document).ready(function() {
  var topOfDivScroll = \$(\".mxg-launcher-btn\").offset().top - \$(window).height();

  \$(window).scroll(function() {
    if (\$(window).scrollTop() > topOfDivScroll) {
      \$(\".mxg-launcher-btn\").hide();
    } else \$(\".mxg-launcher-btn\").show();
  });
});
</script>



<script>

    window.onload = function () {
        mybuttons.style.display = \"none\";
    }
    // Get the button
    var mybuttons = document.getElementById(\"floatmenu\");

    // When the user scrolls down 20px from the top of the document, show the button
    window.onscroll = function () { scrollFunction() };

    function scrollFunction() {
        if (document.body.scrollTop > 500 || document.documentElement.scrollTop > 500) {
            mybuttons.style.display = \"block\";
        } else {
            mybuttons.style.display = \"none\";
        }
    }

</script>
<script>
    \$(document).ready(function () {
        \$(\".js-example-basic-multiple\").select2();
    });
</script>

<!-- Google tag (gtag.js) -->
<script async src=\"https://www.googletagmanager.com/gtag/js?id=G-VPTGK9K2TQ\"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-VPTGK9K2TQ');
</script>

";
        // line 89
        $_minify = System\Classes\CombineAssets::instance()->useMinify;
        yield '<script src="' . Request::getBasePath() . '/modules/system/assets/js/framework-extras'.($_minify ? '.min' : '').'.js"></script>'.PHP_EOL;
        yield '<link rel="stylesheet" property="stylesheet" href="' . Request::getBasePath() .'/modules/system/assets/css/framework-extras.css">'.PHP_EOL;
        unset($_minify);
        // line 90
        yield $this->env->getExtension(\Cms\Twig\Extension::class)->assetsFunction('js');
        yield $this->env->getExtension(\Cms\Twig\Extension::class)->displayBlock('scripts');
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "C:\\xampp\\htdocs\\myclinic\\themes/myclinic/partials/site/script.htm";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  157 => 90,  152 => 89,  68 => 8,  64 => 7,  60 => 6,  56 => 5,  52 => 4,  48 => 3,  44 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "C:\\xampp\\htdocs\\myclinic\\themes/myclinic/partials/site/script.htm", "");
    }
    
    public function checkSecurity()
    {
        static $tags = ["framework" => 89, "scripts" => 90];
        static $filters = ["theme" => 3];
        static $functions = [];

        try {
            $this->sandbox->checkSecurity(
                ['framework', 'scripts'],
                ['theme'],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
