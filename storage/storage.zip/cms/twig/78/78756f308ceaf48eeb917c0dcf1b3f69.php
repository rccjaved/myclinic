<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* C:\xampp\htdocs\myclinic\themes/myclinic/partials/site/header.htm */
class __TwigTemplate_8e57c8dc425d031d126ff12059c906a3 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield "<!-- ======= HEADER START ======= -->
<header>
  <!-- Google Tag Manager -->
  <script>(function (w, d, s, l, i) {
      w[l] = w[l] || []; w[l].push({
        'gtm.start':
          new Date().getTime(), event: 'gtm.js'
      }); var f = d.getElementsByTagName(s)[0],
        j = d.createElement(s), dl = l != 'dataLayer' ? '&l=' + l : ''; j.async = true; j.src =
          'https://www.googletagmanager.com/gtm.js?id=' + i + dl; f.parentNode.insertBefore(j, f);
    })(window, document, 'script', 'dataLayer', 'GTM-NHS8GLVG');</script>
  <!-- End Google Tag Manager -->
  <nav class=\"navbar bg-navy navbar-expand-xxl navbar-dark\">
    <div class=\"container px-xxl-0 position-relative full-container\">
      <a href=\"/\" class=\"navbar-brand p-0 order-last order-md-first\"><img src=\"";
        // line 15
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["headerLogo"] ?? null), "section_image", [], "any", false, false, true, 15), "path", [], "any", false, false, true, 15), 15, $this->source), "html", null, true);
        yield "\"
          class=\"img-fluid nav-logo\" alt=\"navigation button\"></a>
      <button class=\"navbar-toggler\" type=\"button\" data-bs-toggle=\"offcanvas\" data-bs-target=\"#navbarOffcanvas\"
        aria-controls=\"navbarOffcanvas\" aria-expanded=\"false\" aria-label=\"Toggle navigation\">
        <span class=\"navbar-toggler-icon\"></span>
      </button>
      <!-- Expand search bar-->
      <div class=\"search-container-wrap  search-container-wrap-mobile\">
        <form action=\"/search\" method=\"get\">
          <input class=\"search-expand expandright\" id=\"searchright\" type=\"search\" name=\"q\" placeholder=\"Search\">
          <label class=\"button-search searchbutton\" for=\"searchright\"><span class=\"mglass\">&#9906;</span></label>
        </form>
      </div>
      <!-- Expand search bar end-->

      <div class=\"offcanvas offcanvas-end bg-navy\" id=\"navbarOffcanvas\" tabindex=\"-1\"
        aria-labelledby=\"offcanvasNavbarLabel\">
        <div class=\"offcanvas-header mt-4\">
          <button type=\"button\" class=\"btn-close btn-close-white text-reset\" data-bs-dismiss=\"offcanvas\"
            aria-label=\"Close\"></button>


        </div>
        <div class=\"offcanvas-body\">
          <div class=\"navbar-nav justify-content-center flex-grow-1 align-items-center\">
            <a href=\"/\" class=\"nav-item nav-link d-lg-none d-block\"><img src=\"";
        // line 40
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["headerLogo"] ?? null), "section_image", [], "any", false, false, true, 40), "path", [], "any", false, false, true, 40), 40, $this->source), "html", null, true);
        yield "\"
                class=\"img-fluid nav-logo-m\" width=\"150px\" alt=\"my clinic logo\"></a>
            <a class=\"nav-item nav-link d-lg-none d-block\" href=\"/\">Home</a>
            ";
        // line 43
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["headerLinks"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 44
            yield "            <a class=\"nav-item nav-link\" href=\"/";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "link_value", [], "any", false, false, true, 44), 44, $this->source), "html", null, true);
            yield "\">";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "link_name", [], "any", false, false, true, 44), 44, $this->source), "html", null, true);
            yield "</a>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['item'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 46
        yield "            <hr class=\"d-block d-xl-none\">
          </div>

          <div class=\"navbar-nav justify-content-center flex-grow-1 align-items-center\">
            ";
        // line 50
        if (($context["headerPhones"] ?? null)) {
            // line 51
            yield "            <a style=\"text-decoration: none; color: #fff; margin-right: 20px; padding: 15px;\" href=\"tel:";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["headerPhones"] ?? null), "link_value", [], "any", false, false, true, 51), 51, $this->source), "html", null, true);
            yield "\">
              <img src=\"";
            // line 52
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["headerPhones"] ?? null), "section_image", [], "any", false, false, true, 52), "path", [], "any", false, false, true, 52), 52, $this->source), "html", null, true);
            yield "\" class=\"img-fluid me-3\" alt=\"header-phone\"> ";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source,             // line 53
($context["headerPhones"] ?? null), "link_name", [], "any", false, false, true, 53), 53, $this->source), "html", null, true);
            yield "</a>
            ";
        }
        // line 55
        yield "          </div>
          
          <div class=\"navbar-nav justify-content-end ps-lg-3 align-items-center\">
            <a class=\"btn btn-light btn-book-now my-auto book-now-button\" href=\"https://bamc.myclinic.com.sa:8443\">Book
              Now
            </a>
            <!-- Dropdown  language-->
            <div class=\"btn-group flag-dropdown mt-3 mt-lg-0\">
              <a class=\"dropdown-toggle\" type=\"button\" data-bs-toggle=\"dropdown\" aria-expanded=\"false\">
                EN
              </a>
              <ul class=\"dropdown-menu dropdown-menu-lg-end\">
                <li>
                  <a class=\"dropdown-item\">
                    EN
                    <svg id=\"Layer_1\" enable-background=\"new 0 0 24 24\" height=\"512\" viewBox=\"0 0 24 24\" width=\"512\"
                      xmlns=\"http://www.w3.org/2000/svg\">
                      <switch>
                        <g>
                          <path
                            d=\"m9.8 18c-.3 0-.5-.1-.7-.3l-4.9-5.2c-.4-.4-.4-1 0-1.4s1-.4 1.4 0l4.1 4.4 8.4-9.2c.3-.4 1-.5 1.4-.2s.5 1 .2 1.4l-.1.1-9.1 10c-.1.3-.4.4-.7.4z\"
                            fill=\"#02bc7d\" />
                        </g>
                      </switch>
                    </svg>
                  </a>
                </li>
                <li>
                  <hr class=\"dropdown-divider mb-0 w-100\" />
                </li>
                <li>
                  <a class=\"dropdown-item\" href=\"/change-to/ar\">
                    AR
                  </a>
                </li>
              </ul>
            </div>
            <!-- Dropdown  language end-->
          </div>
        </div>
      </div>
    </div>
  </nav>
</header>
<!-- ======= HEADER END ======= -->";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "C:\\xampp\\htdocs\\myclinic\\themes/myclinic/partials/site/header.htm";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  130 => 55,  125 => 53,  122 => 52,  117 => 51,  115 => 50,  109 => 46,  98 => 44,  94 => 43,  88 => 40,  60 => 15,  44 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "C:\\xampp\\htdocs\\myclinic\\themes/myclinic/partials/site/header.htm", "");
    }
    
    public function checkSecurity()
    {
        static $tags = ["for" => 43, "if" => 50];
        static $filters = ["escape" => 15];
        static $functions = [];

        try {
            $this->sandbox->checkSecurity(
                ['for', 'if'],
                ['escape'],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
