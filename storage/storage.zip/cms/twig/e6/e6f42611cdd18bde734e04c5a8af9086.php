<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* C:\xampp\htdocs\myclinic\themes/myclinic/partials/components/planAndPromotions.htm */
class __TwigTemplate_44c0625b288f9726b14f455cb52ca6da extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        $context["records"] = Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["builderList"] ?? null), "records", [], "any", false, false, true, 1);
        // line 2
        yield "

<!--offer section area-->
<section class=\"d-none\">

    <div class=\"container section-py-100\">
        <div class=\"row py-60 pt-0\">

            <div class=\"col-12 col-sm-6 col-lg-6 py-60 pt-0 \">
                <h1 class=\"mt-4 mt-sm-0 text-justy\">";
        // line 11
        yield $this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["planText"] ?? null), "title", [], "any", false, false, true, 11), 11, $this->source);
        yield "</h1>

            </div>
            <div class=\"offset-sm-1 col-12 col-sm-5\">
                <p class=\"text-justy\">";
        // line 15
        yield $this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["planText"] ?? null), "description", [], "any", false, false, true, 15), 15, $this->source);
        yield "</p>
                <a class=\"btn btn-primary btn-mc-01 mb-3 margin-0-auto\" href=\"/all-packages\"><svg
                        xmlns=\"http://www.w3.org/2000/svg\" width=\"40\" height=\"40\" viewBox=\"0 0 40 40\" fill=\"none\"
                        style=\"margin-right: 12px;\">
                        <ellipse cx=\"20\" cy=\"19.6\" rx=\"20\" ry=\"19.6\" fill=\"white\" />
                        <path d=\"M21.7727 14.3984L27.2 19.5984L21.7727 24.7984M27.048 19.5984H18.7148H12\"
                            stroke=\"#003868\" stroke-width=\"2\" stroke-miterlimit=\"10\" stroke-linecap=\"round\"
                            stroke-linejoin=\"round\" />
                    </svg>Learn More</a>
            </div>

        </div>
        <div class=\"row\">
            <div class=\"col-12\">
                <div class=\"offer-tabs\">
                    <div class=\"offerslide mc-plans tab-pane fade show\" id=\"SOLUTIONS\">

                        ";
        // line 32
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["records"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 33
            yield "                        <div class=\"offerItem\">
                            <h4 class=\"offerItemTitle \"
                                style=\"background-image: url(";
            // line 35
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "promotion_image", [], "any", false, false, true, 35), "path", [], "any", false, false, true, 35), 35, $this->source), "html", null, true);
            yield ");background-repeat: no-repeat;background-size: cover;\">
                                ";
            // line 36
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "name", [], "any", false, false, true, 36), 36, $this->source), "html", null, true);
            yield "</h4>
                            <div class=\"offer-detail\">
                                <div class=\"row\">
                                    <div class=\"col-12\">
                                        <div class=\"offer-content\">
                                            <h2 class=\"plan-title\">";
            // line 41
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "name", [], "any", false, false, true, 41), 41, $this->source), "html", null, true);
            yield "</h2>
                                            <div class=\"row gx-5\">
                                                <div class=\"col-12\">
                                                    <ul class=\"list-unstyled plan-list list-unstyled-dynamic\">
                                                        ";
            // line 45
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "promotionItems", [], "any", false, false, true, 45));
            foreach ($context['_seq'] as $context["_key"] => $context["promotionItems"]) {
                // line 46
                yield "                                                        <li>
                                                            <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"45\"
                                                                height=\"25\" viewBox=\"0 0 25 25\" fill=\"none\"
                                                                class=\"me-3\">
                                                                <path
                                                                    d=\"M7.89844 13.3638L10.7177 15.9469L18.2484 9.04688\"
                                                                    stroke=\"#003868\" stroke-width=\"1.5\"
                                                                    stroke-linecap=\"round\" stroke-linejoin=\"round\" />
                                                                <path
                                                                    d=\"M3.3 5.6C1.8625 7.5205 1 9.9125 1 12.5C1 18.848 6.152 24 12.5 24C18.848 24 24 18.848 24 12.5C24 6.152 18.848 1 12.5 1C10.8555 1 9.28 1.345 7.8655 1.9775\"
                                                                    stroke=\"#003868\" stroke-width=\"1.5\"
                                                                    stroke-linecap=\"round\" stroke-linejoin=\"round\" />
                                                            </svg>";
                // line 58
                yield $this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["promotionItems"], "text", [], "any", false, false, true, 58), 58, $this->source);
                yield "
                                                        </li>
                                                        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['promotionItems'], $context['_parent']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 61
            yield "                                                    </ul>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['item'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 71
        yield "
                    </div>

                </div>
            </div>
        </div>
    </div>
</section>
<!--offer section area end-->

<script>
    jQuery(\".accordion-plan-cell\").click(function () {
        if (jQuery(this).hasClass(\"collapsed1\")) {
            jQuery(this).removeClass(\"collapsed1\");
            jQuery(this).siblings().removeClass(\"expanded1\");
            jQuery(this).addClass(\"expanded1\");
            jQuery(this).siblings().addClass(\"collapsed1\");
        } else {
            jQuery(this).toggleClass(\"expanded1\");
            jQuery(this).siblings().toggleClass(\"collapsed1\");
        }
    });
</script>

<script>
    \$(document).ready(function () {
        \$(\".offerItemTitle\").click(function () {
            \$(this)
                .parents(\".offerslide\")
                .children(\".offerItem\")
                .removeClass(\"active\");
            \$(this)
                .parents(\".offerslide\")
                .children(\".offerItem\")
                .children(\".offerItemTitle\")
                .removeClass(\"hide\");
            \$(this).parent(\".offerItem\").addClass(\"active\");
            \$(this).addClass(\"hide\");
        });
    });
</script>";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "C:\\xampp\\htdocs\\myclinic\\themes/myclinic/partials/components/planAndPromotions.htm";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  153 => 71,  138 => 61,  129 => 58,  115 => 46,  111 => 45,  104 => 41,  96 => 36,  92 => 35,  88 => 33,  84 => 32,  64 => 15,  57 => 11,  46 => 2,  44 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "C:\\xampp\\htdocs\\myclinic\\themes/myclinic/partials/components/planAndPromotions.htm", "");
    }
    
    public function checkSecurity()
    {
        static $tags = ["set" => 1, "for" => 32];
        static $filters = ["raw" => 11, "escape" => 35];
        static $functions = [];

        try {
            $this->sandbox->checkSecurity(
                ['set', 'for'],
                ['raw', 'escape'],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
