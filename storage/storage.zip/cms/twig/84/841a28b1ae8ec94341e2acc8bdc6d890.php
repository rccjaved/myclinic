<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* C:\xampp\htdocs\myclinic\themes/myclinic/partials/site/footer.htm */
class __TwigTemplate_b322bb96e1b61521a8342de7e4752b89 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield "<!-- ======= Footer ======= -->
<footer class=\"footer-bg footer-padding\">
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-lg-4 col-12 text-center text-lg-start\">
                <div class=\"footer-about-content\">
                    <div class=\"footer-logo\">
                        <a href=\"/\"><img src=\"";
        // line 8
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["footerLogo"] ?? null), "section_image", [], "any", false, false, true, 8), "path", [], "any", false, false, true, 8), 8, $this->source), "html", null, true);
        yield "\" class=\"img-fluid mb-4\" alt=\"my clinic logo\"></a>
                    </div>
                    <p class=\"footer-about mb-4 text-lg-start text-justy\">
                        ";
        // line 11
        yield $this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["footerAbout"] ?? null), "description", [], "any", false, false, true, 11), 11, $this->source);
        yield "</p>
                    <div class=\"text-lg-start text-center my-5 my-lg-auto socilimg\">
                        ";
        // line 13
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["footerSocialMediaLinks"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 14
            yield "                        <a href=\"";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "link_value", [], "any", false, false, true, 14), 14, $this->source), "html", null, true);
            yield "\"><img src=\"";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "section_image", [], "any", false, false, true, 14), "path", [], "any", false, false, true, 14), 14, $this->source), "html", null, true);
            yield "\" alt=\"social media icon\"></a>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['item'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 16
        yield "                    </div>
                    <div class=\"col-12 d-none d-lg-block mt-2\">
                        <p class=\"text-white\">© My Clinic <script>document.write(new Date().getFullYear())</script>. All rights reserved.</p>
                    </div>
                </div>

            </div>
            <div class=\"col-lg-3 col-6 footer-list\">
                <h3>Company</h3>
                <ul class=\"list-unstyled\">
                    ";
        // line 26
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["footerCompanyLinks"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 27
            yield "                    <li><a href=\"/";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "link_value", [], "any", false, false, true, 27), 27, $this->source), "html", null, true);
            yield "\"
                            class=\"text-decoration-none text-white\">";
            // line 28
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "link_name", [], "any", false, false, true, 28), 28, $this->source), "html", null, true);
            yield "</a>
                    </li>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['item'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 31
        yield "                </ul>
                <div class=\"d-none d-lg-block clinictime\">
                    ";
        // line 33
        yield $this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["footerClinicTimings"] ?? null), "description", [], "any", false, false, true, 33), 33, $this->source);
        yield "
                    <ul class=\"list-unstyled\">
                        ";
        // line 35
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["footerPhones"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 36
            yield "                        <a href=\"";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "link_value", [], "any", false, false, true, 36), 36, $this->source), "html", null, true);
            yield "\" style=\"text-decoration: none;\">

                        <li class=\"mb-2\">
                            <img src=\"";
            // line 39
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "section_image", [], "any", false, false, true, 39), "path", [], "any", false, false, true, 39), 39, $this->source), "html", null, true);
            yield "\" class=\"img-fluid me-3\" alt=\"phone\"> ";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "link_name", [], "any", false, false, true, 39), 39, $this->source), "html", null, true);
            yield "
                        </li></a>

                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['item'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 43
        yield "                    </ul>
                </div>


            </div>
            <div class=\"col-lg-2 col-6 footer-list\">
                <h3>Useful Links</h3>
                <ul class=\"list-unstyled\">
                    ";
        // line 51
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["footerUsefulLinks"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 52
            yield "                    <li><a href=\"/";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "link_value", [], "any", false, false, true, 52), 52, $this->source), "html", null, true);
            yield "\"
                            class=\"text-decoration-none text-white\">";
            // line 53
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "link_name", [], "any", false, false, true, 53), 53, $this->source), "html", null, true);
            yield "</a>
                    </li>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['item'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 56
        yield "                </ul>
                <!-- <a href=\"javascript:void(0)\" class=\"btn btn-light btn-footer-1 mb-3\">Health Checkup</a> -->
                <a href=\"https://bamc.myclinic.com.sa:8443\"
                    class=\"btn btn-light btn-footer-book-now text-start mb-5 d-flex align-items-center d-lg-none book-now-button\">
                    <svg xmlns=\"http://www.w3.org/2000/svg\" class=\"d-none d-lg-block\" width=\"40\" height=\"41\"
                        viewBox=\"0 0 40 41\" style=\"margin-right: 1.25rem;\" fill=\"none\">
                        <path
                            d=\"M39.25 20.4984C39.25 30.8948 30.6458 39.3484 20 39.3484C9.35416 39.3484 0.75 30.8948 0.75 20.4984C0.75 10.1021 9.35416 1.64844 20 1.64844C30.6458 1.64844 39.25 10.1021 39.25 20.4984Z\"
                            fill=\"white\" stroke=\"#223F85\" stroke-width=\"1.5\" />
                        <path d=\"M21.7727 15.2969L27.2 20.4969L21.7727 25.6969M18.7148 20.4969H27.048M12 20.4969H19\"
                            stroke=\"#003868\" stroke-width=\"1.5\" stroke-miterlimit=\"10\" stroke-linecap=\"round\"
                            stroke-linejoin=\"round\" />
                    </svg>
                    <svg width=\"16\" height=\"16\" class=\"d-block d-lg-none me-3\" viewBox=\"0 0 13 13\" fill=\"none\"
                        xmlns=\"http://www.w3.org/2000/svg\">
                        <path
                            d=\"M12.4856 6.31394C12.4856 9.57254 9.7878 12.2279 6.4428 12.2279C3.0978 12.2279 0.4 9.57254 0.4 6.31394C0.4 3.05534 3.0978 0.4 6.4428 0.4C9.7878 0.4 12.4856 3.05534 12.4856 6.31394Z\"
                            fill=\"white\" stroke=\"#223F85\" stroke-width=\"0.8\" />
                        <path
                            d=\"M7.01537 4.64062L8.76371 6.31575L7.01537 7.99088M6.0303 6.31575H8.71475M3.86719 6.31575H6.12217\"
                            stroke=\"#003868\" stroke-width=\"0.8\" stroke-miterlimit=\"10\" stroke-linecap=\"round\"
                            stroke-linejoin=\"round\" />
                    </svg>
                    Book Now</a>
            </div>
            <div class=\"col-lg-3 col-12 footer-list text-center\">
                <a href=\"https://bamc.myclinic.com.sa:8443\"
                    class=\"btn btn-light btn-footer-book-now mx-auto mb-5 d-flex align-items-center d-none d-lg-flex book-now-button\">
                    <svg xmlns=\"http://www.w3.org/2000/svg\" class=\"d-none d-lg-block\" width=\"40\" height=\"41\"
                        viewBox=\"0 0 40 41\" style=\"margin-right: 1.25rem;\" fill=\"none\">
                        <path
                            d=\"M39.25 20.4984C39.25 30.8948 30.6458 39.3484 20 39.3484C9.35416 39.3484 0.75 30.8948 0.75 20.4984C0.75 10.1021 9.35416 1.64844 20 1.64844C30.6458 1.64844 39.25 10.1021 39.25 20.4984Z\"
                            fill=\"white\" stroke=\"#223F85\" stroke-width=\"1.5\" />
                        <path d=\"M21.7727 15.2969L27.2 20.4969L21.7727 25.6969M18.7148 20.4969H27.048M12 20.4969H19\"
                            stroke=\"#003868\" stroke-width=\"1.5\" stroke-miterlimit=\"10\" stroke-linecap=\"round\"
                            stroke-linejoin=\"round\" />
                    </svg>
                    <svg width=\"13\" height=\"13\" class=\"d-block d-lg-none me-3\" viewBox=\"0 0 13 13\" fill=\"none\"
                        xmlns=\"http://www.w3.org/2000/svg\">
                        <path
                            d=\"M12.4856 6.31394C12.4856 9.57254 9.7878 12.2279 6.4428 12.2279C3.0978 12.2279 0.4 9.57254 0.4 6.31394C0.4 3.05534 3.0978 0.4 6.4428 0.4C9.7878 0.4 12.4856 3.05534 12.4856 6.31394Z\"
                            fill=\"white\" stroke=\"#223F85\" stroke-width=\"0.8\" />
                        <path
                            d=\"M7.01537 4.64062L8.76371 6.31575L7.01537 7.99088M6.0303 6.31575H8.71475M3.86719 6.31575H6.12217\"
                            stroke=\"#003868\" stroke-width=\"0.8\" stroke-miterlimit=\"10\" stroke-linecap=\"round\"
                            stroke-linejoin=\"round\" />
                    </svg>
                    Book Now</a>
                <div class=\"row\">
                    <div class=\"col-lg-12 col-6\">
                        <a
                            href=\"https://apps.apple.com/us/app/my-clinic-ksa/id1475630623?ign-itscg=30200&ign-itsct=apps_box_badge\"><img
                                src=\"";
        // line 108
        yield $this->extensions['Cms\Twig\Extension']->themeFilter("assets/imgs/appstaore-footer.png");
        yield "\"
                                class=\"mb-3 d-block mx-auto img-fluid\" alt=\"appstore\"></a>
                    </div>
                    <div class=\"col-lg-12 col-6\">
                        <a
                            href=\"https://play.google.com/store/apps/details?id=com.myclinic.ksa&pcampaignid=pcampaignidMKT-Other-global-all-co-prtnr-py-PartBadge-Mar2515-1\"><img
                                src=\"";
        // line 114
        yield $this->extensions['Cms\Twig\Extension']->themeFilter("assets/imgs/play-store-footer.png");
        yield "\" class=\"img-fluid\" alt=\"playstore\"></a>
                    </div>
                </div>
                <div class=\"d-block d-lg-none text-white timing-for-mob\">
                    ";
        // line 118
        yield $this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["footerClinicTimings"] ?? null), "description", [], "any", false, false, true, 118), 118, $this->source);
        yield "

                    <ul class=\"list-unstyled w-100\">
                        ";
        // line 121
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["footerPhones"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 122
            yield "                        <a href=\"";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "link_value", [], "any", false, false, true, 122), 122, $this->source), "html", null, true);
            yield "\" style=\"text-decoration: none;\">
                            <li class=\"mb-2 text-center\">
                            <img src=\"";
            // line 124
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "section_image", [], "any", false, false, true, 124), "path", [], "any", false, false, true, 124), 124, $this->source), "html", null, true);
            yield "\" class=\"img-fluid me-3\" alt=\"back to top\"> ";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "link_name", [], "any", false, false, true, 124), 124, $this->source), "html", null, true);
            yield "
                        </li>
                         </a>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['item'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 128
        yield "                    </ul>
                    <!-- 
                    <ul class=\"list-unstyled text-white \">
                        ";
        // line 131
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["footerUsefulLinks"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 132
            yield "                        <li class=\"text-white\"><a href=\"";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "link_value", [], "any", false, false, true, 132), 132, $this->source), "html", null, true);
            yield "\" class=\"text-decoration-none text-white\">";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "link_name", [], "any", false, false, true, 132), 132, $this->source), "html", null, true);
            yield "</a>
                        </li>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['item'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 135
        yield "
                    </ul> -->
                </div>
                <!-- <div class=\"col-12 text-end mt-5 d-none d-lg-block pe-5\">
                    <a href=\"javascript:void(0)\" class=\"text-decoration-none\">
                        <p class=\"text-white patient-privacy\">Patient Privacy Policy</p>
                    </a>
                </div> -->

            </div>
            <!-- <hr class=\"bg-white mx-auto my-3\"> -->
        </div>
    </div>
</footer>
<!-- End Footer -->";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "C:\\xampp\\htdocs\\myclinic\\themes/myclinic/partials/site/footer.htm";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  288 => 135,  276 => 132,  272 => 131,  267 => 128,  255 => 124,  249 => 122,  245 => 121,  239 => 118,  232 => 114,  223 => 108,  169 => 56,  160 => 53,  155 => 52,  151 => 51,  141 => 43,  129 => 39,  122 => 36,  118 => 35,  113 => 33,  109 => 31,  100 => 28,  95 => 27,  91 => 26,  79 => 16,  68 => 14,  64 => 13,  59 => 11,  53 => 8,  44 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "C:\\xampp\\htdocs\\myclinic\\themes/myclinic/partials/site/footer.htm", "");
    }
    
    public function checkSecurity()
    {
        static $tags = ["for" => 13];
        static $filters = ["escape" => 8, "raw" => 11, "theme" => 108];
        static $functions = [];

        try {
            $this->sandbox->checkSecurity(
                ['for'],
                ['escape', 'raw', 'theme'],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
