<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* C:\xampp\htdocs\myclinic\themes/myclinic/partials/components/homePageSearch-ar.htm */
class __TwigTemplate_b15475cf5017731fe22c7c667aa360db extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield "<form class=\"row gy-2 search-form align-items-center flex-row-reverse\" id=\"search-form\">
    <div class=\"col-sm-12 col-12 col-lg px-1\">
        <select class=\"form-select form-select-lg select-mc js-example-basic-multiple\" id=\"location\">
            ";
        // line 4
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["locations"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["location"]) {
            // line 5
            yield "            <option value=";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["location"], "id", [], "any", false, false, true, 5), 5, $this->source), "html", null, true);
            yield ">";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["location"], "name_ar", [], "any", false, false, true, 5), 5, $this->source), "html", null, true);
            yield "</option>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['location'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 7
        yield "        </select>
    </div>
    <div class=\"col-auto d-none d-lg-block\"><span>أو</span></div>

    <div class=\"col-sm-6 col-6 col-lg px-1\">
        <select class=\"form-select form-select-lg select-mc js-example-basic-multiple\" id=\"specialty\" name=\"specialty\">
            <option value=\"\">التخصصات</option>
            ";
        // line 14
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["specialties"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 15
            yield "            <option value=";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "slug", [], "any", false, false, true, 15), 15, $this->source), "html", null, true);
            yield ">";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "name_ar", [], "any", false, false, true, 15), 15, $this->source), "html", null, true);
            yield "</option>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['item'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 17
        yield "        </select>
    </div>
    <div class=\"col-auto d-none d-lg-block\"><span>أو</span></div>
    <div class=\"col-sm-6 col-6 col-lg px-1\">
        <select class=\"form-select form-select-lg select-mc js-example-basic-multiple\" id=\"doctor\" name=\"doctor\">
            <option value=\"\"> الطبيب</option>
            ";
        // line 23
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["doctors"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 24
            yield "            <option value=";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 24), 24, $this->source), "html", null, true);
            yield "><span >
                ";
            // line 25
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "designation_ar", [], "any", false, false, true, 25), 25, $this->source), "html", null, true);
            yield "
            </span>";
            // line 26
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "name_ar", [], "any", false, false, true, 26), 26, $this->source), "html", null, true);
            yield "</option>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['item'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 28
        yield "        </select>
    </div>
    <div class=\"col-12 col-lg col-xl-auto text-center\">
        <button class=\"btn btn-primary btn-mc-search mx-auto mt-3 mt-sm-auto flex-row-reverse\" type=\"submit\">
            <svg class=\"ms-3\" xmlns=\"http://www.w3.org/2000/svg\" width=\"40\" height=\"40\" viewBox=\"0 0 40 40\" fill=\"none\">
                <ellipse cx=\"20\" cy=\"19.6\" rx=\"20\" ry=\"19.6\" fill=\"white\" />
                <path d=\"M21.7727 14.3984L27.2 19.5984L21.7727 24.7984M27.048 19.5984H18.7148H12\" stroke=\"#003868\"
                    stroke-width=\"2\" stroke-miterlimit=\"10\" stroke-linecap=\"round\" stroke-linejoin=\"round\" />
            </svg>ابحث </button>
    </div>
</form>

<script>


    document.getElementById('search-form').addEventListener('submit', function (e) {
        e.preventDefault();  // Prevent the default form submission

        // Get the user's input
        const specialty = document.getElementById('specialty').value;
        const doctor = document.getElementById('doctor').value;
        const location = document.getElementById('location').value;

        var detailPageURL = '';

        if (specialty && location && !doctor) {
            detailPageURL = `/ar/search-specialty/\${location}/\${specialty}`;

        } else {
            detailPageURL = (doctor) ? `/ar/doctor-detail/\${doctor}` : (specialty) ? `/ar/search-specialty/\${specialty}` : `/ar/location-doctors/\${location}`;

        }
        // Determine the detail page URL based on the search type

        // Redirect to the appropriate detail page
        window.location.href = detailPageURL;
    });


    \$(document).ready(function () {
        \$('#specialty').change(function () {
            var countryId = \$(this).val();
            if (countryId) {

                var location = document.getElementById('location').value;
                var doctor = document.getElementById('doctor').value;

                \$.ajax({
                    url: '/specialty-doctors/' + countryId + '?location=' + location,
                    headers:{'language':'ar'},
                    type: 'GET',
                    dataType: 'json',
                    success: function (data) {
                        var statesSelect = \$('#doctor');
                        statesSelect.empty();
                        if (data.doctors.length) {
                            statesSelect.append('<option value=\"\"> الطبيب </option>');
                            \$.each(data.doctors, function (key, state) {
                                var selected = (state.id == doctor) ? ' selected' : '';
                                statesSelect.append('<option value=\"' + state.id + '\"' + selected + '>' + (state.designation_ar ? state.designation_ar : null) + \" \"+state.name_ar + '</option>');
                            });
                        } else {
                            statesSelect.append('<option value=\"\"> الطبيب </option>');
                        }
                    },
                    error: function (jqXHR, textStatus, errorThrown) {
                        // Handle errors
                        console.error('API request failed:', textStatus, errorThrown);
                    }
                });
            }

        });

        \$('#location').change(function () {
            var countryId = \$(this).val();
            var specialty = document.getElementById('specialty').value;
            var doctor = document.getElementById('doctor').value;


            \$.ajax({
                url: '/location-specialties/' + countryId,
                headers:{'language':'ar'},
                type: 'GET',
                dataType: 'json',
                success: function (data) {
                    var statesSelect = \$('#specialty');
                    var doctorSelect = \$('#doctor');
                    var selectedSpecialtyDoctors = null;



                    statesSelect.empty();
                    if (data.specialties.length) {
                        statesSelect.append('<option value=\"\"> التخصصات </option>');
                        \$.each(data.specialties, function (key, state) {
                            var selected = (state.slug === specialty) ? ' selected' : '';
                            statesSelect.append('<option value=\"' + state.slug + '\"' + selected + '>' + state.name_ar + '</option>');
                        });
                        \$('#specialty').change();
                    } else {
                        statesSelect.append('<option value=\"\"> التخصصات </option>');
                    }

                    if (!selectedSpecialtyDoctors) {
                        doctorSelect.empty();
                        doctorSelect.append('<option value=\"\"> الطبيب </option>');
                        \$.each(data.doctors, function (key, state) {
                            var selected = (state.id == doctor) ? ' selected' : '';
                            doctorSelect.append('<option value=\"' + state.id + '\"' + selected + '>' +(state.designation_ar ? state.designation_ar : null) + \" \"+ state.name_ar + '</option>');
                        });
                    }
                },
                error: function (jqXHR, textStatus, errorThrown) {
                    // Handle errors
                    console.error('API request failed:', textStatus, errorThrown);
                }
            });

        });
    });

</script>";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "C:\\xampp\\htdocs\\myclinic\\themes/myclinic/partials/components/homePageSearch-ar.htm";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  117 => 28,  109 => 26,  105 => 25,  100 => 24,  96 => 23,  88 => 17,  77 => 15,  73 => 14,  64 => 7,  53 => 5,  49 => 4,  44 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "C:\\xampp\\htdocs\\myclinic\\themes/myclinic/partials/components/homePageSearch-ar.htm", "");
    }
    
    public function checkSecurity()
    {
        static $tags = ["for" => 4];
        static $filters = ["escape" => 5];
        static $functions = [];

        try {
            $this->sandbox->checkSecurity(
                ['for'],
                ['escape'],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
