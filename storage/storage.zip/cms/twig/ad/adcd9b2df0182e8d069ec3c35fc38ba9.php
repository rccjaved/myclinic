<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* C:\xampp\htdocs\myclinic\themes/myclinic/partials/components/appDownload.htm */
class __TwigTemplate_acd61593c1f6b1fbbca9bf9b8d29cf02 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield "<!-- ======= DOWNLOAD OUR APP START ======= -->
<section class=\"download-app section-py-120\" id=\"appDownload\">
    <div class=\"container download-app-bg\">
        <div class=\"row align-items-center\">
            <div class=\"col-12 col-sm-6 text-center\">
                <img src=\"";
        // line 6
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["commonComponent"] ?? null), "section_image", [], "any", false, false, true, 6), "path", [], "any", false, false, true, 6), 6, $this->source), "html", null, true);
        yield "\" class=\"img-fluid app-hand d-none d-sm-inline-flex\"
                    alt=\"mobile-app\">
            </div>
            <div class=\"col-12 col-sm-6 col-lg-6 p-4\">
                <h1 class=\"text-center text-sm-start\">";
        // line 10
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["commonComponent"] ?? null), "title", [], "any", false, false, true, 10), 10, $this->source), "html", null, true);
        yield "</h1>
                <p class=\"text-justy\">";
        // line 11
        yield $this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["commonComponent"] ?? null), "description", [], "any", false, false, true, 11), 11, $this->source);
        yield "</p>
                <div class=\"d-flex align-items-center\">
                    <img src=\"";
        // line 13
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["commonComponent"] ?? null), "section_image", [], "any", false, false, true, 13), "path", [], "any", false, false, true, 13), 13, $this->source), "html", null, true);
        yield "\"
                        class=\"img-fluid app-hand d-block d-sm-none float-start\" alt=\"none\">
                    <div class=\"row g-2 g-md-4\">
                        <div class=\"col-12 col-sm-6 col-xl-auto\">
                            <a
                                href=\"https://apps.apple.com/us/app/my-clinic-ksa/id1475630623?itsct=apps_box_badge&itscg=30200\"><img
                                    src=\"";
        // line 19
        yield $this->extensions['Cms\Twig\Extension']->themeFilter("assets/imgs/appstore.png");
        yield "\" class=\"img-fluid\" alt=\"appstore\"></a>

                        </div>
                        <div class=\"col-12 col-sm-6 col-xl-auto\">
                            <a
                                href=\"https://play.google.com/store/apps/details?id=com.myclinic.ksa&pcampaignid=pcampaignidMKT-Other-global-all-co-prtnr-py-PartBadge-Mar2515-1\">
                                <img src=\"";
        // line 25
        yield $this->extensions['Cms\Twig\Extension']->themeFilter("assets/imgs/play-store.png");
        yield "\" class=\"img-fluid\" alt=\"playstore\"></a>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- ======= DOWNLOAD OUR APP END ======= -->";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "C:\\xampp\\htdocs\\myclinic\\themes/myclinic/partials/components/appDownload.htm";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  85 => 25,  76 => 19,  67 => 13,  62 => 11,  58 => 10,  51 => 6,  44 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "C:\\xampp\\htdocs\\myclinic\\themes/myclinic/partials/components/appDownload.htm", "");
    }
    
    public function checkSecurity()
    {
        static $tags = [];
        static $filters = ["escape" => 6, "raw" => 11, "theme" => 19];
        static $functions = [];

        try {
            $this->sandbox->checkSecurity(
                [],
                ['escape', 'raw', 'theme'],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
