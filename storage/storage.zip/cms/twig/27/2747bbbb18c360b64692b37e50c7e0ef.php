<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* C:\xampp\htdocs\myclinic\themes/myclinic/pages/index.htm */
class __TwigTemplate_be74a3aca86ae1a130ff738103b94930 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield "<!-- Banner -->


<div class=\"swiper-container\">
  <!-- Additional required wrapper -->
  <div class=\"swiper-wrapper\">
    <!-- Slider -->
    ";
        // line 8
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["sliders"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 9
            yield "    <div class=\"swiper-slide\" data-swiper-autoplay=\"8000\">
      <img src=\"";
            // line 10
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "slider_image_mobile", [], "any", false, false, true, 10), "path", [], "any", false, false, true, 10), 10, $this->source), "html", null, true);
            yield "\" class=\"slidemc\" alt=\"services\">
      <img src=\"";
            // line 11
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "slider_image", [], "any", false, false, true, 11), "path", [], "any", false, false, true, 11), 11, $this->source), "html", null, true);
            yield "\" class=\"slidemc slidemc-m-home\" alt=\"services\">
      <div class=\"slide-text\">
        <h1 class=\"mb-3\">";
            // line 13
            yield $this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "title", [], "any", false, false, true, 13), 13, $this->source);
            yield "</h1>
        <p class=\"mb-3 mb-sm-5\">";
            // line 14
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "tag_line", [], "any", false, false, true, 14), 14, $this->source), "html", null, true);
            yield "</p>
        ";
            // line 15
            if (Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "link_value", [], "any", false, false, true, 15)) {
                // line 16
                yield "        <a href=\"";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "link_value", [], "any", false, false, true, 16), 16, $this->source), "html", null, true);
                yield "\" class=\"btn btn-primary slide-s btn-mc-01 mb-6\"><svg
            xmlns=\"http://www.w3.org/2000/svg\" width=\"40\" height=\"40\" viewBox=\"0 0 40 40\" fill=\"none\"
            style=\"margin-right: 20px;\">
            <ellipse cx=\"20\" cy=\"19.6\" rx=\"20\" ry=\"19.6\" fill=\"white\" />
            <path d=\"M21.7727 14.3984L27.2 19.5984L21.7727 24.7984M27.048 19.5984H18.7148H12\" stroke=\"#003868\"
              stroke-width=\"2\" stroke-miterlimit=\"10\" stroke-linecap=\"round\" stroke-linejoin=\"round\" />
          </svg>";
                // line 22
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "link_name", [], "any", false, false, true, 22), 22, $this->source), "html", null, true);
                yield "</a>
        ";
            }
            // line 24
            yield "      </div>
    </div>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['item'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 27
        yield "  </div>
  <!-- If we need pagination -->
  <div class=\"swiper-pagination\"></div>

  <!-- If we need navigation buttons -->
  <div class=\"swiper-button-prev\"><span></span></div>
  <div class=\"swiper-button-next\"><span></span></div>

  <!-- Search Form -->


</div>

<!-- <section class=\"front-search z-1 d-none d-lg-block w-100\">
  <div class=\"container front-form-bg\">
    <div class=\"row\">
      <div class=\"col-12\">
        <div class=\"hero-search\">
          ";
        // line 45
        $cmsPartialParams = [];
        yield $this->env->getExtension(\Cms\Twig\Extension::class)->partialFunction("components/homePageSearch"        , array_merge($context, ['__cms_partial_params' => $cmsPartialParams], $cmsPartialParams)        , true        );
        // line 46
        yield "        </div>
      </div>
    </div>
  </div>
</section> -->

<section class=\"front-search-1 z-1  advnace-search-home\">
  <div class=\"container front-form-bg font-form-2\">
    <div class=\"row\">
      <div class=\"col-12\">
        ";
        // line 56
        $cmsPartialParams = [];
        yield $this->env->getExtension(\Cms\Twig\Extension::class)->partialFunction("components/homePageSearch"        , array_merge($context, ['__cms_partial_params' => $cmsPartialParams], $cmsPartialParams)        , true        );
        // line 57
        yield "      </div>
    </div>
  </div>
</section>




";
        // line 65
        $cmsPartialParams = [];
        yield $this->env->getExtension(\Cms\Twig\Extension::class)->partialFunction("components/specialties"        , array_merge($context, ['__cms_partial_params' => $cmsPartialParams], $cmsPartialParams)        , true        );
        // line 66
        yield "

<!-- ======= FIND YOUR DOCTOR START ======= -->

<section class=\"section-bg section-py-100\">
  <div class=\"container bg-white\">
    <div class=\"row align-items-center\">
      <div class=\"col-12 col-lg-6\">
        <div class=\"mc-block text-center text-lg-start\">
          <h1>";
        // line 75
        yield $this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["findYourDoc"] ?? null), "title", [], "any", false, false, true, 75), 75, $this->source);
        yield "</h1>
          <p class=\"text-justy\">";
        // line 76
        yield $this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["findYourDoc"] ?? null), "description", [], "any", false, false, true, 76), 76, $this->source);
        yield "</p>

          <a href=\"";
        // line 78
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["findYourDoc"] ?? null), "link_value", [], "any", false, false, true, 78), 78, $this->source), "html", null, true);
        yield "\" class=\"btn btn-primary appoint btn-mc-01\"><svg
              xmlns=\"http://www.w3.org/2000/svg\" width=\"49\" height=\"48\" viewBox=\"0 0 49 48\" fill=\"none\">
              <ellipse cx=\"24.325\" cy=\"23.8176\" rx=\"24.2\" ry=\"23.716\" fill=\"white\" />
              <path
                d=\"M22.9612 15.8281C26.2211 15.8281 28.86 18.467 28.86 21.7269C28.86 24.9867 26.2211 27.6256 22.9612 27.6256C19.7014 27.6256 17.0625 24.9867 17.0625 21.7269C17.0625 19.4295 18.3726 17.4425 20.2913 16.4677M32.7925 31.5581L27.3475 26.1131\"
                stroke=\"#003868\" stroke-width=\"1.452\" stroke-miterlimit=\"10\" stroke-linecap=\"round\"
                stroke-linejoin=\"round\" />
            </svg>";
        // line 85
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["findYourDoc"] ?? null), "link_name", [], "any", false, false, true, 85), 85, $this->source), "html", null, true);
        yield "</a>
        </div>
      </div>
      <div class=\"col-12 col-lg-6\">
        <div class=\"mcgallery\">
          <div class=\"gallery\">
            <div class=\"colz\">
              <div class=\"image\">
                <a href=\"/find-doctor\"><img src=\"";
        // line 93
        yield $this->extensions['Cms\Twig\Extension']->themeFilter("assets/imgs/001dr.png");
        yield "\" class=\"mcimg\" alt=\"doctor\"></a>
              </div>
              <div class=\"image\">
                <a href=\"/find-doctor\"><img src=\"";
        // line 96
        yield $this->extensions['Cms\Twig\Extension']->themeFilter("assets/imgs/002dr.png");
        yield "\" class=\"mcimg\" alt=\"doctor\"></a>
              </div>
              <div class=\"image\">
                <a href=\"/find-doctor\"><img src=\"";
        // line 99
        yield $this->extensions['Cms\Twig\Extension']->themeFilter("assets/imgs/003dr.png");
        yield "\" class=\"mcimg\" alt=\"doctor\"></a>
              </div>
              <div class=\"image\">
                <a href=\"/find-doctor\"><img src=\"";
        // line 102
        yield $this->extensions['Cms\Twig\Extension']->themeFilter("assets/imgs/004dr.png");
        yield "\" class=\"mcimg\" alt=\"doctor\"></a>
              </div>
              <div class=\"image\">
                <a href=\"/find-doctor\"><img src=\"";
        // line 105
        yield $this->extensions['Cms\Twig\Extension']->themeFilter("assets/imgs/005dr.png");
        yield "\" class=\"mcimg\" alt=\"doctor\"></a>
              </div>

            </div>
            <div class=\"colz\">
              <div class=\"image\">
                <a href=\"/find-doctor\"><img src=\"";
        // line 111
        yield $this->extensions['Cms\Twig\Extension']->themeFilter("assets/imgs/005dr.png");
        yield "\" class=\"mcimg\" alt=\"doctor\"></a>
              </div>
              <div class=\"image\">
                <a href=\"/find-doctor\"><img src=\"";
        // line 114
        yield $this->extensions['Cms\Twig\Extension']->themeFilter("assets/imgs/004dr.png");
        yield "\" class=\"mcimg\" alt=\"doctor\"></a>
              </div>
              <div class=\"image\">
                <a href=\"/find-doctor\"><img src=\"";
        // line 117
        yield $this->extensions['Cms\Twig\Extension']->themeFilter("assets/imgs/003dr.png");
        yield "\" class=\"mcimg\" alt=\"doctor\"></a>
              </div>
              <div class=\"image\">
                <a href=\"/find-doctor\"><img src=\"";
        // line 120
        yield $this->extensions['Cms\Twig\Extension']->themeFilter("assets/imgs/004dr.png");
        yield "\" class=\"mcimg\" alt=\"doctor\"></a>
              </div>
              <div class=\"image\">
                <a href=\"/find-doctor\"><img src=\"";
        // line 123
        yield $this->extensions['Cms\Twig\Extension']->themeFilter("assets/imgs/005dr.png");
        yield "\" class=\"mcimg\" alt=\"doctor\"></a>
              </div>
            </div>
            <div class=\"colz\">
              <div class=\"image\">
                <a href=\"/find-doctor\"><img src=\"";
        // line 128
        yield $this->extensions['Cms\Twig\Extension']->themeFilter("assets/imgs/003dr.png");
        yield "\" class=\"mcimg\" alt=\"doctor\"></a>
              </div>
              <div class=\"image\">
                <a href=\"/find-doctor\"><img src=\"";
        // line 131
        yield $this->extensions['Cms\Twig\Extension']->themeFilter("assets/imgs/004dr.png");
        yield "\" class=\"mcimg\" alt=\"doctor\"></a>
              </div>
              <div class=\"image\">
                <a href=\"/find-doctor\"><img src=\"";
        // line 134
        yield $this->extensions['Cms\Twig\Extension']->themeFilter("assets/imgs/001dr.png");
        yield "\" class=\"mcimg\" alt=\"doctor\"></a>
              </div>
              <div class=\"image\">
                <a href=\"/find-doctor\"><img src=\"";
        // line 137
        yield $this->extensions['Cms\Twig\Extension']->themeFilter("assets/imgs/002dr.png");
        yield "\" class=\"mcimg\" alt=\"doctor\"></a>
              </div>
              <div class=\"image\">
                <a href=\"/find-doctor\"><img src=\"";
        // line 140
        yield $this->extensions['Cms\Twig\Extension']->themeFilter("assets/imgs/005dr.png");
        yield "\" class=\"mcimg\" alt=\"doctor\"></a>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  </div>
</section>
<!-- ======= FIND YOUR DOCTOR END ======= -->

";
        // line 152
        $cmsPartialParams = [];
        yield $this->env->getExtension(\Cms\Twig\Extension::class)->partialFunction("components/programs"        , array_merge($context, ['__cms_partial_params' => $cmsPartialParams], $cmsPartialParams)        , true        );
        // line 153
        yield "
";
        // line 154
        if (($context["telemedicine_common_section"] ?? null)) {
            // line 155
            yield "<section class=\"section-py-100 section-bg\">
  <div class=\"container bg-white\">
    <div class=\"row align-items-center\">
      <div class=\"col-12 col-lg-6\">
        <div class=\"mc-block text-center text-lg-start\">
          <h1>";
            // line 160
            yield $this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["telemedicine_common_section"] ?? null), "title", [], "any", false, false, true, 160), 160, $this->source);
            yield "</h1>
          <p class=\"text-justy\">";
            // line 161
            yield $this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["telemedicine_common_section"] ?? null), "description", [], "any", false, false, true, 161), 161, $this->source);
            yield "</p>
          ";
            // line 162
            if (Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["telemedicine_common_section"] ?? null), "link_value", [], "any", false, false, true, 162)) {
                // line 163
                yield "
          <a href=\"/";
                // line 164
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["telemedicine_common_section"] ?? null), "link_value", [], "any", false, false, true, 164), 164, $this->source), "html", null, true);
                yield "\" class=\"btn btn-primary btn-mc-01\"><svg
              xmlns=\"http://www.w3.org/2000/svg\" width=\"40\" height=\"40\" viewBox=\"0 0 40 40\" fill=\"none\">
              <ellipse cx=\"20\" cy=\"19.6\" rx=\"20\" ry=\"19.6\" fill=\"white\" />
              <path d=\"M21.7727 14.3984L27.2 19.5984L21.7727 24.7984M18.7148 19.5984H27.048M12 19.5984H21.5\"
                stroke=\"#003868\" stroke-width=\"2\" stroke-miterlimit=\"10\" stroke-linecap=\"round\"
                stroke-linejoin=\"round\" />
            </svg>";
                // line 170
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["telemedicine_common_section"] ?? null), "link_name_", [], "any", false, false, true, 170), 170, $this->source), "html", null, true);
                yield " Learn More</a>
          ";
            }
            // line 172
            yield "        </div>
      </div>
      <div class=\"col-12 col-lg-6 px-0\">
        <img src=\"";
            // line 175
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["telemedicine_common_section"] ?? null), "section_image", [], "any", false, false, true, 175), "path", [], "any", false, false, true, 175), 175, $this->source), "html", null, true);
            yield "\" class=\"img-fluid\" alt=\"telemedicine\">
      </div>
    </div>
  </div>
</section>
";
        }
        // line 181
        yield "
";
        // line 182
        if (($context["health_homecare_common_section"] ?? null)) {
            // line 183
            yield "<section class=\"section-py-100 section-bg-2\">
  <div class=\"container bg-white section-py-100\">
    <div class=\"row align-items-center\">
      <div class=\"col-12 col-lg-6\">
        <div class=\"mc-block text-center text-lg-start\">
          <h1>";
            // line 188
            yield $this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["health_homecare_common_section"] ?? null), "title", [], "any", false, false, true, 188), 188, $this->source);
            yield "</h1>
          <p class=\"text-justy\">";
            // line 189
            yield $this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["health_homecare_common_section"] ?? null), "description", [], "any", false, false, true, 189), 189, $this->source);
            yield "</p>
          ";
            // line 190
            if (Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["health_homecare_common_section"] ?? null), "link_value", [], "any", false, false, true, 190)) {
                // line 191
                yield "          <a href=\"";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["health_homecare_common_section"] ?? null), "link_value", [], "any", false, false, true, 191), 191, $this->source), "html", null, true);
                yield "\" class=\"btn btn-primary btn-mc-01\"><svg
              xmlns=\"http://www.w3.org/2000/svg\" width=\"40\" height=\"40\" viewBox=\"0 0 40 40\" fill=\"none\">
              <ellipse cx=\"20\" cy=\"19.6\" rx=\"20\" ry=\"19.6\" fill=\"white\" />
              <path d=\"M21.7727 14.3984L27.2 19.5984L21.7727 24.7984M18.7148 19.5984H27.048M12 19.5984H21.5\"
                stroke=\"#003868\" stroke-width=\"2\" stroke-miterlimit=\"10\" stroke-linecap=\"round\"
                stroke-linejoin=\"round\" />
            </svg>";
                // line 197
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["health_homecare_common_section"] ?? null), "link_name", [], "any", false, false, true, 197), 197, $this->source), "html", null, true);
                yield "</a>
          ";
            }
            // line 199
            yield "        </div>
      </div>
      <div class=\"col-12 col-lg-6\">
        <img src=\"";
            // line 202
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["health_homecare_common_section"] ?? null), "section_image", [], "any", false, false, true, 202), "path", [], "any", false, false, true, 202), 202, $this->source), "html", null, true);
            yield "\" class=\"img-fluid\" alt=\"homecare\">
      </div>
    </div>
  </div>
</section>
";
        }
        // line 208
        yield "
<!--offer section area-->

<!--offer section area end-->

";
        // line 213
        $cmsPartialParams = [];
        $cmsPartialParams['planText'] = ($context["planText"] ?? null)        ;
        yield $this->env->getExtension(\Cms\Twig\Extension::class)->partialFunction("components/planAndPromotions"        , array_merge($context, ['__cms_partial_params' => $cmsPartialParams], $cmsPartialParams)        , true        );
        // line 214
        yield "


";
        // line 217
        $cmsPartialParams = [];
        yield $this->env->getExtension(\Cms\Twig\Extension::class)->partialFunction("components/appDownload"        , array_merge($context, ['__cms_partial_params' => $cmsPartialParams], $cmsPartialParams)        , true        );
        // line 218
        yield "


";
        // line 221
        $cmsPartialParams = [];
        $cmsPartialParams['testimonials'] = ($context["testimonials"] ?? null)        ;
        yield $this->env->getExtension(\Cms\Twig\Extension::class)->partialFunction("components/testimonial"        , array_merge($context, ['__cms_partial_params' => $cmsPartialParams], $cmsPartialParams)        , true        );
        // line 222
        yield "

<section class=\"section-bg section-py-120\">
  <div class=\"container\">
    <div class=\"row mb-6\">

      <div class=\"col-12 col-sm-6 col-lg-6 py-60 pt-0\">
        <h1 class=\"text-justy\">";
        // line 229
        yield $this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["homeNewsAnnouncement"] ?? null), "title", [], "any", false, false, true, 229), 229, $this->source);
        yield "</h1>

      </div>
      <div class=\"offset-sm-1 col-12 col-sm-5 text-justy\">
        <p>";
        // line 233
        yield $this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["homeNewsAnnouncement"] ?? null), "description", [], "any", false, false, true, 233), 233, $this->source);
        yield "</p>
        <a class=\"btn btn-primary btn-mc-01 mb-3 margin-0-auto\" href=\"";
        // line 234
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["homeNewsAnnouncement"] ?? null), "link_value", [], "any", false, false, true, 234), 234, $this->source), "html", null, true);
        yield "\"><svg
            xmlns=\"http://www.w3.org/2000/svg\" width=\"40\" height=\"40\" viewBox=\"0 0 40 40\" fill=\"none\"
            style=\"margin-right: 12px;\">
            <ellipse cx=\"20\" cy=\"19.6\" rx=\"20\" ry=\"19.6\" fill=\"white\" />
            <path d=\"M21.7727 14.3984L27.2 19.5984L21.7727 24.7984M27.048 19.5984H18.7148H12\" stroke=\"#003868\"
              stroke-width=\"2\" stroke-miterlimit=\"10\" stroke-linecap=\"round\" stroke-linejoin=\"round\" />
          </svg>";
        // line 240
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["homeNewsAnnouncement"] ?? null), "link_name", [], "any", false, false, true, 240), 240, $this->source), "html", null, true);
        yield "</a>
      </div>

    </div>
    <div class=\"row gy-3\">
      ";
        // line 245
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["blogs"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 246
            yield "      <div class=\"col-12 col-sm-6 col-lg-4\">
        <a href=\"/blog-details/";
            // line 247
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 247), 247, $this->source), "html", null, true);
            yield "\">
          <div class=\"blog-post\">
            <img src=\"";
            // line 249
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "blog_image", [], "any", false, false, true, 249), "path", [], "any", false, false, true, 249), 249, $this->source), "html", null, true);
            yield "\" class=\"img-fluid mb-3\" alt=\"blog\">
            <div>
              <div class=\"d-flex\">
                <a href=\"#\" class=\"text-decoration-none post-author\">";
            // line 252
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "author_name", [], "any", false, false, true, 252), 252, $this->source), "html", null, true);
            yield "</a>
              </div>
              <h2 class=\"post-title\">";
            // line 254
            yield $this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "tag_line", [], "any", false, false, true, 254), 254, $this->source);
            yield "</h2>
              <p class=\"post-desc\">";
            // line 255
            yield $this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "description", [], "any", false, false, true, 255), 255, $this->source);
            yield "</p>
            </div>
          </div>
        </a>
      </div>
      ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['item'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 261
        yield "    </div>
  </div>
</section>


<!-- Modal start -->
<div class=\"modals\">
  <dialog class=\"dialog\" id=\"book-now\">
    <button class=\"dialog__close\"></button>
    <div class=\"container\">
      <div class=\"row\">
        <div class=\"col-lg-12 col-xxl-11 mx-auto\">
          <div class=\"bg-white shadow rounded\">
            <div class=\"row\">
              <div class=\"col-md-5 ps-0 d-none d-md-block\">
                <div class=\"form-right h-100 bg-login text-white text-center pt-5\">
                  <img src=\"";
        // line 277
        yield $this->extensions['Cms\Twig\Extension']->themeFilter("assets/imgs/my-clinic-logo-white.png");
        yield "\" class=\"\" style=\"width: 12rem\" alt=\"\" />
                </div>
              </div>
              <div class=\"col-md-7 pe-0\">
                <div class=\"form-left h-100 py-5 px-5\">
                  <h1>Create Account</h1>
                  <div>
                    <a href=\"#\" class=\"btn btn-light btn-social-login me-4\"><img
                        src=\"";
        // line 285
        yield $this->extensions['Cms\Twig\Extension']->themeFilter("assets/imgs/google.png");
        yield "\" class=\"img-fluid me-3\" alt=\"\" />Signup with Google</a>
                    <a href=\"#\" class=\"btn btn-light btn-social-login\"><img src=\"";
        // line 286
        yield $this->extensions['Cms\Twig\Extension']->themeFilter("assets/imgs/fb.png");
        yield "\"
                        class=\"img-fluid me-3\" alt=\"\" />Signup with Facebook</a>
                  </div>
                  <div class=\"text-center my-4\">
                    <p>- OR -</p>
                  </div>
                  <form action=\"\" class=\"row g-4\">
                    <div class=\"col-12\">
                      <div class=\"\">
                        <input type=\"text\" class=\"form-control form-control-lg select-mc\" placeholder=\"Full Name\" />
                      </div>
                    </div>

                    <div class=\"col-12\">
                      <div class=\"\">
                        <input type=\"email\" class=\"form-control form-control-lg select-mc\" placeholder=\"Email\" />
                      </div>
                    </div>
                    <div class=\"col-12\">
                      <div class=\"\">
                        <input type=\"text\" class=\"form-control form-control-lg select-mc\"
                          placeholder=\"Enter Password\" />
                      </div>
                    </div>
                    <div class=\"col-12\">
                      <button type=\"submit\" class=\"btn btn-dark btn-mc-001 w-100 px-0\">
                        login
                      </button>
                    </div>
                    <div class=\"col-sm-6\">
                      Already have an account?
                      <a href=\"#\">Log In</a>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </dialog>
</div>
<!-- Modal End -->

";
        // line 331
        $this->env->getExtension(\Cms\Twig\Extension::class)->yieldBlock('scripts'        , function() use ($context, $blocks, $macros) {
        // line 332
        yield "<script>
  \$(function () {
    \$(\".mc-hide\").slice(0, 8).show();
    \$(\"body\").on(\"click touchstart\", \".load-more-specialty\", function (e) {
      e.preventDefault();
      \$(\".mc-hide:hidden\").slice(0, 10).slideDown();
      if (\$(\".mc-hide:hidden\").length == 0) {
        \$(\".load-more\").css(\"visibility\", \"hidden\");
      }
    });
  });
</script>

<script>
  \$(function () {
    \$(\".mc-hide-2\").slice(0, 8).show();
    \$(\"body\").on(\"click touchstart\", \".load-more-programs\", function (e) {
      e.preventDefault();
      \$(\".mc-hide-2:hidden\").slice(0, 4).slideDown();
      if (\$(\".mc-hide-2:hidden\").length == 0) {
        \$(\".load-more\").css(\"visibility\", \"hidden\");
      }
    });
  });
</script>

<!-- Start Login Modal Script -->
<script>
  // Get all links that start with #modal
  const modalLinks = document.querySelectorAll('a[href^=\"#book-now\"]');

  modalLinks.forEach(function (modalLink, index) {
    // Get modal ID to match the modal
    const modalId = modalLink.getAttribute(\"href\");

    // Click on link
    modalLink.addEventListener(\"click\", function (event) {
      // Get modal element
      const modal = document.querySelector(modalId);
      // If modal with an ID exists
      if (modal) {
        // Get close button
        const closeBtn = modal.querySelector(\".dialog__close\");
        event.preventDefault();
        modal.showModal(); // Open modal

        // Close modal on click
        closeBtn.addEventListener(\"click\", function (event) {
          modal.close();
        });

        // Close modal when clicking outside modal
        document.addEventListener(
          \"click\",
          function (event) {
            const dialogEl = event.target.tagName;
            const dialogElId = event.target.getAttribute(\"id\");
            if (dialogEl == \"DIALOG\") {
              // Close modal
              modal.close();
            }
          },
          false
        );

        // If modal ID not exists
      } else {
        console.log(\"Modal doesn't exist\");
      }
    });
  });
</script>
<!-- End Login Modal Script -->

<script>

  gsap.registerPlugin(ScrollTrigger);

  const additionalY = { val: 0 };
  let additionalYAnim;
  let offset = 0;
  const cols = gsap.utils.toArray(\".colz\");

  cols.forEach((col, i) => {
    const images = col.childNodes;

    // DUPLICATE IMAGES FOR LOOP
    images.forEach((image) => {
      var clone = image.cloneNode(true);
      col.appendChild(clone);
    });

    // SET ANIMATION
    images.forEach((item) => {
      let columnHeight = item.parentElement.clientHeight;
      let direction = i % 2 !== 0 ? \"+=\" : \"-=\"; // Change direction for odd columns

      gsap.to(item, {
        y: direction + Number(columnHeight / 2),
        duration: 10,
        repeat: -1,
        ease: \"none\",
        modifiers: {
          y: gsap.utils.unitize((y) => {
            if (direction == \"+=\") {
              offset += additionalY.val;
              y = (parseFloat(y) - offset) % (columnHeight * 0.5);
            } else {
              offset += additionalY.val;
              y =
                (parseFloat(y) + offset) %
                -Number(columnHeight * 0.5);
            }

            return y;
          }),
        },
      });
    });
  });
</script>
<script>

  // ------------- New Slider ----------

  // swiper    
  var mySwiper = new Swiper('.swiper-container', {
    effect: '',
    loop: true,
    speed: 1000,
    slidesPerView: 1,
    navigation: {
      nextEl: '.swiper-button-next',
      prevEl: '.swiper-button-prev'
    },
    pagination: {
      el: '.swiper-pagination',
      type: 'bullets',
      clickable: 'true'
    },
    autoplay: {
      delay: 3000,
      disableOnInteraction: false,
    },



  });
</script>
<div id=\"targetDiv\" hidden>
  <!-- Include the generated content as a data attribute -->
  <div data-partial-content='";
        // line 483
        $cmsPartialParams = [];
        yield $this->env->getExtension(\Cms\Twig\Extension::class)->partialFunction("components/homePageSearch"        , array_merge($context, ['__cms_partial_params' => $cmsPartialParams], $cmsPartialParams)        , true        );
        yield "'></div>
</div>
<script>
  let text;
  if (window.matchMedia(\"(max-width: 991px)\").matches) {
    console.log(\"le fer ni chli\")
    var targetDiv = document.getElementById('targetDiv');

    // Get the generated content from the data attribute
    var content = targetDiv.querySelector('div').getAttribute('data-partial-content');

    // Set the innerHTML of the div to the generated content
    document.getElementById(\"nsearchSec\").innerHTML = content;
  } else {
    console.log(\"screen wide\")
    var targetDiv = document.getElementById('targetDiv');

    // Get the generated content from the data attribute
    var content = targetDiv.querySelector('div').getAttribute('data-partial-content');

    // Set the innerHTML of the div to the generated content
    document.getElementById(\"nsearch\").innerHTML = content;
  }
</script>

";
        // line 331
        return; yield '';}, true        );
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "C:\\xampp\\htdocs\\myclinic\\themes/myclinic/pages/index.htm";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  774 => 331,  745 => 483,  592 => 332,  590 => 331,  542 => 286,  538 => 285,  527 => 277,  509 => 261,  497 => 255,  493 => 254,  488 => 252,  482 => 249,  477 => 247,  474 => 246,  470 => 245,  462 => 240,  453 => 234,  449 => 233,  442 => 229,  433 => 222,  429 => 221,  424 => 218,  421 => 217,  416 => 214,  412 => 213,  405 => 208,  396 => 202,  391 => 199,  386 => 197,  376 => 191,  374 => 190,  370 => 189,  366 => 188,  359 => 183,  357 => 182,  354 => 181,  345 => 175,  340 => 172,  335 => 170,  326 => 164,  323 => 163,  321 => 162,  317 => 161,  313 => 160,  306 => 155,  304 => 154,  301 => 153,  298 => 152,  283 => 140,  277 => 137,  271 => 134,  265 => 131,  259 => 128,  251 => 123,  245 => 120,  239 => 117,  233 => 114,  227 => 111,  218 => 105,  212 => 102,  206 => 99,  200 => 96,  194 => 93,  183 => 85,  173 => 78,  168 => 76,  164 => 75,  153 => 66,  150 => 65,  140 => 57,  137 => 56,  125 => 46,  122 => 45,  102 => 27,  94 => 24,  89 => 22,  79 => 16,  77 => 15,  73 => 14,  69 => 13,  64 => 11,  60 => 10,  57 => 9,  53 => 8,  44 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "C:\\xampp\\htdocs\\myclinic\\themes/myclinic/pages/index.htm", "");
    }
    
    public function checkSecurity()
    {
        static $tags = ["for" => 8, "if" => 15, "partial" => 45, "put" => 331];
        static $filters = ["escape" => 10, "raw" => 13, "theme" => 93];
        static $functions = [];

        try {
            $this->sandbox->checkSecurity(
                ['for', 'if', 'partial', 'put'],
                ['escape', 'raw', 'theme'],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
