<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* C:\xampp\htdocs\myclinic\themes/myclinic/partials/components/testimonial.htm */
class __TwigTemplate_cf57ab6b1d4edcd6ab9541239fa5b620 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield "<style>
    .testimonial {
        width: 100%;
        /* height: 100vh; */
        display: flex;
        justify-content: center;
        align-items: center;
        /* background-color: #3d5a80; */
        color: #3d5a80;
    }

    .testimonial-slide {
        padding: 46px 20px;
    }

    .testimonial_box-top {
        /* background: url(\"assets/imgs/testimonial-bg.png\"); */
        background-repeat: no-repeat;
        background-size: cover;
        /* background-color: #003868; */
        padding: 60px;
        padding-top: 0px;
        /* border-radius: 15px; */
        display: flex;
        justify-content: center;
        align-items: center;
        flex-direction: column;
        text-align: center;
        /* box-shadow: 5px 5px 20px rgba(152, 193, 217, 0.493); */
    }

    @media only screen and (max-width: 991px) {}

    .testimonial_box-icon {
        padding: 10px 0;
    }

    .testimonial_box-icon i {
        font-size: 25px;
        color: #14213d;
    }

    .slick-next .slick-next-icon,
    .slick-next .slick-prev-icon,
    .slick-prev .slick-next-icon,
    .slick-prev .slick-prev-icon {
        display: block;
        color: #FFF;
        opacity: 1;
        font-size: 24px;
        line-height: 1;
        /* content: \"\\f054\"; */
        font-family: FontAwesome;
    }

    .slick-prev .slick-prev-icon::before {
        content: \"\\f053\";
    }

    .slick-next .slick-next-icon::before {
        content: \"\\f054\";
    }

    .testimonial_box-text {
        padding: 10px 0;
    }

    .testimonial_box-text p {
        color: #003868;
        font-size: 14px;
        line-height: 20px;
        margin-bottom: 0;
    }

    .testimonial_box-img {
        padding: 20px 0 10px;
        display: flex;
        justify-content: center;
    }

    .testimonial_box-img img {
        width: 70px;
        height: 70px;
        /* border-radius: 50px; */
        border: 2px solid #e5e5e5;
    }

    .testimonial_box-name {
        padding-top: 10px;
    }

    .testimonial_box-name h4 {
        font-size: 20px;
        line-height: 25px;
        color: #003868;
        margin-bottom: 0;
    }

    .testimonial_box-job p {
        color: #293241;
        font-size: 14px;
        text-transform: uppercase;
        letter-spacing: 3px;
        line-height: 20px;
        font-weight: 300;
        margin-bottom: 0;
    }

    .slick-autoplay-toggle-button {
        display: none;
    }

    .testimonial-slider .slick-list {
        margin: 0px 20px !important;
    }
</style>
<section class=\"section-bg-2 section-py-100\">
    <div class=\"testimonial\">
        <div class=\"container\">
            <div class=\"row\">
                <div class=\"col-12 text-center\">
                    <h1>";
        // line 122
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["sectionHeading"] ?? null), "name", [], "any", false, false, true, 122), 122, $this->source), "html", null, true);
        yield "</h1>
                </div>
            </div>
            <div class=\"testimonial__inner\">
                <div class=\"testimonial-slider\">

                    ";
        // line 128
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["testimonials"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 129
            yield "

                    <div class=\"testimonial-slide\">
                        <div class=\"testimonial_box\">
                            <div class=\"testimonial_box-inner\">
                                <div class=\"testimonial_box-top\">

                                    <div class=\"testimonial_box-text\">
                                        <p>";
            // line 137
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "testimonial", [], "any", false, false, true, 137), 137, $this->source), "html", null, true);
            yield "</p>
                                    </div>
                                    <div class=\"testimonial_box-name\">
                                        <h4>";
            // line 140
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "name", [], "any", false, false, true, 140), 140, $this->source), "html", null, true);
            yield "</h4>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>

                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['item'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 149
        yield "                </div>
            </div>
        </div>
    </div>
</section>
";
        // line 154
        $this->env->getExtension(\Cms\Twig\Extension::class)->yieldBlock('scripts'        , function() use ($context, $blocks, $macros) {
        // line 155
        yield "
<script>
    \$(document).ready(function () {
        \$('.testimonial-slider').slick({
            autoplay: true,
            autoplaySpeed: 1000,
            speed: 600,
            draggable: true,
            infinite: true,
            slidesToShow: 3,
            slidesToScroll: 1,
            arrows: true,
            dots: true,
            responsive: [
                {
                    breakpoint: 1680,
                    settings: {
                        slidesToShow: 2,
                        slidesToScroll: 1,
                    }
                },
                {
                    breakpoint: 575,
                    settings: {
                        slidesToShow: 1,
                        slidesToScroll: 1,
                    }
                }
            ]
        });
    });
</script>
";
        // line 154
        return; yield '';}, true        );
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "C:\\xampp\\htdocs\\myclinic\\themes/myclinic/partials/components/testimonial.htm";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  254 => 154,  220 => 155,  218 => 154,  211 => 149,  196 => 140,  190 => 137,  180 => 129,  176 => 128,  167 => 122,  44 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "C:\\xampp\\htdocs\\myclinic\\themes/myclinic/partials/components/testimonial.htm", "");
    }
    
    public function checkSecurity()
    {
        static $tags = ["for" => 128, "put" => 154];
        static $filters = ["escape" => 122];
        static $functions = [];

        try {
            $this->sandbox->checkSecurity(
                ['for', 'put'],
                ['escape'],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
