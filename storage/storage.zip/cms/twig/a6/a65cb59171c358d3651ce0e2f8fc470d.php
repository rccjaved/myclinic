<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* C:\xampp\htdocs\myclinic\themes/myclinic/pages/find-doctor.htm */
class __TwigTemplate_aefd200aa906d7c4618c7e3c63637ae1 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield "<!-- ======= BANNER START ======= -->

<div class=\"swiper-container resize-slider\">
  <!-- Additional required wrapper -->
  <div class=\"swiper-wrapper\">
    <!-- Slider -->
    ";
        // line 7
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["sliders"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 8
            yield "    <div class=\"swiper-slide\">
      
      <img src=\"";
            // line 10
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "slider_image_mobile", [], "any", false, false, true, 10), "path", [], "any", false, false, true, 10), 10, $this->source), "html", null, true);
            yield "\" class=\"slidemc\" alt=\"find a doctor\">
      <img src=\"";
            // line 11
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "slider_image", [], "any", false, false, true, 11), "path", [], "any", false, false, true, 11), 11, $this->source), "html", null, true);
            yield "\" class=\"slidemc slidemc-m-home\" alt=\"find a doctor\">
      <div class=\"slide-text\">
        <h1 class=\"mb-3\">";
            // line 13
            yield $this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "title", [], "any", false, false, true, 13), 13, $this->source);
            yield "</h1>
        <p class=\"mb-3 mb-sm-5\">";
            // line 14
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "tag_line", [], "any", false, false, true, 14), 14, $this->source), "html", null, true);
            yield "</p>
        ";
            // line 15
            if (Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "link_value", [], "any", false, false, true, 15)) {
                // line 16
                yield "        <a href=\"/ar/";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "link_value", [], "any", false, false, true, 16), 16, $this->source), "html", null, true);
                yield "\" class=\"btn btn-primary slide-s btn-mc-01 mb-6\"><svg
            xmlns=\"http://www.w3.org/2000/svg\" width=\"40\" height=\"40\" viewBox=\"0 0 40 40\" fill=\"none\"
            style=\"margin-right: 20px;\">
            <ellipse cx=\"20\" cy=\"19.6\" rx=\"20\" ry=\"19.6\" fill=\"white\" />
            <path d=\"M21.7727 14.3984L27.2 19.5984L21.7727 24.7984M27.048 19.5984H18.7148H12\" stroke=\"#003868\"
              stroke-width=\"2\" stroke-miterlimit=\"10\" stroke-linecap=\"round\" stroke-linejoin=\"round\" />
          </svg>";
                // line 22
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "link_name", [], "any", false, false, true, 22), 22, $this->source), "html", null, true);
                yield "</a>
        ";
            }
            // line 24
            yield "      </div>
    </div>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['item'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 27
        yield "  </div>
  <!-- If we need pagination -->
  <div class=\"swiper-pagination\"></div>

  <!-- If we need navigation buttons -->
  <div class=\"swiper-button-prev\"><span></span></div>
  <div class=\"swiper-button-next\"><span></span></div>




</div>


";
        // line 41
        if (($context["ourDoctor"] ?? null)) {
            // line 42
            yield "<!-- ======= BANNER END ======= -->
<section class=\"section-py-100\">
  <div class=\"container\">
    <div class=\"row justify-content-center\">
      <div class=\"col-12 col-xl-10 text-center\">
        <h1>";
            // line 47
            yield $this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["ourDoctor"] ?? null), "title", [], "any", false, false, true, 47), 47, $this->source);
            yield "</h1>
        <p>";
            // line 48
            yield $this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["ourDoctor"] ?? null), "description", [], "any", false, false, true, 48), 48, $this->source);
            yield "</p>
      </div>
    </div>
  </div>
</section>
";
        }
        // line 54
        yield "
<section class=\"section-py-100 pt-0\">
  <div class=\"container\">
    <div class=\"row shadow-none shadow-lg p-3\">
      <div class=\"col-12\">
        <div class=\"hero-search\">
          ";
        // line 60
        $cmsPartialParams = [];
        yield $this->env->getExtension(\Cms\Twig\Extension::class)->partialFunction("components/homePageSearch"        , array_merge($context, ['__cms_partial_params' => $cmsPartialParams], $cmsPartialParams)        , true        );
        // line 61
        yield "        </div>
      </div>
    </div>
    <!-- <div class=\"row\">

            <div class=\"col-12\">
              <form class=\"row search-form gy-2 align-items-center\" action=\"doctor-profile.html\">
                <div class=\"col-xl col-12\">
                  <select class=\"form-select form-select-lg select-mc\" id=\"autoSizingSelect\">
                    <option value=\"\">Location</option>
                    <option value=\"1\">Jeddah</option>
    
                  </select>
                </div>
                <div class=\"col-auto d-none\"><span>OR</span></div>
    
                <div class=\"col-xl col-12\">
                  <select class=\"form-select form-select-lg select-mc\" id=\"autoSizingSelect0\">
                    <option value=\"\">Speciality</option>
                    <option value=\"Cardiology\">Cardiology</option>
                  </select>
                </div>
                <div class=\"col-auto d-none\"><span>OR</span></div>
                <div class=\"col-xl col-12\">
                  <select class=\"form-select form-select-lg select-mc\" id=\"autoSizingSelect1\">
                    <option value=\"\">Doctor’s Name</option>
                    <option value=\"1\">Dr. Ahmad Alwazzan</option>
                  </select>
                </div>
                <div class=\"col-xl col-12\">
                  <select class=\"form-select form-select-lg select-mc\" id=\"autoSizingSelect2\">
                    <option value=\"\">Health Concerns</option>
                    <option value=\"heart\">Heart</option>
    
                  </select>
                </div>
                <div class=\"col-xl-auto col-12 text-center\">
                  <button class=\"btn btn-primary btn-mc-01 mx-auto\" type=\"submit\"><svg
                    xmlns=\"http://www.w3.org/2000/svg\" width=\"40\" height=\"40\" viewBox=\"0 0 40 40\" fill=\"none\"
                    style=\"margin-right: 20px;\">
                    <ellipse cx=\"20\" cy=\"19.6\" rx=\"20\" ry=\"19.6\" fill=\"white\" />
                    <path d=\"M21.7727 14.3984L27.2 19.5984L21.7727 24.7984M27.048 19.5984H18.7148H12\"
                      stroke=\"#003868\" stroke-width=\"2\" stroke-miterlimit=\"10\" stroke-linecap=\"round\"
                      stroke-linejoin=\"round\" />
                  </svg>Search</button>

                </div>
              </form>
            </div>
          </div> -->
  </div>
</section>

";
        // line 114
        $cmsPartialParams = [];
        $cmsPartialParams['testimonials'] = ($context["testimonials"] ?? null)        ;
        yield $this->env->getExtension(\Cms\Twig\Extension::class)->partialFunction("components/testimonial"        , array_merge($context, ['__cms_partial_params' => $cmsPartialParams], $cmsPartialParams)        , true        );
        // line 115
        yield "



";
        // line 119
        $cmsPartialParams = [];
        yield $this->env->getExtension(\Cms\Twig\Extension::class)->partialFunction("components/appDownload"        , array_merge($context, ['__cms_partial_params' => $cmsPartialParams], $cmsPartialParams)        , true        );
        // line 120
        yield "


<script>
  var mySwiper = new Swiper('.swiper-container', {
    effect: '',
    loop: false,
    speed: 1000,
    slidesPerView: 1,
    navigation: {
      nextEl: '.swiper-button-next',
      prevEl: '.swiper-button-prev'
    },
    pagination: {
      el: '.swiper-pagination',
      type: 'bullets',
      clickable: 'true'
    },
    autoplay: {
      delay: 3000,
      disableOnInteraction: false,
    },



  });



</script>";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "C:\\xampp\\htdocs\\myclinic\\themes/myclinic/pages/find-doctor.htm";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  219 => 120,  216 => 119,  210 => 115,  206 => 114,  151 => 61,  148 => 60,  140 => 54,  131 => 48,  127 => 47,  120 => 42,  118 => 41,  102 => 27,  94 => 24,  89 => 22,  79 => 16,  77 => 15,  73 => 14,  69 => 13,  64 => 11,  60 => 10,  56 => 8,  52 => 7,  44 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "C:\\xampp\\htdocs\\myclinic\\themes/myclinic/pages/find-doctor.htm", "");
    }
    
    public function checkSecurity()
    {
        static $tags = ["for" => 7, "if" => 15, "partial" => 60];
        static $filters = ["escape" => 10, "raw" => 13];
        static $functions = [];

        try {
            $this->sandbox->checkSecurity(
                ['for', 'if', 'partial'],
                ['escape', 'raw'],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
