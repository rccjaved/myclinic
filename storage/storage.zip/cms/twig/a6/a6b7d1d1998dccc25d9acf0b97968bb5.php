<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* C:\xampp\htdocs\myclinic\themes/myclinic/pages/ar/doctor-detail.htm */
class __TwigTemplate_1ec505025b8219384b5aae4cf4ec8922 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield "<!-- ======= BANNER START ======= -->
<section class=\"doctor-detail-bg detail-padding pb-0\">
    <div class=\"container\">
        <div class=\"row align-items-center\">
            <div class=\"col-12 col-sm-6\">
                <img src=\"";
        // line 6
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["doctor"] ?? null), "doctor_detail_image", [], "any", false, false, true, 6), "path", [], "any", false, false, true, 6), 6, $this->source), "html", null, true);
        yield "\" class=\"img-fluid doc-img-detail\" alt=\"\">
            </div>
            <div class=\"col-12 col-sm-6\">
                <div class=\"text-end description-wrap\">
                    ";
        // line 10
        if (Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["doctor"] ?? null), "designation_ar", [], "any", false, false, true, 10)) {
            // line 11
            yield "                        <h1 class=\"pt-3 pt-md-0\">
                            <span>";
            // line 12
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["doctor"] ?? null), "designation_ar", [], "any", false, false, true, 12), 12, $this->source), "html", null, true);
            yield "</span>&nbsp;";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["doctor"] ?? null), "name_ar", [], "any", false, false, true, 12), 12, $this->source), "html", null, true);
            yield "
                        </h1>
                    ";
        } else {
            // line 15
            yield "                        <h1 class=\"pt-3 pt-md-0\">";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["doctor"] ?? null), "name_ar", [], "any", false, false, true, 15), 15, $this->source), "html", null, true);
            yield "</h1>
                    ";
        }
        // line 17
        yield "                    <p class=\"doc-specialty\">";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["doctor"] ?? null), "specialty_desc_ar", [], "any", false, false, true, 17), 17, $this->source), "html", null, true);
        yield "</p>

                    <div class=\"edu-wrap\">
                        <div class=\"edu-tag\">التعليم</div>
                        <h2>";
        // line 21
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["doctor"] ?? null), "highest_degree_ar", [], "any", false, false, true, 21), 21, $this->source), "html", null, true);
        yield "</h2>
                    </div>

                    <ul class=\"dr-pro-list text-end dr-pro-list-en\">
                        <li> الموقع: ";
        // line 25
        yield $this->sandbox->ensureToStringAllowed(($context["doctor_locations"] ?? null), 25, $this->source);
        yield "</li>
                        <li>اللغات : ";
        // line 26
        yield $this->sandbox->ensureToStringAllowed(($context["doctor_language"] ?? null), 26, $this->source);
        yield " </li>
                    </ul>
                    ";
        // line 28
        if (($context["isButtonVisible"] ?? null)) {
            // line 29
            yield "                        ";
            if (($context["isBookNow"] ?? null)) {
                // line 30
                yield "                        ";
                if ((($_v0 = ($context["bookingLinks"] ?? null)) && is_array($_v0) || $_v0 instanceof ArrayAccess ? ($_v0[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["doctor"] ?? null), "doctor_app_id", [], "any", false, false, true, 30)] ?? null) : null)) {
                    // line 31
                    yield "                        <a href=\"";
                    yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed((($_v1 = ($context["bookingLinks"] ?? null)) && is_array($_v1) || $_v1 instanceof ArrayAccess ? ($_v1[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["doctor"] ?? null), "doctor_app_id", [], "any", false, false, true, 31)] ?? null) : null), 31, $this->source), "html", null, true);
                    yield "\"class=\"btn btn-primary btn-mc-01 float-end\">
                            <svg class=\"ms-3\" xmlns=\"http://www.w3.org/2000/svg\" width=\"40\" height=\"40\" viewBox=\"0 0 40 40\" fill=\"none\">
                                <ellipse cx=\"20\" cy=\"19.6\" rx=\"20\" ry=\"19.6\" fill=\"white\" />
                                <path d=\"M21.7727 14.3984L27.2 19.5984L21.7727 24.7984M18.7148 19.5984H27.048M12 19.5984H21.5\"
                                    stroke=\"#003868\" stroke-width=\"2\" stroke-miterlimit=\"10\" stroke-linecap=\"round\"
                                    stroke-linejoin=\"round\" />
                            </svg>احجز الآن
                        </a>
                        ";
                } else {
                    // line 40
                    yield "                        <a href=\"https://bamc.myclinic.com.sa:8443\"class=\"btn btn-primary btn-mc-01 float-end\">
                            <svg class=\"ms-3\" xmlns=\"http://www.w3.org/2000/svg\" width=\"40\" height=\"40\" viewBox=\"0 0 40 40\" fill=\"none\">
                                <ellipse cx=\"20\" cy=\"19.6\" rx=\"20\" ry=\"19.6\" fill=\"white\" />
                                <path d=\"M21.7727 14.3984L27.2 19.5984L21.7727 24.7984M18.7148 19.5984H27.048M12 19.5984H21.5\"
                                    stroke=\"#003868\" stroke-width=\"2\" stroke-miterlimit=\"10\" stroke-linecap=\"round\"
                                    stroke-linejoin=\"round\" />
                            </svg>احجز الآن
                        </a>
                        ";
                }
                // line 49
                yield "                        ";
            } else {
                // line 50
                yield "                        <a href=\"/ar/contact-us\" class=\"btn btn-primary btn-mc-01 float-end\">
                            <svg class=\"ms-3\" xmlns=\"http://www.w3.org/2000/svg\" width=\"40\" height=\"40\" viewBox=\"0 0 40 40\" fill=\"none\">
                                <ellipse cx=\"20\" cy=\"19.6\" rx=\"20\" ry=\"19.6\" fill=\"white\" />
                                <path d=\"M21.7727 14.3984L27.2 19.5984L21.7727 24.7984M18.7148 19.5984H27.048M12 19.5984H21.5\"
                                    stroke=\"#003868\" stroke-width=\"2\" stroke-miterlimit=\"10\" stroke-linecap=\"round\"
                                    stroke-linejoin=\"round\" />
                            </svg>اسألنا
                        </a>
                        ";
            }
            // line 59
            yield "                    ";
        }
        // line 60
        yield "                </div>
            </div>
        </div>
    </div>
    <img class=\"img-doc-background-tec\" src=\"";
        // line 64
        yield $this->extensions['Cms\Twig\Extension']->themeFilter("assets/imgs/ask-us.png");
        yield "\">
</section>
<!-- ======= BANNER END ======= -->

";
        // line 68
        $cmsPartialParams = [];
        $cmsPartialParams['testimonials'] = ($context["testimonials"] ?? null)        ;
        yield $this->env->getExtension(\Cms\Twig\Extension::class)->partialFunction("components/testimonial-ar"        , array_merge($context, ['__cms_partial_params' => $cmsPartialParams], $cmsPartialParams)        , true        );
        // line 69
        yield "
<!-- ======= OUR DOCTORS START ======= -->
<section class=\"section-py-120\">
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-12 text-center py-60 pt-0\">
                <h1 class=\"\">أطباء مماثلين</h1>
            </div>
        </div>
        <div class=\"row similar-doctors-container\">
            ";
        // line 79
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["similar_doctor"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 80
            yield "            <div class=\"col-12 col-sm-6 col-xl-4 col-xxl-3 mc-hide-2\">
                <div class=\"doctor-card\">
                    <div class=\"doctor-img-2 text-center\">
                        <img src=\"";
            // line 83
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "doctor_image", [], "any", false, false, true, 83), "path", [], "any", false, false, true, 83), 83, $this->source), "html", null, true);
            yield "\" class=\"img-fluid\" alt=\"\" style=\"border-radius: 50%;\">
                    </div>
                    <h3><span>";
            // line 85
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "designation_ar", [], "any", false, false, true, 85), 85, $this->source), "html", null, true);
            yield "</span>&nbsp;";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "name_ar", [], "any", false, false, true, 85), 85, $this->source), "html", null, true);
            yield "</h3>
                    <div class=\"dr-specialities\">";
            // line 86
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "specialty_desc_ar", [], "any", false, false, true, 86), 86, $this->source), "html", null, true);
            yield "</div>

                    <div class=\" row hide\">
                        <div class=\"col-12 text-center\">
                            <p style=\"margin-bottom: 0px;\"><a href=\"/ar/doctor-detail/";
            // line 90
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "id", [], "any", false, false, true, 90), 90, $this->source), "html", null, true);
            yield "\"
                                    style=\"text-decoration: none; color: white;\">";
            // line 91
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "highest_degree_ar", [], "any", false, false, true, 91), 91, $this->source), "html", null, true);
            yield "</a></p>
                        </div>
                    </div>
                    
                    <div class=\"dr-calendar my-4\" style=\"direction: rtl;\" id=\"doctor-availability-";
            // line 95
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 95), 95, $this->source), "html", null, true);
            yield "\">
                        <!-- Loading spinner will be shown initially -->
                        <div class=\"loading-spinner text-center py-3\">
                            <div class=\"spinner-border text-primary\" role=\"status\">
                                <span class=\"sr-only\">جار التحميل...</span>
                            </div>
                        </div>
                    </div>
                
                    <div class=\"d-flex justify-content-around\">
                        <div class=\"w-100 mt-50\">
                            <a href=\"/ar/doctor-detail/";
            // line 106
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 106), 106, $this->source), "html", null, true);
            yield "\" class=\"btn btn-light btn-dr-card w-100 profile-link\">
                                <span class=\"btn-text\">الحساب التعريفي</span>
                                <span class=\"spinner-border spinner-border-sm d-none\" role=\"status\"></span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['item'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 115
        yield "            <div class=\"col-12 mt-3\">
                <a href=\"#\" class=\"btn btn-view-all btn-outline-dark view-more-dr\">
                    <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"40\" height=\"40\" viewBox=\"0 0 40 40\" fill=\"none\">
                        <ellipse cx=\"20\" cy=\"19.6\" rx=\"20\" ry=\"19.6\" fill=\"#003868\" />
                        <path d=\"M24.7969 21.7727L19.5969 27.2L14.3969 21.7727M19.5969 18.7148L19.5969 27.048M19.5969 12L19.5969 21.5\"
                            stroke=\"white\" stroke-width=\"2\" stroke-miterlimit=\"10\" stroke-linecap=\"round\"
                            stroke-linejoin=\"round\" />
                    </svg>عرض المزيد من الأطباء
                </a>
            </div>
        </div>
    </div>
</section>
<!-- ======= OUR DOCTORS END ======= -->

<style>
.loading-spinner {
    min-height: 120px;
    display: flex;
    align-items: center;
    justify-content: center;
}

.spinner-border {
    width: 2rem;
    height: 2rem;
}

.profile-link {
    position: relative;
}
.profile-link .btn-text {
    transition: opacity 0.2s;
}
.profile-link.loading .btn-text {
    opacity: 0;
}
.profile-link.loading .spinner-border {
    position: absolute;
    left: 50%;
    top: 50%;
    transform: translate(-50%, -50%);
    display: inline-block !important;
}

.skeleton-loader {
    padding: 10px;
    direction: rtl;
}
.skeleton-line {
    height: 12px;
    background: #f0f0f0;
    margin-bottom: 8px;
    border-radius: 4px;
    animation: pulse 1.5s infinite ease-in-out;
}

@keyframes pulse {
    0% { opacity: 0.6; }
    50% { opacity: 1; }
    100% { opacity: 0.6; }
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Arabic number and month mappings
    const arabicNumbers = {
        '0':'٠', '1':'١', '2':'٢', '3':'٣', '4':'٤', '5':'٥', '6':'٦', '7':'٧', '8':'٨', '9':'٩',
        'AM': 'ص', 'PM': 'م',
        'Jan': 'يناير', 'Feb': 'فبراير', 'Mar': 'مارس', 'Apr': 'أبريل', 'May': 'مايو', 'Jun': 'يونيو',
        'Jul': 'يوليو', 'Aug': 'أغسطس', 'Sep': 'سبتمبر', 'Oct': 'أكتوبر', 'Nov': 'نوفمبر', 'Dec': 'ديسمبر'
    };

    // Convert English to Arabic
    function toArabic(text) {
        return text.replace(/[0-9AMPMJanFebMarAprMayJunJulAugSepOctNovDec]+/g, 
            match => arabicNumbers[match] || match.split('').map(c => arabicNumbers[c] || c).join(''));
    }

    // Load availability for similar doctors
    function loadSimilarDoctorsAvailability() {
        const doctorCards = document.querySelectorAll('.similar-doctors-container .doctor-card');
        
        doctorCards.forEach((card, index) => {
            const doctorId = card.querySelector('.dr-calendar').id.replace('doctor-availability-', '');
            
            // Set timeout with increasing delay
            setTimeout(() => {
                fetchAvailability(doctorId);
            }, index * 500);
        });
    }

    // Fetch availability data
    function fetchAvailability(doctorId) {
        const container = document.getElementById('doctor-availability-' + doctorId);
        
        // Show skeleton loader
        container.innerHTML = `
            <div class=\"skeleton-loader\">
                <div class=\"skeleton-line\" style=\"width: 80%\"></div>
                <div class=\"skeleton-line\" style=\"width: 60%\"></div>
                <div class=\"skeleton-line\" style=\"width: 70%\"></div>
            </div>
        `;
        
        fetch(window.location.href, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-Requested-With': 'XMLHttpRequest',
                'X-OCTOBER-REQUEST-HANDLER': 'onSimilarDoctorsAvailability',
                'X-OCTOBER-REQUEST-PARTIALS': ''
            },
            body: JSON.stringify({
                doctor_id: doctorId
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.availableDates) {
                const date = new Date(data.availableDates.latest_date.date);
                const time = data.availableDates.latest_time;
                
                // Format time to 12-hour format
                const timeParts = time.split(':');
                let hours = parseInt(timeParts[0]);
                const minutes = timeParts[1];
                const ampm = hours >= 12 ? 'PM' : 'AM';
                hours = hours % 12;
                hours = hours ? hours : 12;
                const formattedTime = hours + ':' + minutes + ' ' + ampm;
                
                // Format date in Arabic
                const formattedDate = date.toLocaleDateString('ar-EG', {
                    day: 'numeric',
                    month: 'short',
                    year: 'numeric'
                });
                
                container.innerHTML = `
                    <div class=\"dr-calendar-text text-center\">
                        <p><strong>أقرب موعد متاح</strong></p>
                        <p style=\"font-size: 12px;\"><strong>\${data.availableDates.company_name}</strong></p>
                    </div>
                    <div class=\"dr-calendar-flex\">
                        <a class=\"dr-cale\">\${formattedDate}</a>
                        <a class=\"dr-cale\">\${toArabic(formattedTime)}</a>
                    </div>
                `;
                
                // Update buttons container
                const buttonsContainer = container.closest('.doctor-card').querySelector('.d-flex.justify-content-around');
                buttonsContainer.innerHTML = `
                    <div>
                    <a href=\"\${data.bookingLink}\" class=\"btn btn-dr-card-2 rtl-button\">
                        <span class=\"button-text\">احجز الآن</span> 
                        
                        <svg width=\"28\" height=\"27\" viewBox=\"0 0 28 27\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">
                        <ellipse cx=\"13.7306\" cy=\"13.7772\" rx=\"13.4181\" ry=\"13.1913\" fill=\"white\" />
                        <path class=\"arr-cl\" d=\"M14.9238 10.2812L18.565 13.781L14.9238 17.2807M12.8722 13.781H18.463M8.36719 13.781H14.7408\" stroke=\"#003868\" stroke-width=\"2\" stroke-miterlimit=\"10\" stroke-linecap=\"round\" stroke-linejoin=\"round\" />
                        </svg>
                    </a>
                    </div>
                    <div>
                        <a href=\"/ar/doctor-detail/\${doctorId}\" class=\"btn btn-light btn-dr-card profile-link\">
                            <span class=\"btn-text\">الحساب التعريفي</span>
                            <span class=\"spinner-border spinner-border-sm d-none\" role=\"status\"></span>
                        </a>
                    </div>
                `;
            } else {
                container.innerHTML = '<p class=\"text-center py-3\"></p>';
                const buttonsContainer = container.closest('.doctor-card').querySelector('.d-flex.justify-content-around');
                buttonsContainer.innerHTML = `
                    <div class=\"w-100 mt-50\">
                        <a href=\"/ar/doctor-detail/\${doctorId}\" class=\"btn btn-light btn-dr-card w-100 profile-link\">
                            
                            <span class=\"btn-text\">الحساب التعريفي</span>
                            <span class=\"spinner-border spinner-border-sm d-none\" role=\"status\"></span>
                        </a>
                    </div>
                `;
            }
        })
        .catch(error => {
            console.error('Error fetching availability:', error);
            container.innerHTML = '<p class=\"text-center py-3\">خطأ في تحميل البيانات</p>';
        });
    }

    // Add loading state for profile links
    document.addEventListener('click', function(e) {
        if (e.target.closest('.profile-link')) {
            e.target.closest('.profile-link').classList.add('loading');
        }
    });

    // Start loading similar doctors availability
    loadSimilarDoctorsAvailability();

    // Prefetch data on hover
    document.querySelectorAll('.doctor-card').forEach(card => {
        card.addEventListener('mouseenter', function() {
            const doctorId = this.querySelector('.dr-calendar').id.replace('doctor-availability-', '');
            if (!this.dataset.prefetched) {
                fetchAvailability(doctorId);
                this.dataset.prefetched = true;
            }
        });
    });
});
</script>";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "C:\\xampp\\htdocs\\myclinic\\themes/myclinic/pages/ar/doctor-detail.htm";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  246 => 115,  231 => 106,  217 => 95,  210 => 91,  206 => 90,  199 => 86,  193 => 85,  188 => 83,  183 => 80,  179 => 79,  167 => 69,  163 => 68,  156 => 64,  150 => 60,  147 => 59,  136 => 50,  133 => 49,  122 => 40,  109 => 31,  106 => 30,  103 => 29,  101 => 28,  96 => 26,  92 => 25,  85 => 21,  77 => 17,  71 => 15,  63 => 12,  60 => 11,  58 => 10,  51 => 6,  44 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "C:\\xampp\\htdocs\\myclinic\\themes/myclinic/pages/ar/doctor-detail.htm", "");
    }
    
    public function checkSecurity()
    {
        static $tags = ["if" => 10, "partial" => 68, "for" => 79];
        static $filters = ["escape" => 6, "raw" => 25, "theme" => 64];
        static $functions = [];

        try {
            $this->sandbox->checkSecurity(
                ['if', 'partial', 'for'],
                ['escape', 'raw', 'theme'],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
