<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* C:\xampp\htdocs\myclinic\themes/myclinic/pages/ar/location-search-specialty-detail.htm */
class __TwigTemplate_cdb67966cf5cec4a30004f95d201785f extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield "<!-- ======= BANNER START ======= -->
<section class=\"section-bg\">
    <div class=\"container-fluid\">
        <div class=\"row align-items-center\">
            <div class=\"col-12 col-sm-6 text-center text-sm-start px-0\">
                <div class=\"mc-block text-end\">
                    <h1>";
        // line 7
        yield $this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["specialty"] ?? null), "name_ar", [], "any", false, false, true, 7), 7, $this->source);
        yield "</h1>
                    <p>";
        // line 8
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["specialty"] ?? null), "tag_line_ar", [], "any", false, false, true, 8), 8, $this->source), "html", null, true);
        yield "</p>
                </div>
            </div>
            <div class=\"col-12 col-sm-6 px-0\">
                <div class=\"position-relative search-doctor-list\">
                    <img src=\"";
        // line 13
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["specialty"] ?? null), "specialty_banner_image", [], "any", false, false, true, 13), "path", [], "any", false, false, true, 13), 13, $this->source), "html", null, true);
        yield "\" class=\"img-fluid\" alt=\"\">
                    <form class=\"row row-cols-2 g-2 g-lg-3 dr-search-form align-items-center\" id=\"search-form\">
                        <div class=\"col-12\">
                            <label class=\"visually-hidden\" for=\"autoSizingSelect\">Preference</label>
                            <span class=\"select2-selection__arrow\" role=\"presentation\"><b
                                    role=\"presentation\"></b></span>
                            <select class=\"form-select form-select-lg select-mc\" id=\"location\">
                                ";
        // line 20
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["locations"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 21
            yield "                                ";
            if ((Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 21) == Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["location"] ?? null), "id", [], "any", false, false, true, 21))) {
                // line 22
                yield "                                <option value=\"";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["location"] ?? null), "id", [], "any", false, false, true, 22), 22, $this->source), "html", null, true);
                yield "\" selected>";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["location"] ?? null), "name_ar", [], "any", false, false, true, 22), 22, $this->source), "html", null, true);
                yield "</option>
                                ";
            } else {
                // line 24
                yield "                                <option value=";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 24), 24, $this->source), "html", null, true);
                yield ">";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "name_ar", [], "any", false, false, true, 24), 24, $this->source), "html", null, true);
                yield "</option>
                                ";
            }
            // line 26
            yield "                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['item'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 27
        yield "                            </select>
                        </div>

                        <div class=\"col\">
                            <label class=\"visually-hidden\" for=\"autoSizingSelect\">Preference</label>
                            <select class=\"form-select form-select-lg select-mc\" id=\"doctor\">
                                <option value=\"\"> التخصصات </option>
                                ";
        // line 34
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["optionDoctorList"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 35
            yield "                                <option value=";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 35), 35, $this->source), "html", null, true);
            yield "><span>
                                        ";
            // line 36
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "designation_ar", [], "any", false, false, true, 36), 36, $this->source), "html", null, true);
            yield "
                                    </span>";
            // line 37
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "name_ar", [], "any", false, false, true, 37), 37, $this->source), "html", null, true);
            yield "</option>
                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['item'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 39
        yield "                            </select>
                        </div>


                        <div class=\"col\">
                            <label class=\"visually-hidden\" for=\"autoSizingSelect\">Preference</label>
                            <select class=\"form-select form-select-lg select-mc\" id=\"specialty\">
                                <option value=\"\">اسم الطبيب
                                </option>
                                ";
        // line 48
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["specialties"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 49
            yield "                                ";
            if ((Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "slug", [], "any", false, false, true, 49) == Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["specialty"] ?? null), "slug", [], "any", false, false, true, 49))) {
                // line 50
                yield "                                <option value=\"";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["specialty"] ?? null), "slug", [], "any", false, false, true, 50), 50, $this->source), "html", null, true);
                yield "\" selected>";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["specialty"] ?? null), "name_ar", [], "any", false, false, true, 50), 50, $this->source), "html", null, true);
                yield "</option>
                                ";
            } else {
                // line 52
                yield "                                <option value=";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "slug", [], "any", false, false, true, 52), 52, $this->source), "html", null, true);
                yield ">";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "name_ar", [], "any", false, false, true, 52), 52, $this->source), "html", null, true);
                yield "</option>
                                ";
            }
            // line 54
            yield "                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['item'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 55
        yield "                            </select>
                        </div>


                        <div class=\"col-12\">
                            <button
                                class=\"btn btn-primary btn-mc-search mc-search mb-4 mb-sm-0 mx-auto search-icon-degree\"><svg
                                    xmlns=\"http://www.w3.org/2000/svg\" width=\"49\" height=\"48\" viewBox=\"0 0 49 48\"
                                    fill=\"none\">
                                    <ellipse cx=\"24.2\" cy=\"23.716\" rx=\"24.2\" ry=\"23.716\" fill=\"white\" />
                                    <path
                                        d=\"M22.8362 15.7266C26.0961 15.7266 28.735 18.3655 28.735 21.6253C28.735 24.8852 26.0961 27.5241 22.8362 27.5241C19.5764 27.5241 16.9375 24.8852 16.9375 21.6253C16.9375 19.3279 18.2476 17.341 20.1663 16.3661M32.6675 31.4566L27.2225 26.0116\"
                                        stroke=\"#003868\" stroke-width=\"1.452\" stroke-miterlimit=\"10\"
                                        stroke-linecap=\"round\" stroke-linejoin=\"round\" />
                                </svg>ابحث
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- ======= BANNER END ======= -->


<!-- ======= OUR DOCTORS  START ======= -->
<section class=\"mt-5\">
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-12 text-center section-py-100 pt-0\">
                <h1 class=\"\">أطباؤنا</h1>
            </div>
        </div>

        <div class=\"row\" dir=\"rtl\">
            ";
        // line 91
        if (($context["hod"] ?? null)) {
            // line 92
            yield "            <div class=\"col-12 col-sm-6 col-xl-4 col-xxl-3\">
                <a href=\"javascript:void(0)\" onclick=\"GoLinks(event,'/doctor-detail/'+'";
            // line 93
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "id", [], "any", false, false, true, 93), 93, $this->source), "html", null, true);
            yield "')\">
                    <div class=\"doctor-card\">

                        <a href=\"/ar/doctor-detail/";
            // line 96
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "id", [], "any", false, false, true, 96), 96, $this->source), "html", null, true);
            yield "\">
                            <div class=\"doctor-img-001 text-center\">
                                <img src=\"";
            // line 98
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "doctor_image", [], "any", false, false, true, 98), "path", [], "any", false, false, true, 98), 98, $this->source), "html", null, true);
            yield "\" class=\"img-fluid\" alt=\"\"
                                    style=\"border-radius: 50%;\">
                            </div>
                        </a>

                        <a href=\"/ar/doctor-detail/";
            // line 103
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "id", [], "any", false, false, true, 103), 103, $this->source), "html", null, true);
            yield "\" style=\"text-decoration: none;\">
                            <h3> <span>
                                    ";
            // line 105
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "designation_ar", [], "any", false, false, true, 105), 105, $this->source), "html", null, true);
            yield "
                                </span>";
            // line 106
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "name_ar", [], "any", false, false, true, 106), 106, $this->source), "html", null, true);
            yield "</h3>
                        </a>

                        <div class=\"dr-specialities drspecialty-truncate my-3\"><a href=\"/ar/doctor-detail/";
            // line 109
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "id", [], "any", false, false, true, 109), 109, $this->source), "html", null, true);
            yield "\"
                                style=\"text-decoration: none;\"
                                class=\"dr-specialities drspecialty-truncate\">";
            // line 111
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "specialty_desc_ar", [], "any", false, false, true, 111), 111, $this->source), "html", null, true);
            yield "</a></div>


                        <div class=\" row hide\">
                            <div class=\"col-12 text-center\">
                                <p style=\"margin-bottom: 0px;\"><a href=\"/ar/doctor-detail/";
            // line 116
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "id", [], "any", false, false, true, 116), 116, $this->source), "html", null, true);
            yield "\"
                                        style=\"text-decoration: none; color: white;\">";
            // line 117
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "highest_degree_ar", [], "any", false, false, true, 117), 117, $this->source), "html", null, true);
            yield "</a></p>
                            </div>
                        </div>
                        ";
            // line 121
            yield "                        ";
            $context["arabicNumbers"] = ["0" => "٠", "1" => "١", "2" => "٢", "3" => "٣", "4" => "٤", "5" => "٥", "6" => "٦", "7" => "٧", "8" => "٨", "9" => "٩", "AM" => "ص", "PM" => "م", "Jan" => "يناير", "Feb" => "فبراير", "Mar" => "مارس", "Apr" => "أبريل", "May" => "مايو", "Jun" => "يونيو", "Jul" => "يوليو", "Aug" => "أغسطس", "Sep" => "سبتمبر", "Oct" => "أكتوبر", "Nov" => "نوفمبر", "Dec" => "ديسمبر"];
            // line 127
            yield "                        


                        <div class=\"dr-calendar my-4\" style=\"direction: rtl;\">
                            ";
            // line 131
            if (((($_v0 = ($context["availableDates"] ?? null)) && is_array($_v0) || $_v0 instanceof ArrayAccess ? ($_v0[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "id", [], "any", false, false, true, 131)] ?? null) : null) && (($_v1 = ($context["bookingLinks"] ?? null)) && is_array($_v1) || $_v1 instanceof ArrayAccess ? ($_v1[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "id", [], "any", false, false, true, 131)] ?? null) : null))) {
                // line 132
                yield "                            <div class=\"dr-calendar-text text-center\">
                                <p><strong>أقرب موعد متاح</strong></p>
                                <p style=\"font-size: 12px;\"><strong>";
                // line 134
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, (($_v2 = ($context["availableDates"] ?? null)) && is_array($_v2) || $_v2 instanceof ArrayAccess ? ($_v2[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "id", [], "any", false, false, true, 134)] ?? null) : null), "company_name", [], "any", false, false, true, 134), 134, $this->source), "html", null, true);
                yield "</strong></p>
                            </div>
                            <div class=\"dr-calendar-flex\">
                                <a class=\"dr-cale\">";
                // line 137
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::replace($this->extensions['Twig\Extension\CoreExtension']->formatDate($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, (($_v3 = ($context["availableDates"] ?? null)) && is_array($_v3) || $_v3 instanceof ArrayAccess ? ($_v3[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "id", [], "any", false, false, true, 137)] ?? null) : null), "latest_date", [], "any", false, false, true, 137), 137, $this->source), "j-M-Y"), $this->sandbox->ensureToStringAllowed(                // line 138
($context["arabicNumbers"] ?? null), 138, $this->source)), "html", null, true);
                yield "</a>
                                <a class=\"dr-cale\">";
                // line 139
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::replace($this->extensions['Twig\Extension\CoreExtension']->formatDate($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, (($_v4 = ($context["availableDates"] ?? null)) && is_array($_v4) || $_v4 instanceof ArrayAccess ? ($_v4[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "id", [], "any", false, false, true, 139)] ?? null) : null), "latest_time", [], "any", false, false, true, 139), 139, $this->source), "h:i A"), $this->sandbox->ensureToStringAllowed(                // line 140
($context["arabicNumbers"] ?? null), 140, $this->source)), "html", null, true);
                yield "</a>

                            </div>
                            ";
            }
            // line 144
            yield "                        </div>

                        <div class=\"d-flex justify-content-around\">
                            <div class=\"";
            // line 147
            if ( !(($_v5 = ($context["bookingLinks"] ?? null)) && is_array($_v5) || $_v5 instanceof ArrayAccess ? ($_v5[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "id", [], "any", false, false, true, 147)] ?? null) : null)) {
                yield "w-100 mt-40";
            }
            yield "\">
                                <button href=\"javascript:void(0)\"
                                    onclick=\"GoLinks(event,'/ar/doctor-detail/'+'";
            // line 149
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "id", [], "any", false, false, true, 149), 149, $this->source), "html", null, true);
            yield "')\"
                                    class=\"btn btn-light btn-dr-card ";
            // line 150
            if ( !(($_v6 = ($context["bookingLinks"] ?? null)) && is_array($_v6) || $_v6 instanceof ArrayAccess ? ($_v6[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "id", [], "any", false, false, true, 150)] ?? null) : null)) {
                yield "w-100";
            }
            yield "\">
                                    الحساب التعريفي
                                </button>
                            </div>
                            &nbsp;
                            ";
            // line 155
            if (($context["canBook"] ?? null)) {
                // line 156
                yield "                            <div>
                                ";
                // line 157
                if (($context["isMobile"] ?? null)) {
                    // line 158
                    yield "                                <a href=\"/ar/contact-us\"
                                    class=\"btn btn-dr-card-2 ";
                    // line 159
                    if ( !(($_v7 = ($context["bookingLinks"] ?? null)) && is_array($_v7) || $_v7 instanceof ArrayAccess ? ($_v7[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "id", [], "any", false, false, true, 159)] ?? null) : null)) {
                        yield "mt-40";
                    }
                    yield "\">
                                    <svg width=\"28\" height=\"27\" viewBox=\"0 0 28 27\" fill=\"none\"
                                        xmlns=\"http://www.w3.org/2000/svg\">
                                        <ellipse cx=\"13.7306\" cy=\"13.7772\" rx=\"13.4181\" ry=\"13.1913\" fill=\"white\" />
                                        <path class=\"arr-cl\"
                                            d=\"M14.9238 10.2812L18.565 13.781L14.9238 17.2807M12.8722 13.781H18.463M8.36719 13.781H14.7408\"
                                            stroke=\"#003868\" stroke-width=\"2\" stroke-miterlimit=\"10\"
                                            stroke-linecap=\"round\" stroke-linejoin=\"round\" />
                                    </svg>
                                    اسألنا
                                </a>
                                ";
                } else {
                    // line 171
                    yield "                                ";
                    if ((($_v8 = ($context["bookingLinks"] ?? null)) && is_array($_v8) || $_v8 instanceof ArrayAccess ? ($_v8[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "id", [], "any", false, false, true, 171)] ?? null) : null)) {
                        // line 172
                        yield "                                <button href=\"javascript:void(0)\" onclick=\"GoLinks(event, '";
                        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed((($_v9 = ($context["bookingLinks"] ?? null)) && is_array($_v9) || $_v9 instanceof ArrayAccess ? ($_v9[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["hod"] ?? null), "id", [], "any", false, false, true, 172)] ?? null) : null), 172, $this->source), "html", null, true);
                        yield "')\"
                                    class=\"btn btn-dr-card-2\">
                                    <svg width=\"28\" height=\"27\" viewBox=\"0 0 28 27\" fill=\"none\"
                                        xmlns=\"http://www.w3.org/2000/svg\">
                                        <ellipse cx=\"13.7306\" cy=\"13.7772\" rx=\"13.4181\" ry=\"13.1913\" fill=\"white\" />
                                        <path class=\"arr-cl\"
                                            d=\"M14.9238 10.2812L18.565 13.781L14.9238 17.2807M12.8722 13.781H18.463M8.36719 13.781H14.7408\"
                                            stroke=\"#003868\" stroke-width=\"2\" stroke-miterlimit=\"10\"
                                            stroke-linecap=\"round\" stroke-linejoin=\"round\" />
                                    </svg>
                                    احجز الآن
                                </button>
                                ";
                    }
                    // line 185
                    yield "                                ";
                }
                // line 186
                yield "                            </div>
                            ";
            }
            // line 188
            yield "                        </div>

                    </div>
                </a>
            </div>
            ";
        }
        // line 194
        yield "            ";
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["doctors"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 195
            yield "            <div class=\"col-12 col-sm-6 col-xl-4 col-xxl-3\">
                <a href=\"javascript:void(0)\" onclick=\"GoLinks(event,'/ar/doctor-detail/'+'";
            // line 196
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 196), 196, $this->source), "html", null, true);
            yield "')\">
                    <div class=\"doctor-card\">

                        <a href=\"/ar/doctor-detail/";
            // line 199
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 199), 199, $this->source), "html", null, true);
            yield "\">
                            <div class=\"doctor-img-001 text-center\">
                                <img src=\"";
            // line 201
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "doctor_image", [], "any", false, false, true, 201), "path", [], "any", false, false, true, 201), 201, $this->source), "html", null, true);
            yield "\" class=\"img-fluid\" alt=\"\"
                                    style=\"border-radius: 50%;\">
                            </div>
                        </a>

                        <a href=\"/ar/doctor-detail/";
            // line 206
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 206), 206, $this->source), "html", null, true);
            yield "\" style=\"text-decoration: none;\">
                            <h3> <span>
                                    ";
            // line 208
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "designation_ar", [], "any", false, false, true, 208), 208, $this->source), "html", null, true);
            yield "
                                </span>";
            // line 209
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "name_ar", [], "any", false, false, true, 209), 209, $this->source), "html", null, true);
            yield "</h3>
                        </a>

                        <div class=\"dr-specialities drspecialty-truncate my-3\"><a href=\"/ar/doctor-detail/";
            // line 212
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 212), 212, $this->source), "html", null, true);
            yield "\"
                                style=\"text-decoration: none;\"
                                class=\"dr-specialities drspecialty-truncate\">";
            // line 214
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "specialty_desc_ar", [], "any", false, false, true, 214), 214, $this->source), "html", null, true);
            yield "</a></div>


                        <div class=\" row hide\">
                            <div class=\"col-12 text-center\">
                                <p style=\"margin-bottom: 0px\"><a href=\"/ar/doctor-detail/";
            // line 219
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 219), 219, $this->source), "html", null, true);
            yield "\"
                                        style=\"text-decoration: none; color: white;\">";
            // line 220
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "highest_degree_ar", [], "any", false, false, true, 220), 220, $this->source), "html", null, true);
            yield "</a></p>
                            </div>
                        </div>
                        ";
            // line 224
            yield "                        ";
            $context["arabicNumbers"] = ["0" => "٠", "1" => "١", "2" => "٢", "3" => "٣", "4" => "٤", "5" => "٥", "6" => "٦", "7" => "٧", "8" => "٨", "9" => "٩", "AM" => "ص", "PM" => "م", "Jan" => "يناير", "Feb" => "فبراير", "Mar" => "مارس", "Apr" => "أبريل", "May" => "مايو", "Jun" => "يونيو", "Jul" => "يوليو", "Aug" => "أغسطس", "Sep" => "سبتمبر", "Oct" => "أكتوبر", "Nov" => "نوفمبر", "Dec" => "ديسمبر"];
            // line 230
            yield "                        


                        <div class=\"dr-calendar my-4\">
                            ";
            // line 234
            if (((($_v10 = ($context["availableDates"] ?? null)) && is_array($_v10) || $_v10 instanceof ArrayAccess ? ($_v10[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 234)] ?? null) : null) && (($_v11 = ($context["bookingLinks"] ?? null)) && is_array($_v11) || $_v11 instanceof ArrayAccess ? ($_v11[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 234)] ?? null) : null))) {
                // line 235
                yield "                            <div class=\"dr-calendar-text text-center\">
                                <p><strong>أقرب موعد متاح</strong></p>
                                <p style=\"font-size: 12px;\"><strong>";
                // line 237
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, (($_v12 = ($context["availableDates"] ?? null)) && is_array($_v12) || $_v12 instanceof ArrayAccess ? ($_v12[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 237)] ?? null) : null), "company_name", [], "any", false, false, true, 237), 237, $this->source), "html", null, true);
                yield "</strong></p>
                            </div>
                            <div class=\"dr-calendar-flex\">
                                <a class=\"dr-cale\">";
                // line 240
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::replace($this->extensions['Twig\Extension\CoreExtension']->formatDate($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, (($_v13 = ($context["availableDates"] ?? null)) && is_array($_v13) || $_v13 instanceof ArrayAccess ? ($_v13[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 240)] ?? null) : null), "latest_date", [], "any", false, false, true, 240), 240, $this->source), "j-M-Y"), $this->sandbox->ensureToStringAllowed(                // line 241
($context["arabicNumbers"] ?? null), 241, $this->source)), "html", null, true);
                yield "</a>
                                <a class=\"dr-cale\">";
                // line 242
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::replace($this->extensions['Twig\Extension\CoreExtension']->formatDate($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, (($_v14 = ($context["availableDates"] ?? null)) && is_array($_v14) || $_v14 instanceof ArrayAccess ? ($_v14[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 242)] ?? null) : null), "latest_time", [], "any", false, false, true, 242), 242, $this->source), "h:i A"), $this->sandbox->ensureToStringAllowed(                // line 243
($context["arabicNumbers"] ?? null), 243, $this->source)), "html", null, true);
                yield "</a>
                                <!-- <div class=\"slots\">";
                // line 244
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, (($_v15 = ($context["availableDates"] ?? null)) && is_array($_v15) || $_v15 instanceof ArrayAccess ? ($_v15[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 244)] ?? null) : null), "slots_available", [], "any", false, false, true, 244), 244, $this->source), "html", null, true);
                yield " فتحات</div> -->
                            </div>
                            ";
            }
            // line 247
            yield "                        </div>

                        <div class=\"d-flex justify-content-around\">
                            <div class=\"";
            // line 250
            if ( !(($_v16 = ($context["bookingLinks"] ?? null)) && is_array($_v16) || $_v16 instanceof ArrayAccess ? ($_v16[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 250)] ?? null) : null)) {
                yield "w-100 mt-40";
            }
            yield "\">
                                <button href=\"javascript:void(0)\"
                                    onclick=\"GoLinks(event,'/ar/doctor-detail/'+'";
            // line 252
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 252), 252, $this->source), "html", null, true);
            yield "')\"
                                    class=\"btn btn-light btn-dr-card\">
                                    الحساب التعريفي
                                </button>
                            </div>
                            &nbsp;
                            ";
            // line 258
            if (($context["canBook"] ?? null)) {
                // line 259
                yield "                            <div>
                                ";
                // line 260
                if (($context["isMobile"] ?? null)) {
                    // line 261
                    yield "                                <a href=\"/ar/contact-us\"
                                    class=\"btn btn-dr-card-2 ";
                    // line 262
                    if ( !(($_v17 = ($context["bookingLinks"] ?? null)) && is_array($_v17) || $_v17 instanceof ArrayAccess ? ($_v17[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 262)] ?? null) : null)) {
                        yield "mt-40";
                    }
                    yield "\">
                                    <svg width=\"28\" height=\"27\" viewBox=\"0 0 28 27\" fill=\"none\"
                                        xmlns=\"http://www.w3.org/2000/svg\">
                                        <ellipse cx=\"13.7306\" cy=\"13.7772\" rx=\"13.4181\" ry=\"13.1913\" fill=\"white\" />
                                        <path class=\"arr-cl\"
                                            d=\"M14.9238 10.2812L18.565 13.781L14.9238 17.2807M12.8722 13.781H18.463M8.36719 13.781H14.7408\"
                                            stroke=\"#003868\" stroke-width=\"2\" stroke-miterlimit=\"10\"
                                            stroke-linecap=\"round\" stroke-linejoin=\"round\" />
                                    </svg>
                                    اسألنا
                                </a>
                                ";
                } else {
                    // line 274
                    yield "                                ";
                    if ((($_v18 = ($context["bookingLinks"] ?? null)) && is_array($_v18) || $_v18 instanceof ArrayAccess ? ($_v18[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 274)] ?? null) : null)) {
                        // line 275
                        yield "                                <button href=\"javascript:void(0)\"
                                    onclick=\"GoLinks(event, '";
                        // line 276
                        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed((($_v19 = ($context["bookingLinks"] ?? null)) && is_array($_v19) || $_v19 instanceof ArrayAccess ? ($_v19[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 276)] ?? null) : null), 276, $this->source), "html", null, true);
                        yield "')\" class=\"btn btn-dr-card-2\">
                                    <svg width=\"28\" height=\"27\" viewBox=\"0 0 28 27\" fill=\"none\"
                                        xmlns=\"http://www.w3.org/2000/svg\">
                                        <ellipse cx=\"13.7306\" cy=\"13.7772\" rx=\"13.4181\" ry=\"13.1913\" fill=\"white\" />
                                        <path class=\"arr-cl\"
                                            d=\"M14.9238 10.2812L18.565 13.781L14.9238 17.2807M12.8722 13.781H18.463M8.36719 13.781H14.7408\"
                                            stroke=\"#003868\" stroke-width=\"2\" stroke-miterlimit=\"10\"
                                            stroke-linecap=\"round\" stroke-linejoin=\"round\" />
                                    </svg>
                                    احجز الآن
                                </button>
                                ";
                    } else {
                        // line 288
                        yield "                                <a href=\"https://bamc.myclinic.com.sa:8443\"
                                     class=\"btn btn-dr-card-2 ";
                        // line 289
                        if ( !(($_v20 = ($context["bookingLinks"] ?? null)) && is_array($_v20) || $_v20 instanceof ArrayAccess ? ($_v20[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 289)] ?? null) : null)) {
                            yield "mt-40";
                        }
                        yield "\">
                                    <svg width=\"28\" height=\"27\" viewBox=\"0 0 28 27\" fill=\"none\"
                                        xmlns=\"http://www.w3.org/2000/svg\">
                                        <ellipse cx=\"13.7306\" cy=\"13.7772\" rx=\"13.4181\" ry=\"13.1913\" fill=\"white\" />
                                        <path class=\"arr-cl\"
                                            d=\"M14.9238 10.2812L18.565 13.781L14.9238 17.2807M12.8722 13.781H18.463M8.36719 13.781H14.7408\"
                                            stroke=\"#003868\" stroke-width=\"2\" stroke-miterlimit=\"10\"
                                            stroke-linecap=\"round\" stroke-linejoin=\"round\" />
                                    </svg>
                                    احجز الآن
                                </a>
                                ";
                    }
                    // line 301
                    yield "                                ";
                }
                // line 302
                yield "                            </div>
                            ";
            }
            // line 304
            yield "                        </div>

                    </div>
                </a>
            </div>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['item'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 310
        yield "

        </div>

    </div>
</section>
<!-- ======= OUR DOCTORS END ======= -->

<!-- ======= DOWNLOAD OUR APP START ======= -->
";
        // line 319
        $cmsPartialParams = [];
        yield $this->env->getExtension(\Cms\Twig\Extension::class)->partialFunction("components/appDownload-ar"        , array_merge($context, ['__cms_partial_params' => $cmsPartialParams], $cmsPartialParams)        , true        );
        // line 320
        yield "<!-- ======= DOWNLOAD OUR APP END ======= -->

<script>
    document.getElementById('search-form').addEventListener('submit', function (e) {
        e.preventDefault();  // Prevent the default form submission

        // Get the user's input
        const specialty = document.getElementById('specialty').value;
        const doctor = document.getElementById('doctor').value;
        const location = document.getElementById('location').value;

        var detailPageURL = '';

        if (specialty && location && !doctor) {
            detailPageURL = `/ar/search-specialty/\${location}/\${specialty}`;

        } else {
            detailPageURL = (doctor) ? `/ar/doctor-detail/\${doctor}` : (specialty) ? `/ar/search-specialty/\${specialty}` : `/ar/location-doctors/\${location}`;
        }

        // Determine the detail page URL based on the search type

        // Redirect to the appropriate detail page
        window.location.href = detailPageURL;
    });


    \$(document).ready(function () {
        \$('#specialty').change(function () {
            var countryId = \$(this).val();
            var location = document.getElementById('location').value;
            var doctor = document.getElementById('doctor').value;

            \$.ajax({
                url: '/specialty-doctors/' + countryId + '?location=' + location,
                headers: { 'language': 'ar' },
                type: 'GET',
                dataType: 'json',
                success: function (data) {
                    var statesSelect = \$('#doctor');
                    statesSelect.empty();
                    if (data.doctors.length) {
                        statesSelect.append('<option value=\"\"> طبيب  </option>');
                        \$.each(data.doctors, function (key, state) {
                            var selected = (state.id == doctor) ? ' selected' : '';

                            statesSelect.append('<option value=\"' + state.id + '\"' + selected + '>' + (state.designation_ar ? state.designation_ar : null) + ' ' + state.name_ar + '</option>');
                        });
                    } else {
                        statesSelect.append('<option value=\"\"> طبيب  </option>');
                    }
                },
                error: function (jqXHR, textStatus, errorThrown) {
                    // Handle errors
                    console.error('API request failed:', textStatus, errorThrown);
                }
            });

        });

        \$('#location').change(function () {
            var countryId = \$(this).val();
            var specialty = document.getElementById('specialty').value;

            \$.ajax({
                url: '/location-specialties/' + countryId,
                headers: { 'language': 'ar' },
                type: 'GET',
                dataType: 'json',
                success: function (data) {
                    var statesSelect = \$('#specialty');
                    var doctorSelect = \$('#doctor');
                    var selectedSpecialtyDoctors = null;

                    statesSelect.empty();
                    if (data.specialties.length) {
                        statesSelect.append('<option value=\"\"> التخصصات </option>');
                        \$.each(data.specialties, function (key, state) {
                            var selected = (state.slug === specialty) ? ' selected' : '';
                            selectedSpecialtyDoctors = (state.slug === specialty) ? state : null;

                            statesSelect.append('<option value=\"' + state.slug + '\"' + selected + '>' + state.name_ar + '</option>');
                        });
                        \$('#specialty').change();

                    } else {
                        statesSelect.append('<option value=\"\"> التخصصات </option>');
                    }

                    if (!selectedSpecialtyDoctors) {
                        doctorSelect.empty();
                        doctorSelect.append('<option value=\"\"> طبيب </option>');
                    }


                },
                error: function (jqXHR, textStatus, errorThrown) {
                    // Handle errors
                    console.error('API request failed:', textStatus, errorThrown);
                }
            });

        });
    });


    function GoLinks(event, bookingLink) {
        event.preventDefault();

        // If the booking link is not found (empty), redirect to the external site
        if (!bookingLink || bookingLink === '') {
            window.location.href = 'https://bamc.myclinic.com.sa:8443';
        } else {
            window.location.href = bookingLink;
        }
    }

</script>";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "C:\\xampp\\htdocs\\myclinic\\themes/myclinic/pages/ar/location-search-specialty-detail.htm";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  618 => 320,  615 => 319,  604 => 310,  593 => 304,  589 => 302,  586 => 301,  569 => 289,  566 => 288,  551 => 276,  548 => 275,  545 => 274,  528 => 262,  525 => 261,  523 => 260,  520 => 259,  518 => 258,  509 => 252,  502 => 250,  497 => 247,  491 => 244,  487 => 243,  486 => 242,  482 => 241,  481 => 240,  475 => 237,  471 => 235,  469 => 234,  463 => 230,  460 => 224,  454 => 220,  450 => 219,  442 => 214,  437 => 212,  431 => 209,  427 => 208,  422 => 206,  414 => 201,  409 => 199,  403 => 196,  400 => 195,  395 => 194,  387 => 188,  383 => 186,  380 => 185,  363 => 172,  360 => 171,  343 => 159,  340 => 158,  338 => 157,  335 => 156,  333 => 155,  323 => 150,  319 => 149,  312 => 147,  307 => 144,  300 => 140,  299 => 139,  295 => 138,  294 => 137,  288 => 134,  284 => 132,  282 => 131,  276 => 127,  273 => 121,  267 => 117,  263 => 116,  255 => 111,  250 => 109,  244 => 106,  240 => 105,  235 => 103,  227 => 98,  222 => 96,  216 => 93,  213 => 92,  211 => 91,  173 => 55,  167 => 54,  159 => 52,  151 => 50,  148 => 49,  144 => 48,  133 => 39,  125 => 37,  121 => 36,  116 => 35,  112 => 34,  103 => 27,  97 => 26,  89 => 24,  81 => 22,  78 => 21,  74 => 20,  64 => 13,  56 => 8,  52 => 7,  44 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "C:\\xampp\\htdocs\\myclinic\\themes/myclinic/pages/ar/location-search-specialty-detail.htm", "");
    }
    
    public function checkSecurity()
    {
        static $tags = ["for" => 20, "if" => 21, "set" => 121, "partial" => 319];
        static $filters = ["raw" => 7, "escape" => 8, "replace" => 138, "date" => 137];
        static $functions = [];

        try {
            $this->sandbox->checkSecurity(
                ['for', 'if', 'set', 'partial'],
                ['raw', 'escape', 'replace', 'date'],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
