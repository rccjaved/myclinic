<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* C:\xampp\htdocs\myclinic\themes/myclinic/pages/ar/location-doctors.htm */
class __TwigTemplate_b0fd1be3551fdb8ba4f33cbe110683fc extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield "<!-- ======= BANNER START ======= -->
<section class=\"section-bg\">
    <div class=\"container-fluid\">
        <div class=\"row align-items-center \">
            <div class=\"col-12 col-sm-12 col-md-6 text-center text-sm-end px-0 d-none d-md-block\">
                <div class=\"mc-block\">
                    <h1>";
        // line 7
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["location"] ?? null), "name_ar", [], "any", false, false, true, 7), 7, $this->source), "html", null, true);
        yield "</h1>
                </div>
            </div>
            <div class=\"col-12 col-sm-12 col-md-6 px-0\">
                <div class=\"position-relative\">
                    <h1 class=\"d-md-none location-in-mobile text-end\">";
        // line 12
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["location"] ?? null), "name_ar", [], "any", false, false, true, 12), 12, $this->source), "html", null, true);
        yield "</h1>
                    <img src=\"";
        // line 13
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["location"] ?? null), "location_image", [], "any", false, false, true, 13), "path", [], "any", false, false, true, 13), 13, $this->source), "html", null, true);
        yield "\" class=\"img-fluid location-img\" alt=\"\">
                    <form class=\"row row-cols-2 g-2 g-lg-3 dr-search-form align-items-center flex-row-reverse\"
                        id=\"search-form\">

                        <div class=\"col-12 position-relative arrow-icon-left\">
                            <span class=\"select2-selection__arrow\" role=\"presentation\"><b
                                    role=\"presentation\"></b></span>
                            <label class=\"visually-hidden\" for=\"autoSizingSelect\">Preference</label>
                            <select class=\"form-select form-select-lg select-mc\" id=\"location\">
                                ";
        // line 22
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["locations"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 23
            yield "                                ";
            if ((Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 23) == Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["location"] ?? null), "id", [], "any", false, false, true, 23))) {
                // line 24
                yield "                                <option value=\"";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["location"] ?? null), "id", [], "any", false, false, true, 24), 24, $this->source), "html", null, true);
                yield "\" selected>";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["location"] ?? null), "name_ar", [], "any", false, false, true, 24), 24, $this->source), "html", null, true);
                yield "</option>
                                ";
            } else {
                // line 26
                yield "                                <option value=";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 26), 26, $this->source), "html", null, true);
                yield ">";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "name_ar", [], "any", false, false, true, 26), 26, $this->source), "html", null, true);
                yield "</option>
                                ";
            }
            // line 28
            yield "                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['item'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 29
        yield "                            </select>
                        </div>


                        <div class=\"col position-relative arrow-icon-left\">
                            <span class=\"select2-selection__arrow\" role=\"presentation\"><b
                                    role=\"presentation\"></b></span>
                            <label class=\"visually-hidden\" for=\"autoSizingSelect\">Preference</label>
                            <select class=\"form-select form-select-lg select-mc\" id=\"specialty\">
                                <option value=\"\"> التخصصات </option>                                
                                ";
        // line 39
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["specialties"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 40
            yield "                                <option value=";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "slug", [], "any", false, false, true, 40), 40, $this->source), "html", null, true);
            yield ">";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "name_ar", [], "any", false, false, true, 40), 40, $this->source), "html", null, true);
            yield "</option>
                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['item'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 42
        yield "                            </select>
                        </div>

                        <div class=\"col position-relative arrow-icon-left\">
                            <span class=\"select2-selection__arrow\" role=\"presentation\"><b
                                    role=\"presentation\"></b></span>
                            <label class=\"visually-hidden\" for=\"autoSizingSelect\">Preference</label>
                            <select class=\"form-select form-select-lg select-mc\" id=\"doctor\">
                                <option value=\"\">اسم الطبيب
                                </option>
                                ";
        // line 52
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["doctors"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 53
            yield "                                <option value=";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 53), 53, $this->source), "html", null, true);
            yield "><span >
                                    ";
            // line 54
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "designation_ar", [], "any", false, false, true, 54), 54, $this->source), "html", null, true);
            yield "
                                </span>";
            // line 55
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "name_ar", [], "any", false, false, true, 55), 55, $this->source), "html", null, true);
            yield "</option>
                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['item'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 57
        yield "                            </select>
                        </div>


                        <div class=\"col-12\">
                            <button
                                class=\"btn btn-primary btn-mc-search mc-search mb-4 mb-sm-0 mx-auto search-icon-degree\"><svg
                                    xmlns=\"http://www.w3.org/2000/svg\" width=\"49\" height=\"48\" viewBox=\"0 0 49 48\"
                                    fill=\"none\">
                                    <ellipse cx=\"24.2\" cy=\"23.716\" rx=\"24.2\" ry=\"23.716\" fill=\"white\" />
                                    <path
                                        d=\"M22.8362 15.7266C26.0961 15.7266 28.735 18.3655 28.735 21.6253C28.735 24.8852 26.0961 27.5241 22.8362 27.5241C19.5764 27.5241 16.9375 24.8852 16.9375 21.6253C16.9375 19.3279 18.2476 17.341 20.1663 16.3661M32.6675 31.4566L27.2225 26.0116\"
                                        stroke=\"#003868\" stroke-width=\"1.452\" stroke-miterlimit=\"10\"
                                        stroke-linecap=\"round\" stroke-linejoin=\"round\" />
                                </svg>ابحث</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- ======= BANNER END ======= -->





<!-- ======= OUR DOCTORS  START ======= -->
<section>
    <div class=\"container mt-5\">
        <div class=\"row\">
            <div class=\"col-12 text-center section-py-100 pt-0\">
                <h1 class=\"\">أطباؤنا</h1>
            </div>
        </div>

        <div class=\"row\">

            ";
        // line 96
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["doctors"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 97
            yield "            <div class=\"col-12 col-sm-6 col-xl-4 col-xxl-3 mc-hide-2\">
                <div class=\"doctor-card\">
                    
                    <div class=\"doctor-img-2 text-center\">
                        <img src=\"";
            // line 101
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "doctor_image", [], "any", false, false, true, 101), "path", [], "any", false, false, true, 101), 101, $this->source), "html", null, true);
            yield "\" class=\"img-fluid\" alt=\"\" style=\"border-radius: 50%;\">
                    </div>
                    <h3><span >
                        ";
            // line 104
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "designation_ar", [], "any", false, false, true, 104), 104, $this->source), "html", null, true);
            yield "
                    </span>";
            // line 105
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "name_ar", [], "any", false, false, true, 105), 105, $this->source), "html", null, true);
            yield "</h3>
                    <div class=\"dr-specialities\">";
            // line 106
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "specialty_desc_ar", [], "any", false, false, true, 106), 106, $this->source), "html", null, true);
            yield "</div>

                    <div class=\"row hide\">
                        <div class=\"col-12 text-center\">
                            <p>";
            // line 110
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "highest_degree_ar", [], "any", false, false, true, 110), 110, $this->source), "html", null, true);
            yield "</p>
                        </div>
                    </div>
                    ";
            // line 114
            yield "                    ";
            $context["arabicNumbers"] = ["0" => "٠", "1" => "١", "2" => "٢", "3" => "٣", "4" => "٤", "5" => "٥", "6" => "٦", "7" => "٧", "8" => "٨", "9" => "٩", "AM" => "ص", "PM" => "م", "Jan" => "يناير", "Feb" => "فبراير", "Mar" => "مارس", "Apr" => "أبريل", "May" => "مايو", "Jun" => "يونيو", "Jul" => "يوليو", "Aug" => "أغسطس", "Sep" => "سبتمبر", "Oct" => "أكتوبر", "Nov" => "نوفمبر", "Dec" => "ديسمبر"];
            // line 120
            yield "                    

                    <div class=\"dr-calendar\" style=\"direction: rtl;\">
                        ";
            // line 123
            if (((($_v0 = ($context["availableDates"] ?? null)) && is_array($_v0) || $_v0 instanceof ArrayAccess ? ($_v0[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 123)] ?? null) : null) && (($_v1 = ($context["bookingLinks"] ?? null)) && is_array($_v1) || $_v1 instanceof ArrayAccess ? ($_v1[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 123)] ?? null) : null))) {
                // line 124
                yield "                        <div class=\"dr-calendar-text text-center\">
                            <p><strong>أقرب موعد متاح</strong></p>
                            <p style=\"font-size: 12px;\"><strong>";
                // line 126
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, (($_v2 = ($context["availableDates"] ?? null)) && is_array($_v2) || $_v2 instanceof ArrayAccess ? ($_v2[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 126)] ?? null) : null), "company_name", [], "any", false, false, true, 126), 126, $this->source), "html", null, true);
                yield "</strong></p>
                        </div>
                        <div class=\"dr-calendar-flex\">
                            <a class=\"dr-cale\">";
                // line 129
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::replace($this->extensions['Twig\Extension\CoreExtension']->formatDate($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, (($_v3 = ($context["availableDates"] ?? null)) && is_array($_v3) || $_v3 instanceof ArrayAccess ? ($_v3[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 129)] ?? null) : null), "latest_date", [], "any", false, false, true, 129), 129, $this->source), "j-M-Y"), $this->sandbox->ensureToStringAllowed(($context["arabicNumbers"] ?? null), 129, $this->source)), "html", null, true);
                yield "</a>
                            <a class=\"dr-cale\">";
                // line 130
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::replace($this->extensions['Twig\Extension\CoreExtension']->formatDate($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, (($_v4 = ($context["availableDates"] ?? null)) && is_array($_v4) || $_v4 instanceof ArrayAccess ? ($_v4[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 130)] ?? null) : null), "latest_time", [], "any", false, false, true, 130), 130, $this->source), "h:i A"), $this->sandbox->ensureToStringAllowed(($context["arabicNumbers"] ?? null), 130, $this->source)), "html", null, true);
                yield "</a>
                            <!-- <div class=\"slots\">";
                // line 131
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, (($_v5 = ($context["availableDates"] ?? null)) && is_array($_v5) || $_v5 instanceof ArrayAccess ? ($_v5[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 131)] ?? null) : null), "slots_available", [], "any", false, false, true, 131), 131, $this->source), "html", null, true);
                yield " فتحات</div> -->
                        </div>
                        ";
            }
            // line 134
            yield "                    </div>

                    <div class=\"d-flex justify-content-around\">
                        <div>
                            ";
            // line 138
            if (Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "isHaveAskUsSpecialty", [], "any", false, false, true, 138)) {
                // line 139
                yield "                            <a href=\"/ar/contact-us\"
                                class=\"btn btn-dr-card-2 ";
                // line 140
                if ( !(($_v6 = ($context["bookingLinks"] ?? null)) && is_array($_v6) || $_v6 instanceof ArrayAccess ? ($_v6[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 140)] ?? null) : null)) {
                    yield "mt-40";
                }
                yield "\">
                                <svg width=\"28\" height=\"27\" viewBox=\"0 0 28 27\" fill=\"none\"
                                    xmlns=\"http://www.w3.org/2000/svg\">
                                    <ellipse cx=\"13.7306\" cy=\"13.7772\" rx=\"13.4181\" ry=\"13.1913\" fill=\"white\" />
                                    <path class=\"arr-cl\"
                                        d=\"M14.9238 10.2812L18.565 13.781L14.9238 17.2807M12.8722 13.781H18.463M8.36719 13.781H14.7408\"
                                        stroke=\"#003868\" stroke-width=\"2\" stroke-miterlimit=\"10\" stroke-linecap=\"round\"
                                        stroke-linejoin=\"round\" />
                                </svg>
                                اسألنا
                            </a>
                            ";
            } else {
                // line 152
                yield "                            ";
                if ((($_v7 = ($context["bookingLinks"] ?? null)) && is_array($_v7) || $_v7 instanceof ArrayAccess ? ($_v7[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 152)] ?? null) : null)) {
                    // line 153
                    yield "                            <button href=\"javascript:void(0)\" onclick=\"GoLinks(event, '";
                    yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed((($_v8 = ($context["bookingLinks"] ?? null)) && is_array($_v8) || $_v8 instanceof ArrayAccess ? ($_v8[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 153)] ?? null) : null), 153, $this->source), "html", null, true);
                    yield "')\"
                                class=\"btn btn-dr-card-2\">
                                <svg width=\"28\" height=\"27\" viewBox=\"0 0 28 27\" fill=\"none\"
                                    xmlns=\"http://www.w3.org/2000/svg\">
                                    <ellipse cx=\"13.7306\" cy=\"13.7772\" rx=\"13.4181\" ry=\"13.1913\" fill=\"white\" />
                                    <path class=\"arr-cl\"
                                        d=\"M14.9238 10.2812L18.565 13.781L14.9238 17.2807M12.8722 13.781H18.463M8.36719 13.781H14.7408\"
                                        stroke=\"#003868\" stroke-width=\"2\" stroke-miterlimit=\"10\" stroke-linecap=\"round\"
                                        stroke-linejoin=\"round\" />
                                </svg>
                                احجز الآن
                            </button>
                            ";
                } else {
                    // line 166
                    yield "                            <a href=\"https://bamc.myclinic.com.sa:8443\" 
                                class=\"btn btn-dr-card-2 ";
                    // line 167
                    if ( !(($_v9 = ($context["bookingLinks"] ?? null)) && is_array($_v9) || $_v9 instanceof ArrayAccess ? ($_v9[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 167)] ?? null) : null)) {
                        yield "mt-40";
                    }
                    yield "\">
                                <svg width=\"28\" height=\"27\" viewBox=\"0 0 28 27\" fill=\"none\"
                                    xmlns=\"http://www.w3.org/2000/svg\">
                                    <ellipse cx=\"13.7306\" cy=\"13.7772\" rx=\"13.4181\" ry=\"13.1913\" fill=\"white\" />
                                    <path class=\"arr-cl\"
                                        d=\"M14.9238 10.2812L18.565 13.781L14.9238 17.2807M12.8722 13.781H18.463M8.36719 13.781H14.7408\"
                                        stroke=\"#003868\" stroke-width=\"2\" stroke-miterlimit=\"10\" stroke-linecap=\"round\"
                                        stroke-linejoin=\"round\" />
                                </svg>
                                احجز الآن
                            </a>
                            ";
                }
                // line 179
                yield "                            ";
            }
            // line 180
            yield "                        </div>
                        &nbsp;
                        <div class=\"";
            // line 182
            if ( !(($_v10 = ($context["bookingLinks"] ?? null)) && is_array($_v10) || $_v10 instanceof ArrayAccess ? ($_v10[Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 182)] ?? null) : null)) {
                yield "w-100 mt-40";
            }
            yield "\">
                            <button href=\"javascript:void(0)\" onclick=\"GoLinks(event,'/ar/doctor-detail/'+'";
            // line 183
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, true, 183), 183, $this->source), "html", null, true);
            yield "')\"
                                class=\"btn btn-light btn-dr-card \">
                                الحساب التعريفي
                            </button>
                        </div>


                        

                    </div>

                </div>
            </div>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['item'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 197
        yield "

            <div class=\"col-12 mt-3\">
                <a href=\"#\" class=\"btn btn-view-all btn-outline-dark view-more-dr\"><svg
                        xmlns=\"http://www.w3.org/2000/svg\" width=\"40\" height=\"40\" viewBox=\"0 0 40 40\" fill=\"none\">
                        <ellipse cx=\"20\" cy=\"19.6\" rx=\"20\" ry=\"19.6\" fill=\"#003868\" />
                        <path
                            d=\"M24.7969 21.7727L19.5969 27.2L14.3969 21.7727M19.5969 18.7148L19.5969 27.048M19.5969 12L19.5969 21.5\"
                            stroke=\"white\" stroke-width=\"2\" stroke-miterlimit=\"10\" stroke-linecap=\"round\"
                            stroke-linejoin=\"round\" />
                    </svg>View more doctors</a>
            </div>


        </div>

    </div>
</section>
<!-- ======= OUR DOCTORS END ======= -->

";
        // line 217
        $cmsPartialParams = [];
        yield $this->env->getExtension(\Cms\Twig\Extension::class)->partialFunction("components/appDownload-ar"        , array_merge($context, ['__cms_partial_params' => $cmsPartialParams], $cmsPartialParams)        , true        );
        // line 218
        yield "

<script>
    document.getElementById('search-form').addEventListener('submit', function (e) {
        e.preventDefault();  // Prevent the default form submission

        // Get the user's input
        const specialty = document.getElementById('specialty').value;
        const doctor = document.getElementById('doctor').value;
        const location = document.getElementById('location').value;

        var detailPageURL = '';

        if (specialty && location) {
            detailPageURL = `/ar/search-specialty/\${location}/\${specialty}`;

        } else {
            detailPageURL = (doctor) ? `/ar/doctor-detail/\${doctor}` : (specialty) ? `/ar/search-specialty/\${specialty}` : `/ar/location-doctors/\${location}`;

        }
        // Determine the detail page URL based on the search type

        // Redirect to the appropriate detail page
        window.location.href = detailPageURL;
    });


    \$(document).ready(function () {
        \$('#specialty').change(function () {
            var countryId = \$(this).val();
            var location = document.getElementById('location').value;
            var doctor = document.getElementById('doctor').value;

            \$.ajax({
                url: '/specialty-doctors/' + countryId + '?location=' + location,
                headers:{'language':'ar'},
                type: 'GET',
                dataType: 'json',
                success: function (data) {
                    var statesSelect = \$('#doctor');
                    statesSelect.empty();
                    if (data.doctors.length) {
                        statesSelect.append('<option value=\"\">  اسم الطبيب </option>');
                        \$.each(data.doctors, function (key, state) {
                            var selected = (state.id == doctor) ? ' selected' : '';
                            statesSelect.append('<option value=\"' + state.id + '\"' + selected + '>' + (state.designation_ar ? state.designation_ar : null)+' '+state.name_ar + '</option>');
                        });
                    } else {
                        statesSelect.append('<option value=\"\">  اسم الطبيب </option>');
                    }
                },
                error: function (jqXHR, textStatus, errorThrown) {
                    // Handle errors
                    console.error('API request failed:', textStatus, errorThrown);
                }
            });

        });

        \$('#location').change(function () {
            var countryId = \$(this).val();
            var specialty = document.getElementById('specialty').value;

            \$.ajax({
                url: '/location-specialties/' + countryId,
                headers:{'language':'ar'},
                type: 'GET',
                dataType: 'json',
                success: function (data) {
                    var statesSelect = \$('#specialty');
                    var doctorSelect = \$('#doctor');
                    var selectedSpecialtyDoctors = null
                    statesSelect.empty();
                    if (data.specialties.length) {
                        statesSelect.append('<option value=\"\"> التخصصات </option>');
                        \$.each(data.specialties, function (key, state) {
                            var selected = (state.slug === specialty) ? ' selected' : '';
                            selectedSpecialtyDoctors = (state.slug === specialty) ? state : null;

                            statesSelect.append('<option value=\"' + state.slug + '\"'+selected+'>' + state.name_ar + '</option>');
                        });
                        \$('#specialty').change();

                    } else {
                        statesSelect.append('<option value=\"\"> التخصصات </option>');
                    }
                    if(!selectedSpecialtyDoctors){
                        doctorSelect.empty();
                        doctorSelect.append('<option value=\"\">اسم الطبيب </option>');
                    }

                },
                error: function (jqXHR, textStatus, errorThrown) {
                    // Handle errors
                    console.error('API request failed:', textStatus, errorThrown);
                }
            });

        });
    });


    function GoLinks(event, bookingLink) {
        event.preventDefault();
        
        // If the booking link is not found (empty), redirect to the external site
        if (!bookingLink || bookingLink === '') {
            window.location.href = 'https://bamc.myclinic.com.sa:8443';
        } else {
            window.location.href = bookingLink;
        }
    }

</script>";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "C:\\xampp\\htdocs\\myclinic\\themes/myclinic/pages/ar/location-doctors.htm";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  403 => 218,  400 => 217,  378 => 197,  358 => 183,  352 => 182,  348 => 180,  345 => 179,  328 => 167,  325 => 166,  308 => 153,  305 => 152,  288 => 140,  285 => 139,  283 => 138,  277 => 134,  271 => 131,  267 => 130,  263 => 129,  257 => 126,  253 => 124,  251 => 123,  246 => 120,  243 => 114,  237 => 110,  230 => 106,  226 => 105,  222 => 104,  216 => 101,  210 => 97,  206 => 96,  165 => 57,  157 => 55,  153 => 54,  148 => 53,  144 => 52,  132 => 42,  121 => 40,  117 => 39,  105 => 29,  99 => 28,  91 => 26,  83 => 24,  80 => 23,  76 => 22,  64 => 13,  60 => 12,  52 => 7,  44 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "C:\\xampp\\htdocs\\myclinic\\themes/myclinic/pages/ar/location-doctors.htm", "");
    }
    
    public function checkSecurity()
    {
        static $tags = ["for" => 22, "if" => 23, "set" => 114, "partial" => 217];
        static $filters = ["escape" => 7, "replace" => 129, "date" => 129];
        static $functions = [];

        try {
            $this->sandbox->checkSecurity(
                ['for', 'if', 'set', 'partial'],
                ['escape', 'replace', 'date'],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
