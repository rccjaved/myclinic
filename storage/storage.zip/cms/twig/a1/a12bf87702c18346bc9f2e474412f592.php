<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* C:\xampp\htdocs\myclinic\themes/myclinic/partials/components/specialties.htm */
class __TwigTemplate_a459e4789ac62e84228cae1d6ab3da8b extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield "<section class=\"section-py-100 pb-0\">
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-12 text-center\">
                <h1 class=\"py-60 pt-0\">Select Your <br class=\"d-block d-sm-none\">Location</h1>
            </div>
        </div>
        <div class=\"row btn-city\">
            <div class=\"col-12 text-center\">
                <div class=\"btn-mc-city-group\">
                    ";
        // line 11
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["locations"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["location"]) {
            // line 12
            yield "                    ";
            if ((Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["location"], "id", [], "any", false, false, true, 12) == 1)) {
                // line 13
                yield "                    <a target=\"";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["location"], "id", [], "any", false, false, true, 13), 13, $this->source), "html", null, true);
                yield "\" class=\"btn-mc-city showLocation active\">";
                yield $this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["location"], "title", [], "any", false, false, true, 13), 13, $this->source);
                yield "</a>
                    ";
            } else {
                // line 15
                yield "                    <a target=\"";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["location"], "id", [], "any", false, false, true, 15), 15, $this->source), "html", null, true);
                yield "\" class=\"btn-mc-city showLocation\">";
                yield $this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["location"], "title", [], "any", false, false, true, 15), 15, $this->source);
                yield "</a>
                    ";
            }
            // line 17
            yield "                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['location'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 18
        yield "                </div>
            </div>
        </div>

        <div class=\"row mt-4\">
            <div class=\"col-12\">
                <div class=\"home-demo\">
                    <div class=\"owl-carousel owl-theme\">
                        <a class=\"special-letter showSpecial\" target=\"1\">A</a>
                        <a class=\"special-letter showSpecial\" target=\"2\">B</a>
                        <a class=\"special-letter showSpecial\" target=\"3\">C</a>
                        <a class=\"special-letter showSpecial\" target=\"4\">D</a>
                        <a class=\"special-letter showSpecial\" target=\"5\">E</a>
                        <a class=\"special-letter showSpecial\" target=\"6\">F</a>
                        <a class=\"special-letter showSpecial\" target=\"7\">G</a>
                        <a class=\"special-letter showSpecial\" target=\"8\">H</a>
                        <a class=\"special-letter showSpecial\" target=\"9\">I</a>
                        <a class=\"special-letter showSpecial\" target=\"10\">J</a>
                        <a class=\"special-letter showSpecial\" target=\"11\">K</a>
                        <a class=\"special-letter showSpecial\" target=\"12\">L</a>
                        <a class=\"special-letter showSpecial\" target=\"13\">M</a>
                        <a class=\"special-letter showSpecial\" target=\"14\">N</a>
                        <a class=\"special-letter showSpecial\" target=\"15\">O</a>
                        <a class=\"special-letter showSpecial\" target=\"16\">P</a>
                        <a class=\"special-letter showSpecial\" target=\"17\">Q</a>
                        <a class=\"special-letter showSpecial\" target=\"18\">R</a>
                        <a class=\"special-letter showSpecial\" target=\"19\">S</a>
                        <a class=\"special-letter showSpecial\" target=\"20\">T</a>
                        <a class=\"special-letter showSpecial\" target=\"21\">U</a>
                        <a class=\"special-letter showSpecial\" target=\"22\">V</a>
                        <a class=\"special-letter showSpecial\" target=\"23\">W</a>
                        <a class=\"special-letter showSpecial\" target=\"24\">X</a>
                        <a class=\"special-letter showSpecial\" target=\"25\">Y</a>
                        <a class=\"special-letter showSpecial\" target=\"26\">Z</a>
                    </div>
                </div>
            </div>

            <!-- <div class=\"col-12\">
                <div class=\"card-slider alp\">
                    <a class=\"special-letter showSpecial\" target=\"1\">A</a>
                    <a class=\"special-letter showSpecial\" target=\"2\">B</a>
                    <a class=\"special-letter showSpecial\" target=\"3\">C</a>
                    <a class=\"special-letter showSpecial\" target=\"4\">D</a>
                    <a class=\"special-letter showSpecial\" target=\"5\">E</a>
                    <a class=\"special-letter showSpecial\" target=\"6\">F</a>
                    <a class=\"special-letter showSpecial\" target=\"7\">G</a>
                    <a class=\"special-letter showSpecial\" target=\"8\">H</a>
                    <a class=\"special-letter showSpecial\" target=\"9\">I</a>
                    <a class=\"special-letter showSpecial\" target=\"10\">J</a>
                    <a class=\"special-letter showSpecial\" target=\"11\">K</a>
                    <a class=\"special-letter showSpecial\" target=\"12\">L</a>
                    <a class=\"special-letter showSpecial\" target=\"13\">M</a>
                    <a class=\"special-letter showSpecial\" target=\"14\">N</a>
                    <a class=\"special-letter showSpecial\" target=\"15\">O</a>
                    <a class=\"special-letter showSpecial\" target=\"16\">P</a>
                    <a class=\"special-letter showSpecial\" target=\"17\">Q</a>
                    <a class=\"special-letter showSpecial\" target=\"18\">R</a>
                    <a class=\"special-letter showSpecial\" target=\"19\">S</a>
                    <a class=\"special-letter showSpecial\" target=\"20\">T</a>
                    <a class=\"special-letter showSpecial\" target=\"21\">U</a>
                    <a class=\"special-letter showSpecial\" target=\"22\">V</a>
                    <a class=\"special-letter showSpecial\" target=\"23\">W</a>
                    <a class=\"special-letter showSpecial\" target=\"24\">X</a>
                    <a class=\"special-letter showSpecial\" target=\"25\">Y</a>
                    <a class=\"special-letter showSpecial\" target=\"26\">Z</a>
                </div>
            </div> -->
        </div>
    </div>
</section>


<section>
    <div class=\"container\">
        <div class=\"row section-py-100\">
            <div class=\"col-12\">

                <div class=\"row g-3 g-sm-4\" id=\"specialtyCard\">

                    ";
        // line 98
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["specialties"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 99
            yield "                    <div class=\"col-12 col-md-6 col-lg-4 col-xl-3 mc-specl\">
                        <div class=\"speciality-box\">
                            <a href=\"/specialty-detail/";
            // line 101
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "slug", [], "any", false, false, true, 101), 101, $this->source), "html", null, true);
            yield "/1\"> <img src=\"";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "specialty_image", [], "any", false, false, true, 101), "path", [], "any", false, false, true, 101), 101, $this->source), "html", null, true);
            yield "\"
                                    class=\"img-fluid\" alt=\"\">
                                <button class=\"btn btn-light btn-specilty\">";
            // line 103
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "name", [], "any", false, false, true, 103), 103, $this->source), "html", null, true);
            yield "</button>
                            </a>
                        </div>
                    </div>

                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['item'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 109
        yield "

                </div>
                <div class=\"col-12 mt-2\">
                    <a href=\"/our-specialities\" class=\"btn btn-outline-dark btn-view-all btn-view-all-specl\"><svg
                            xmlns=\"http://www.w3.org/2000/svg\" width=\"40\" height=\"40\" viewBox=\"0 0 40 40\" fill=\"none\">
                            <ellipse cx=\"20\" cy=\"19.6\" rx=\"20\" ry=\"19.6\" fill=\"#003868\" />
                            <path
                                d=\"M24.7969 21.7727L19.5969 27.2L14.3969 21.7727M19.5969 18.7148L19.5969 27.048M19.5969 12L19.5969 21.5\"
                                stroke=\"white\" stroke-width=\"2\" stroke-miterlimit=\"10\" stroke-linecap=\"round\"
                                stroke-linejoin=\"round\" />
                        </svg>View All</a>
                </div>

            </div>
        </div>
    </div>
</section>


<script>
    document.addEventListener('DOMContentLoaded', function () {
        function setCookie(name, value, days) {
            var expires = \"\";
            if (days) {
                var date = new Date();
                date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
                expires = \"; expires=\" + date.toUTCString();
            }
            document.cookie = name + \"=\" + (value || \"\") + expires + \"; path=/\";
        }

        function getCookie(name) {
            var nameEQ = name + \"=\";
            var ca = document.cookie.split(';');
            for (var i = 0; i < ca.length; i++) {
                var c = ca[i];
                while (c.charAt(0) == ' ') c = c.substring(1, c.length);
                if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length, c.length);
            }
            return null;
        }

        function eraseCookie(name) {
            document.cookie = name + '=; Max-Age=-99999999;';
        }

        var locationCookie = getCookie('userLocation');

        if (!locationCookie) {
            if (navigator.geolocation) {

                navigator.geolocation.getCurrentPosition(function (position) {
                    var latitude = position.coords.latitude;
                    var longitude = position.coords.longitude;
                    // var latitude = '24.7722044';
                    // var longitude = '46.6260422'

                    \$.ajax({
                        url: '/get-locations?longitude=' + longitude + '&latitude=' + latitude,
                        type: 'GET',
                        dataType: 'json',
                        success: function (data) {
                            \$('.btn-mc-city-group a').removeClass('active');
                            \$('.btn-mc-city-group a[target=\"' + data.location + '\"]').click()
                        },
                        error: function (jqXHR, textStatus, errorThrown) {
                            // Handle errors
                            console.error('API request failed:', textStatus, errorThrown);
                        }
                    });
                });
            } else {
                alert('Geolocation is not supported by this browser.');
            }
        }
    });
</script>

<script>
    var activeLocation = null;

    \$('.btn-mc-city-group').on('click', 'a', function () {
        // Remove the 'active' class from all buttons and add it to the clicked button
        \$('.btn-mc-city-group a.active').removeClass('active');
        \$(this).addClass('active');

        // Get the target attribute value of the clicked button (locationId)
        var locationId = \$(this).attr('target');

        // Make an AJAX request to fetch specialties for the selected location
        \$.ajax({
            url: '/location-specialties/' + locationId,
            type: 'GET',
            dataType: 'json',
            success: function (data) {
                // Get the container for specialties
                var specialtiesContainer = \$('#specialtyCard');

                // Clear the existing content
                specialtiesContainer.empty();

                // Check if there are specialties in the response
                if (data.specialties.length > 0) {
                    // Iterate through specialties and append them to the container
                    var i = 1;
                    data.specialties.forEach(function (item) {
                        if (i <= 8) {
                            var specialtyHtml = `
                        <div class=\"col-12 col-md-6 col-lg-4 col-xl-3 mc-specl\" style=\"display: block;\">
                        <div class=\"speciality-box\">
                            <a href=\"/specialty-detail/\${item.slug}/\${locationId}\"> <img src=\"\${item.image_path}\"
                                    class=\"img-fluid\" alt=\"\">
                                <button class=\"btn btn-light btn-specilty\">\${item.name}</button>
                            </a>
                            </div>
                        </div>
                    `;
                            specialtiesContainer.append(specialtyHtml);
                        }

                        i++;
                    });
                } else {
                    // Handle the case when there are no specialties
                    specialtiesContainer.html('<p>No specialties available for this location.</p>');
                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                // Handle errors
                console.error('API request failed:', textStatus, errorThrown);
            }
        });

        activeLocation = \$(this).attr('target');
        \$('.home-demo a.active').removeClass('active');


    });


    \$('.home-demo').on('click', 'a', function () {

        // Get the target attribute value of the clicked button (locationId)
        var alphabet = \$(this).attr('target');
        var activeLocationValue = activeLocation ? activeLocation : 1;

        \$.ajax({
            url: '/location-specialties/' + activeLocationValue + '/alphabet/' + alphabet,
            type: 'GET',
            dataType: 'json',
            success: function (data) {
                // Get the container for specialties
                var specialtiesContainer = \$('#specialtyCard');

                // Clear the existing content
                specialtiesContainer.empty();

                // Check if there are specialties in the response
                if (data.specialties.length > 0) {
                    var i = 1;
                    data.specialties.forEach(function (item) {
                        if (i <= 8) {
                            var specialtyHtml = `
                        <div class=\"col-12 col-md-6 col-lg-4 col-xl-3 mc-specl\" style=\"display: block;\">
                        <div class=\"speciality-box\">
                            <a href=\"/specialty-detail/\${item.slug}/\${activeLocationValue}\"> <img src=\"\${item.image_path}\"
                                    class=\"img-fluid\" alt=\"\">
                                <button class=\"btn btn-light btn-specilty\">\${item.name}</button>
                            </a>
                            </div>
                        </div>
                    `;
                            specialtiesContainer.append(specialtyHtml);
                        }
                        i++;
                    });
                } else {
                    // Handle the case when there are no specialties
                    specialtiesContainer.html('<p>No specialties available for this location.</p>');
                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                // Handle errors
                console.error('API request failed:', textStatus, errorThrown);
            }
        });

    });


</script>

<script>
    var specialLetters = document.querySelectorAll('.special-letter');
    var owl = \$('.owl-carousel');
    owl.owlCarousel({
        loop: false,
        nav: false,
        margin: 10,
        responsive: {
            0: {
                items: 7
            },
            600: {
                items: 12
            },
            960: {
                items: 16
            },
            1200: {
                items: 20
            },
            1600: {
                items: 24
            },
            1920: {
                items: 26
            }
        }
    });
    specialLetters.forEach(function (letter) {
        letter.addEventListener('click', function () {
            // Remove active class from all letters
            specialLetters.forEach(function (el) {
                el.classList.remove('active');
            });

            // Add active class to the clicked letter
            letter.classList.add('active');
        });
    });

    owl.on('mousewheel', '.owl-stage', function (e) {
        if (e.deltaY > 0) {
            owl.trigger('next.owl');
        } else {
            owl.trigger('prev.owl');
        }
        e.preventDefault();
    });
    \$(function () {
        if (window.matchMedia(\"(max-width: 700px)\").matches) {
            \$(\".mc-specl\").slice(0, 5).show();
            \$(\".mc-specl\").slice(0, 5).show();
            \$(\".mc-specl-2\").slice(0, 5).show();
            \$(\".mc-specl-3\").slice(0, 5).show();
            \$(\".mc-specl-4\").slice(0, 5).show();
            \$(\".mc-specl-5\").slice(0, 5).show();
            \$(\".mc-specl-6\").slice(0, 5).show();
            \$(\".mc-specl-7\").slice(0, 5).show();
            \$(\".mc-specl-8\").slice(0, 5).show();
            \$(\".mc-specl-9\").slice(0, 5).show();
            \$(\".mc-specl-10\").slice(0, 5).show();
            \$(\".mc-specl-11\").slice(0, 5).show();
            \$(\".mc-specl-12\").slice(0, 5).show();
            \$(\".mc-specl-13\").slice(0, 5).show();
            \$(\".mc-specl-14\").slice(0, 5).show();
            \$(\".mc-specl-15\").slice(0, 5).show();
            \$(\".mc-specl-16\").slice(0, 5).show();
            \$(\".mc-specl-17\").slice(0, 5).show();
            \$(\".mc-specl-18\").slice(0, 5).show();
            \$(\".mc-specl-19\").slice(0, 5).show();
            \$(\".mc-specl-20\").slice(0, 5).show();
            \$(\".mc-specl-21\").slice(0, 5).show();
            \$(\".mc-specl-22\").slice(0, 5).show();
            \$(\".mc-specl-23\").slice(0, 5).show();
            \$(\".mc-specl-24\").slice(0, 5).show();
            \$(\".mc-specl-25\").slice(0, 5).show();
            \$(\".mc-specl-26\").slice(0, 5).show();
        } else {
            \$(\".mc-specl\").slice(0, 8).show();
            \$(\".mc-specl-2\").slice(0, 8).show();
            \$(\".mc-specl-3\").slice(0, 8).show();
            \$(\".mc-specl-4\").slice(0, 8).show();
            \$(\".mc-specl-5\").slice(0, 8).show();
            \$(\".mc-specl-6\").slice(0, 8).show();
            \$(\".mc-specl-7\").slice(0, 8).show();
            \$(\".mc-specl-8\").slice(0, 8).show();
            \$(\".mc-specl-9\").slice(0, 8).show();
            \$(\".mc-specl-10\").slice(0, 8).show();
            \$(\".mc-specl-11\").slice(0, 8).show();
            \$(\".mc-specl-12\").slice(0, 8).show();
            \$(\".mc-specl-13\").slice(0, 8).show();
            \$(\".mc-specl-14\").slice(0, 8).show();
            \$(\".mc-specl-15\").slice(0, 8).show();
            \$(\".mc-specl-16\").slice(0, 8).show();
            \$(\".mc-specl-17\").slice(0, 8).show();
            \$(\".mc-specl-18\").slice(0, 8).show();
            \$(\".mc-specl-19\").slice(0, 8).show();
            \$(\".mc-specl-20\").slice(0, 8).show();
            \$(\".mc-specl-21\").slice(0, 8).show();
            \$(\".mc-specl-22\").slice(0, 8).show();
            \$(\".mc-specl-23\").slice(0, 8).show();
            \$(\".mc-specl-24\").slice(0, 8).show();
            \$(\".mc-specl-25\").slice(0, 8).show();
            \$(\".mc-specl-26\").slice(0, 8).show();
        }

        // \$(\"body\").on('click touchstart', '.btn-view-all-specl', function (e) {
        //     e.preventDefault();
        //     \$(\".mc-specl:hidden\").slice(0, 3).slideDown();
        //     if (\$(\".mc-specl:hidden\").length == 0) {
        //         \$(\".load-more\").css('visibility', 'hidden');
        //     }

        // });
    });

</script>";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "C:\\xampp\\htdocs\\myclinic\\themes/myclinic/partials/components/specialties.htm";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  194 => 109,  182 => 103,  175 => 101,  171 => 99,  167 => 98,  85 => 18,  79 => 17,  71 => 15,  63 => 13,  60 => 12,  56 => 11,  44 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "C:\\xampp\\htdocs\\myclinic\\themes/myclinic/partials/components/specialties.htm", "");
    }
    
    public function checkSecurity()
    {
        static $tags = ["for" => 11, "if" => 12];
        static $filters = ["escape" => 13, "raw" => 13];
        static $functions = [];

        try {
            $this->sandbox->checkSecurity(
                ['for', 'if'],
                ['escape', 'raw'],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
