<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* C:\xampp\htdocs\myclinic\themes/myclinic/partials/site/meta-ar.htm */
class __TwigTemplate_99a780d56afe672147d9a1c046b9a366 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield "<!-- Required meta tags -->

<meta charset=\"UTF-8\">
<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
<title>My Clinic - ";
        // line 5
        yield (($this->extensions['Cms\Twig\Extension']->placeholderFunction("pageTitle")) ? ($this->extensions['Cms\Twig\Extension']->placeholderFunction("pageTitle")) : (((Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["this"] ?? null), "page", [], "any", false, false, true, 5), "meta_title", [], "any", false, false, true, 5)) ? ($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["this"] ?? null), "page", [], "any", false, false, true, 5), "meta_title", [], "any", false, false, true, 5), 5, $this->source), "html", null, true)) : ($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["this"] ?? null), "page", [], "any", false, false, true, 5), "title", [], "any", false, false, true, 5), 5, $this->source), "html", null, true)))));
        yield "</title>
<meta name=\"description\" content=\"";
        // line 6
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["this"] ?? null), "page", [], "any", false, false, true, 6), "meta_description", [], "any", false, false, true, 6), 6, $this->source), "html", null, true);
        yield "\">
<meta name=\"title\" content=\"";
        // line 7
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["this"] ?? null), "page", [], "any", false, false, true, 7), "meta_title", [], "any", false, false, true, 7), 7, $this->source), "html", null, true);
        yield "\">
<meta name=\"author\" content=\"My Clinic\">
<meta name=\"generator\" content=\"My Clinic\">

<!--  Social media meta tags -->
<meta property=\"og:title\" content=\"عيادتي\">
<meta property=\"og:type\" content=\"website\" />
<meta property=\"og:image\" content=\"https://www.myclinic.com.sa/storage/app/media/social-media-banner-ar.png\">
<meta property=\"og:url\" content=\"https://myclinic.com.sa\">
<meta name=\"twitter:card\" content=\"summary_large_image\">

";
        // line 25
        yield "
<!-- Fonts -->
<link rel=\"stylesheet\" href=\"";
        // line 27
        yield $this->extensions['Cms\Twig\Extension']->themeFilter("assets/fonts-ar/stylesheet.css");
        yield "\">

<link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css\">


<link rel=\"stylesheet\" href=\"";
        // line 32
        yield $this->extensions['Cms\Twig\Extension']->themeFilter("assets/vendors/bootstrap/css/bootstrap.css");
        yield "\">

<link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css\">
<link rel=\"stylesheet\"
    href=\"https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css\">
<link href=\"";
        // line 37
        yield $this->extensions['Cms\Twig\Extension']->themeFilter("assets/vendors/select2/select2.css");
        yield "\" rel=\"stylesheet\" />


<link rel=\"stylesheet\" href=\"";
        // line 40
        yield $this->extensions['Cms\Twig\Extension']->themeFilter("assets/vendors/slick/slick.css");
        yield "\">
<link rel=\"stylesheet\" href=\"";
        // line 41
        yield $this->extensions['Cms\Twig\Extension']->themeFilter("assets/vendors/slick/slick-2.css");
        yield "\">

<link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.4.6/css/swiper.css\">
<link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.4.6/css/swiper.min.css\">



<link rel=\"stylesheet\" href=\"";
        // line 48
        yield $this->extensions['Cms\Twig\Extension']->themeFilter("assets/css/style-ar.css");
        yield "\">
<link rel=\"stylesheet\" href=\"";
        // line 49
        yield $this->extensions['Cms\Twig\Extension']->themeFilter("assets/css/responsive.css");
        yield "\">

<link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.5.0/css/flag-icon.min.css\">


<!-- Favicons -->
<link href=\"";
        // line 55
        yield $this->extensions['Cms\Twig\Extension']->themeFilter("assets/imgs/favicon.ico");
        yield "\" rel=\"icon\">
<!-- <link href=\"";
        // line 56
        yield $this->extensions['Cms\Twig\Extension']->themeFilter("assets/img/apple-touch-icon.png");
        yield "\" rel=\"apple-touch-icon\"> -->
<!-- Favicons -->




<script src=\"";
        // line 62
        yield $this->extensions['Cms\Twig\Extension']->themeFilter("assets/vendors/jquery/jquery.js");
        yield "\"></script>


<script src=\"https://unpkg.co/gsap@3/dist/gsap.min.js\"></script>
<script src=\"https://unpkg.com/gsap@3/dist/ScrollTrigger.min.js\"></script>
<script src=\"https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.4.6/js/swiper.js\"></script>
<script src=\"https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.4.6/js/swiper.min.js\"></script>
<!-- <script src=\"jquery.min.js\"></script> -->
<script src=\"https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js\"></script>
<script src=\"";
        // line 71
        yield $this->extensions['Cms\Twig\Extension']->themeFilter("assets/js/select2.min.js");
        yield "\"></script>

<!-- Start Messenger/Chatbot Script -->
<script type=\"text/javascript\" charset=\"utf-8\">

    (function (g, e, n, es, ys) {
  
      g['_genesysJs'] = e;
  
      g[e] = g[e] || function () {
  
        (g[e].q = g[e].q || []).push(arguments)
  
      };
  
      g[e].t = 1 * new Date();
  
      g[e].c = es;
  
      ys = document.createElement('script'); ys.async = 1; ys.src = n; ys.charset = 'utf-8'; document.head.appendChild(ys);
  
    })(window, 'Genesys', 'https://apps.mypurecloud.ie/genesys-bootstrap/genesys.min.js', {
  
      environment: 'prod-euw1',
  
      deploymentId: '4079a35d-6d99-499d-98a6-c6f5dda7c13b'
  
    });
  
  </script>
<!-- End Messenger/Chatbot Script -->

<!-- Bootstrap CSS v5.3.2 -->
<!-- <link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.2/css/bootstrap.min.css\"> -->
<!-- <link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.13/css/intlTelInput.css\"> -->";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "C:\\xampp\\htdocs\\myclinic\\themes/myclinic/partials/site/meta-ar.htm";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  150 => 71,  138 => 62,  129 => 56,  125 => 55,  116 => 49,  112 => 48,  102 => 41,  98 => 40,  92 => 37,  84 => 32,  76 => 27,  72 => 25,  58 => 7,  54 => 6,  50 => 5,  44 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "C:\\xampp\\htdocs\\myclinic\\themes/myclinic/partials/site/meta-ar.htm", "");
    }
    
    public function checkSecurity()
    {
        static $tags = [];
        static $filters = ["escape" => 5, "theme" => 27];
        static $functions = ["placeholder" => 5];

        try {
            $this->sandbox->checkSecurity(
                [],
                ['escape', 'theme'],
                ['placeholder'],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
