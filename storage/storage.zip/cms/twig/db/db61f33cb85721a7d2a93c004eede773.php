<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* C:\xampp\htdocs\myclinic\themes/myclinic/partials/site/footer-ar.htm */
class __TwigTemplate_8813f9a2ece1741fabce92aeaf82d318 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield "<!-- ======= Footer ======= -->
<footer class=\"footer-bg footer-padding\">
    <div class=\"container\">
        <div class=\"row flex-row-reverse\">
            <div class=\"col-lg-4 col-12 \">
                <div class=\"footer-about-content\">
                    <div class=\"footer-logo text-end\">
                        <a href=\"/ar\">
                            <img src=\"";
        // line 9
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["footerLogo"] ?? null), "section_image", [], "any", false, false, true, 9), "path", [], "any", false, false, true, 9), 9, $this->source), "html", null, true);
        yield "\" class=\"img-fluid mb-4\" alt=\"my clinic logo\">
                        </a>
                    </div>
                    <p class=\"footer-about mb-4  text-justy text-end\" style=\"color: white\">
                        ";
        // line 13
        yield $this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["footerAbout"] ?? null), "description_ar", [], "any", false, false, true, 13), 13, $this->source);
        yield "</p>
                    <div class=\"text-end my-5 my-lg-auto socilimg\">
                        ";
        // line 15
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["footerSocialMediaLinks"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 16
            yield "                        <a href=\"";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "link_value", [], "any", false, false, true, 16), 16, $this->source), "html", null, true);
            yield "\"><img src=\"";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "section_image", [], "any", false, false, true, 16), "path", [], "any", false, false, true, 16), 16, $this->source), "html", null, true);
            yield "\" alt=\"social media logo\"></a>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['item'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 18
        yield "                    </div>
                    <div class=\"col-12 d-none d-lg-block mt-2\">
                        <p class=\"text-white text-end\" >© My Clinic <span style=\"font-family: 'Courier New', Courier, monospace;\"><script>document.write(new Date().getFullYear())</script></span>. All rights reserved.</p>
                    </div>
                </div>

            </div>
            <div class=\"col-lg-3 col-6 footer-list\">
                <h3>الشركة</h3>
                <ul class=\"list-unstyled list-footer\">
                    ";
        // line 28
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["footerCompanyLinks"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 29
            yield "                    <li><a href=\"/ar/";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "link_value", [], "any", false, false, true, 29), 29, $this->source), "html", null, true);
            yield "\"
                            class=\"text-decoration-none text-white\">";
            // line 30
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "link_name_ar", [], "any", false, false, true, 30), 30, $this->source), "html", null, true);
            yield "</a>
                    </li>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['item'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 33
        yield "                </ul>
                <div class=\"d-none d-lg-block clinictime \">
                    ";
        // line 35
        yield $this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["footerClinicTimings"] ?? null), "description_ar", [], "any", false, false, true, 35), 35, $this->source);
        yield "

                    <ul class=\"list-unstyled list-footer\">
                        ";
        // line 38
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["footerPhones"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 39
            yield "                        <a href=\"";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "link_value", [], "any", false, false, true, 39), 39, $this->source), "html", null, true);
            yield "\" style=\"text-decoration: none;\">

                        <li class=\"mb-2\"><img src=\"";
            // line 41
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "section_image", [], "any", false, false, true, 41), "path", [], "any", false, false, true, 41), 41, $this->source), "html", null, true);
            yield "\" class=\"img-fluid me-3\"
                                alt=\"phone\">";
            // line 42
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "link_name_ar", [], "any", false, false, true, 42), 42, $this->source), "html", null, true);
            yield "</li></a>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['item'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 44
        yield "
                    </ul>
                </div>


            </div>
            <div class=\"col-lg-2 col-6 footer-list\">
                <h3>روابط تهمك</h3>
                <ul class=\"list-unstyled list-footer\">
                    ";
        // line 53
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["footerUsefulLinks"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 54
            yield "                    <li><a href=\"/ar/";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "link_value", [], "any", false, false, true, 54), 54, $this->source), "html", null, true);
            yield "\"
                            class=\"text-decoration-none text-white\">";
            // line 55
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "link_name_ar", [], "any", false, false, true, 55), 55, $this->source), "html", null, true);
            yield "</a>
                    </li>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['item'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 58
        yield "                </ul>
                <!-- <a href=\"javascript:void(0)\" class=\"btn btn-light btn-footer-1 mb-3\">Health Checkup</a> -->
                <a href=\"https://bamc.myclinic.com.sa:8443\"
                    class=\"btn btn-light btn-footer-book-now text-start mb-5 d-flex align-items-center d-lg-none\">
                    <svg xmlns=\"http://www.w3.org/2000/svg\" class=\"d-none d-lg-block\" width=\"40\" height=\"41\"
                        viewBox=\"0 0 40 41\" style=\"margin-right: 1.25rem;\" fill=\"none\">
                        <path
                            d=\"M39.25 20.4984C39.25 30.8948 30.6458 39.3484 20 39.3484C9.35416 39.3484 0.75 30.8948 0.75 20.4984C0.75 10.1021 9.35416 1.64844 20 1.64844C30.6458 1.64844 39.25 10.1021 39.25 20.4984Z\"
                            fill=\"white\" stroke=\"#223F85\" stroke-width=\"1.5\" />
                        <path d=\"M21.7727 15.2969L27.2 20.4969L21.7727 25.6969M18.7148 20.4969H27.048M12 20.4969H19\"
                            stroke=\"#003868\" stroke-width=\"1.5\" stroke-miterlimit=\"10\" stroke-linecap=\"round\"
                            stroke-linejoin=\"round\" />
                    </svg>
                    <svg width=\"16\" height=\"16\" class=\"d-block d-lg-none me-3\" viewBox=\"0 0 13 13\" fill=\"none\"
                        xmlns=\"http://www.w3.org/2000/svg\">
                        <path
                            d=\"M12.4856 6.31394C12.4856 9.57254 9.7878 12.2279 6.4428 12.2279C3.0978 12.2279 0.4 9.57254 0.4 6.31394C0.4 3.05534 3.0978 0.4 6.4428 0.4C9.7878 0.4 12.4856 3.05534 12.4856 6.31394Z\"
                            fill=\"white\" stroke=\"#223F85\" stroke-width=\"0.8\" />
                        <path
                            d=\"M7.01537 4.64062L8.76371 6.31575L7.01537 7.99088M6.0303 6.31575H8.71475M3.86719 6.31575H6.12217\"
                            stroke=\"#003868\" stroke-width=\"0.8\" stroke-miterlimit=\"10\" stroke-linecap=\"round\"
                            stroke-linejoin=\"round\" />
                    </svg>
                    احجز الآن</a>
            </div>
            <div class=\"col-lg-3 col-12 footer-list text-center\">
                <a href=\"https://bamc.myclinic.com.sa:8443\"
                    class=\"btn btn-light btn-footer-book-now mx-auto mb-5 d-flex align-items-center d-none d-lg-flex\">
                    <svg xmlns=\"http://www.w3.org/2000/svg\" class=\"d-none d-lg-block\" width=\"40\" height=\"41\"
                        viewBox=\"0 0 40 41\" style=\"margin-right: 1.25rem;\" fill=\"none\">
                        <path
                            d=\"M39.25 20.4984C39.25 30.8948 30.6458 39.3484 20 39.3484C9.35416 39.3484 0.75 30.8948 0.75 20.4984C0.75 10.1021 9.35416 1.64844 20 1.64844C30.6458 1.64844 39.25 10.1021 39.25 20.4984Z\"
                            fill=\"white\" stroke=\"#223F85\" stroke-width=\"1.5\" />
                        <path d=\"M21.7727 15.2969L27.2 20.4969L21.7727 25.6969M18.7148 20.4969H27.048M12 20.4969H19\"
                            stroke=\"#003868\" stroke-width=\"1.5\" stroke-miterlimit=\"10\" stroke-linecap=\"round\"
                            stroke-linejoin=\"round\" />
                    </svg>
                    <svg width=\"13\" height=\"13\" class=\"d-block d-lg-none me-3\" viewBox=\"0 0 13 13\" fill=\"none\"
                        xmlns=\"http://www.w3.org/2000/svg\">
                        <path
                            d=\"M12.4856 6.31394C12.4856 9.57254 9.7878 12.2279 6.4428 12.2279C3.0978 12.2279 0.4 9.57254 0.4 6.31394C0.4 3.05534 3.0978 0.4 6.4428 0.4C9.7878 0.4 12.4856 3.05534 12.4856 6.31394Z\"
                            fill=\"white\" stroke=\"#223F85\" stroke-width=\"0.8\" />
                        <path
                            d=\"M7.01537 4.64062L8.76371 6.31575L7.01537 7.99088M6.0303 6.31575H8.71475M3.86719 6.31575H6.12217\"
                            stroke=\"#003868\" stroke-width=\"0.8\" stroke-miterlimit=\"10\" stroke-linecap=\"round\"
                            stroke-linejoin=\"round\" />
                    </svg>
                    احجز الآن</a>
                <div class=\"row\">
                    <div class=\"col-lg-12 col-6\">
                        <a
                            href=\"https://apps.apple.com/us/app/my-clinic-ksa/id1475630623?ign-itscg=30200&ign-itsct=apps_box_badge\"><img
                                src=\"";
        // line 110
        yield $this->extensions['Cms\Twig\Extension']->themeFilter("assets/imgs/appstaore-footer.png");
        yield "\"
                                class=\"mb-3 d-block mx-auto img-fluid\" alt=\"appstore\"></a>
                    </div>
                    <div class=\"col-lg-12 col-6\">
                        <a
                            href=\"https://play.google.com/store/apps/details?id=com.myclinic.ksa&pcampaignid=pcampaignidMKT-Other-global-all-co-prtnr-py-PartBadge-Mar2515-1\"><img
                                src=\"";
        // line 116
        yield $this->extensions['Cms\Twig\Extension']->themeFilter("assets/imgs/play-store-footer.png");
        yield "\" class=\"img-fluid\" alt=\"playstore\"></a>
                    </div>
                </div>
                <div class=\"d-block d-lg-none timing-arabic-color\">
                    ";
        // line 120
        yield $this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, ($context["footerClinicTimings"] ?? null), "description_ar", [], "any", false, false, true, 120), 120, $this->source);
        yield "
                    <ul class=\"list-unstyled list-footer\">
                        ";
        // line 122
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["footerPhones"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 123
            yield "                        <a href=\"";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "link_value", [], "any", false, false, true, 123), 123, $this->source), "html", null, true);
            yield "\" style=\"text-decoration: none;\">
                        <li class=\"mb-2\"><img src=\"";
            // line 124
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "section_image", [], "any", false, false, true, 124), "path", [], "any", false, false, true, 124), 124, $this->source), "html", null, true);
            yield "\" class=\"img-fluid me-3\"
                                alt=\"back to top\">";
            // line 125
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "link_name_ar", [], "any", false, false, true, 125), 125, $this->source), "html", null, true);
            yield "</li></a>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['item'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 127
        yield "
                    </ul>
                    <!-- <ul class=\"list-unstyled list-footer\">
                        ";
        // line 130
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["footerUsefulLinks"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 131
            yield "                        <li><a href=\"";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "link_value_ar", [], "any", false, false, true, 131), 131, $this->source), "html", null, true);
            yield "\"
                                class=\"text-decoration-none text-white\">";
            // line 132
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->sandbox->ensureToStringAllowed(Cms\Twig\GetAttrNode::customGetAttribute($this->env, $this->source, $context["item"], "link_name", [], "any", false, false, true, 132), 132, $this->source), "html", null, true);
            yield "</a>
                        </li>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['item'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 135
        yield "
                    </ul> -->
                </div>
                <!-- <div class=\"col-12 text-end mt-5 d-none d-lg-block pe-5\">
                    <a href=\"javascript:void(0)\" class=\"text-decoration-none\">
                        <p class=\"text-white\">سياسة خصوصية المريض</p>
                    </a>
                </div> -->

            </div>
            <!-- <hr class=\"bg-white mx-auto my-3\"> -->
        </div>
    </div>
</footer>
<!-- End Footer -->";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "C:\\xampp\\htdocs\\myclinic\\themes/myclinic/partials/site/footer-ar.htm";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  291 => 135,  282 => 132,  277 => 131,  273 => 130,  268 => 127,  260 => 125,  256 => 124,  251 => 123,  247 => 122,  242 => 120,  235 => 116,  226 => 110,  172 => 58,  163 => 55,  158 => 54,  154 => 53,  143 => 44,  135 => 42,  131 => 41,  125 => 39,  121 => 38,  115 => 35,  111 => 33,  102 => 30,  97 => 29,  93 => 28,  81 => 18,  70 => 16,  66 => 15,  61 => 13,  54 => 9,  44 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "C:\\xampp\\htdocs\\myclinic\\themes/myclinic/partials/site/footer-ar.htm", "");
    }
    
    public function checkSecurity()
    {
        static $tags = ["for" => 15];
        static $filters = ["escape" => 9, "raw" => 13, "theme" => 110];
        static $functions = [];

        try {
            $this->sandbox->checkSecurity(
                ['for'],
                ['escape', 'raw', 'theme'],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
