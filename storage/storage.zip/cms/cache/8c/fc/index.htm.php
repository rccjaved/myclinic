<?php 
use MyClinic\Setting\Models\Testimonial;use MyClinic\Setting\Models\Slider;use MyClinic\Setting\Models\CommonComponent;use MyClinic\Setting\Models\PageContent;use MyClinic\Setting\Models\Blog;class Cmsd77d5b5878a3947485021ecab0f339122406c06ef35694d7b5185c4e698aaa5dClass extends Cms\Classes\PageCode
{





public function onStart()
{
  $isMobile = Agent::isMobile();
  $this['isMobile']= $isMobile;

  $testimonials=Testimonial::where('category','home')->orderBy('name')->get();
  $this['testimonials'] = $testimonials;

  $sliders = Slider::where('type','home_page')->get();
  $this['sliders'] = $sliders;
  $this['telemedicine_common_section']=CommonComponent::where('slug','telemedicine')->first();
  $this['health_homecare_common_section']=CommonComponent::where('slug','health-homecare')->first();
  $this['findYourDoc']=CommonComponent::where('slug','find-your-doctor')->first();
  $this['planText']=PageContent::where('page','home')->where('section','home-plans')->first();
  $this['blogs'] = Blog::limit(3)->get();
  $this['homeNewsAnnouncement']=PageContent::where('page','home')->where('section','home-news-announcement')->first();
  $fromMobile = Agent::isDesktop();
  $this['fromMobile']= $fromMobile;

}
}
