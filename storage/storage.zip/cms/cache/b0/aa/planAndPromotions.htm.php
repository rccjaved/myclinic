<?php 
class Cmsd0fa3c576b973d6e9a1ad70875ef9a524c360e7dc360f92db8367d1d8f2caf1fClass extends Cms\Classes\PartialCode
{

}
