<?php 
use MyClinic\Setting\Models\Testimonial;use MyClinic\Setting\Models\Slider;use MyClinic\Setting\Models\PageContent;class Cms4abd729491e57d77287bd3be9fb86a6fa995e435a680a70fca88adea6c530ec3Class extends Cms\Classes\PageCode
{



public function onStart()
{
$testimonials=Testimonial::where('category','home')->orderBy('name')->get();
$this['testimonials'] = $testimonials;

$sliders = Slider::where('type','find_doctor')->get();
$this['sliders'] = $sliders;
$this['ourDoctor']=PageContent::where('page','find-doctor')->where('section','find-doctor-our-doctors')->first();
$fromMobile = Agent::isMobile();
$this['fromMobile']= $fromMobile;

}
}
