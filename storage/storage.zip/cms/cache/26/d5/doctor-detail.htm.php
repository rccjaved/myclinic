<?php 
use MyClinic\Doctor\Models\Specialty;use MyClinic\Doctor\Models\Doctor;use MyClinic\Setting\Models\Location;use MyClinic\Doctor\Models\HealthConcern;use MyClinic\Setting\Models\Testimonial;use Illuminate\Support\Facades\Crypt;use Illuminate\Support\Facades\Http;use Illuminate\Support\Str;use MyClinic\Doctor\Helpers\Encryptionhelper;use Illuminate\Support\Facades\Log;use Illuminate\Support\Facades\Cache;class Cms105410f09c8339cf994c05cbb4aa6c5cfd165094ea387edc744df2f57815b602Class extends Cms\Classes\PageCode
{











public function onStart()
{
    $id = $this->param('id'); 
    $doctor = Doctor::find($id);

    if (!$doctor) {
        return;
    }

    // Set doctor details
    $doctor_app_id = $doctor->doctor_app_id;
    $locations = $doctor->locations;
    $doctor_locations = '';
    $locationIDs = [];

    foreach ($locations as $item) {
        $doctor_locations .= ' ' . $item->name_ar . '<br>';
        $locationIDs[] = $item->id;
    }
    $doctor_locations = rtrim($doctor_locations, '<br>');
    $this['doctor_locations'] = $doctor_locations;

    $language = $doctor->languages;
    $doctor_language = '';
    foreach ($language as $item) {
        $doctor_language .= ' ' . $item->name_ar . ',';
    }
    $doctor_language = rtrim($doctor_language, ',');
    $this['doctor_language'] = $doctor_language;

    $this['doctor'] = $doctor;

    // Handle specialties and determine button visibility
    $specialties = $doctor->specialties;
    $isBookNow = true;
    $isButtonVisible = true;

    $this['specialties'] = $specialties;
    $specialty_ids = [];
    foreach ($specialties as $item) {
        if (in_array($item->slug, ['Dental', 'er', 'physiotherapy'])) {
            $isBookNow = false;
        }
        if ($item->slug == 'er') {
            $isButtonVisible = false;
        }
        $specialty_ids[] = $item->id;
    }

    // Fetch similar doctors
    $doctor_ids = DB::table('myclinic_doctor_doctor_specialty')
                    ->whereIn('specialty_id', $specialty_ids)
                    ->pluck('doctor_id')->toArray();
    $locationDoctors = DB::table('myclinic_doctor_doctor_location')
                         ->whereIn('location_id', $locationIDs)
                         ->pluck('doctor_id')->toArray();
    $mergedDoctors = array_intersect($doctor_ids, $locationDoctors);

    $similarDoctors = Doctor::whereIn('id', $mergedDoctors)
                            ->whereNotIn('id', [$doctor->id])
                            ->orderBy('name')
                            ->get();

    $this['similar_doctor'] = $similarDoctors;

    $testimonials = Testimonial::where('category', 'home')->get();
    $this['testimonials'] = $testimonials;
    $this['isBookNow'] = $isBookNow;
    $this['isButtonVisible'] = $isButtonVisible;

    // Fetch availability only for the main doctor
    list($isAvailable, $availableDates, $bookingLinks) = $this->fetchDoctorAvailability($doctor_app_id);
    $this['availableDates'] = $availableDates;
    $this['bookingLinks'] = $bookingLinks;
    $this['isBookNow'] = $isBookNow && $isAvailable;
}

private function fetchDoctorAvailability($doctor_app_id)
{
    $cacheKey = 'doctor_availability_' . $doctor_app_id;
    $cacheDuration = 60; // 1 minute cache
    
    if (Cache::has($cacheKey)) {
        return Cache::get($cacheKey);
    }

    $companyMapping = [
        'nc01' => 'جدة المحمدية',
        'safa' => 'جدة الصفا',
        'prc' => 'جدة الخالدية مركز طب الأسنان',
        'ryd1' => 'الرياض الصحافة',
    ];

    $response = Http::post('https://bamc.myclinic.com.sa/OS.WebAPI.External/api/OSExternal/ApptGetEarlistSlots', [
        "SecurityToken" => "e236d058-fa14-44e1-aa07-5415d8f062c2",
        "DoctorId" => $doctor_app_id,
        "IsTelemedicine" => false,
        "PreferredTime" => "0",
        "IsFollowUp" => false
    ]);

    $isAvailable = false;
    $availableDates = [];
    $bookingLinks = [];

    if ($response->successful()) {
        $earliestSlots = $response->json();

        if (!empty($earliestSlots['ApptGetEarlistSlotBySpecialityResponse'])) {
            $isAvailable = true;

            foreach ($earliestSlots['ApptGetEarlistSlotBySpecialityResponse'] as $doctorData) {
                $specialtyId = (int)$doctorData['SpecialtyId'];
                $slotDate = $doctorData['SlotDate'] ? new DateTime($doctorData['SlotDate']) : null;
                $slotTime = $doctorData['SlotTime'] ? new DateTime($doctorData['SlotTime']) : null;
                $companyId = (string)$doctorData['Company'];
                $companyName = $companyMapping[$companyId] ?? $companyId; 
                $doctorAppId = (int)$doctorData['DoctorId'];

                if ($slotDate && $slotTime) {
                    $dataToEncrypt = [
                        'speciality_id' => $specialtyId,
                        'doctor_id' => $doctorAppId,
                        'location' => $companyId,
                        'date' => $slotDate->format('Y-m-d'),
                    ];

                    $strJson = json_encode($dataToEncrypt);
                    $encryptedQueries = encryptData($strJson);

                    $weekDates = $doctorData['WeekDates'] ?? [];
                    $latestDate = $slotDate;
                    $slotsAvailable = count($weekDates);

                    $availableDates[$doctorAppId] = [
                        'doctor_id' => $doctorAppId,
                        'doctor_name' => $doctorData['DoctorName'],
                        'latest_date' => $latestDate,
                        'slots_available' => $slotsAvailable,
                        'latest_time' => $slotTime->format('H:i:s'),
                        'company_name' => $companyName
                    ];

                    $bookingLinks[$doctorAppId] = 'https://bamc.myclinic.com.sa:8443/search-results?p=' . $encryptedQueries;
                }
            }
        }
    }

    $result = [$isAvailable, $availableDates, $bookingLinks];
    Cache::put($cacheKey, $result, $cacheDuration);
    
    return $result;
}

public function onSimilarDoctorsAvailability()
{
    $doctorId = input('doctor_id');
    
    $cacheKey = 'doctor_avail_ar_' . $doctorId;
    if (Cache::has($cacheKey)) {
        return Cache::get($cacheKey);
    }

    $doctor = Doctor::find($doctorId);
    if (!$doctor) {
        return [];
    }
    
    $response = Http::post('https://bamc.myclinic.com.sa/OS.WebAPI.External/api/OSExternal/ApptGetEarlistSlots', [
        "SecurityToken" => "e236d058-fa14-44e1-aa07-5415d8f062c2",
        "DoctorId" => $doctor->doctor_app_id,
        "IsTelemedicine" => false,
        "PreferredTime" => "0",
        "IsFollowUp" => false
    ]);

    $result = ['availableDates' => null, 'bookingLink' => null];

    if ($response->successful()) {
        $data = $response->json();
        if (!empty($data['ApptGetEarlistSlotBySpecialityResponse'])) {
            $firstSlot = $data['ApptGetEarlistSlotBySpecialityResponse'][0];
            
            if ($firstSlot['SlotDate'] && $firstSlot['SlotTime']) {
                $result = [
                    'availableDates' => [
                        'latest_date' => new DateTime($firstSlot['SlotDate']),
                        'latest_time' => $firstSlot['SlotTime'],
                        'company_name' => $this->getArabicCompanyName($firstSlot['Company'])
                    ],
                    'bookingLink' => $this->generateBookingLink($firstSlot)
                ];
            }
        }
    }

    Cache::put($cacheKey, $result, 60);
    return $result;
}

private function getArabicCompanyName($companyId)
{
    $companyMapping = [
        'nc01' => 'جدة المحمدية',
        'safa' => 'جدة الصفا',
        'prc' => 'جدة الخالدية مركز طب الأسنان',
        'ryd1' => 'الرياض الصحافة',
    ];
    
    return $companyMapping[$companyId] ?? $companyId;
}

private function generateBookingLink($slotData)
{
    $dataToEncrypt = [
        'speciality_id' => (int)$slotData['SpecialtyId'],
        'doctor_id' => (int)$slotData['DoctorId'],
        'location' => (string)$slotData['Company'],
        'date' => (new DateTime($slotData['SlotDate']))->format('Y-m-d'),
    ];
    
    return 'https://bamc.myclinic.com.sa:8443/search-results?p=' . encryptData(json_encode($dataToEncrypt));
}
}
