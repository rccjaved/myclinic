<?php 
use MyClinic\Setting\Models\Location;class Cmsa7acc984cc32379abd1ee10cd325351c4b050040d8afc9b7db1efc7413aac31cClass extends Cms\Classes\PartialCode
{

public function onStart()
{

    $alMohammadiyah = Location::find(1);
    $this['specialties']=$alMohammadiyah->specialties()->where('show_home_page',1)->orderBy('name')->get();
    $this['locations']=Location::orderBy('id')->get(); 
    if (request()->has('latitude') && request()->has('longitude')) {
        $latitude = request('latitude');
        $longitude = request('longitude');

        $nearestLocation = Location::selectRaw('id, ( 3959 * acos( cos( radians(?) ) * cos( radians( latitude ) ) * cos( radians( longitude ) - radians(?) ) + sin( radians(?) ) * sin( radians( latitude ) ) ) ) AS distance', [$latitude, $longitude, $latitude])
            ->orderBy('distance')
            ->first();


        $this['nearestLocation'] = $nearestLocation;
    }

}
}
