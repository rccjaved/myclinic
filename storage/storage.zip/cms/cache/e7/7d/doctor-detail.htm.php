<?php 
use MyClinic\Doctor\Models\Specialty;use MyClinic\Doctor\Models\Doctor;use MyClinic\Setting\Models\Location;use MyClinic\Doctor\Models\HealthConcern;use MyClinic\Setting\Models\Testimonial;use Illuminate\Support\Facades\Crypt;use Illuminate\Support\Facades\Http;use Illuminate\Support\Str;use MyClinic\Doctor\Helpers\Encryptionhelper;use Illuminate\Support\Facades\Log;use Illuminate\Support\Facades\DB;class Cms097e215b9e5c2837049cad43d928346a99460a8981f7eb581d1753a1693b9ac0Class extends Cms\Classes\PageCode
{











public function onStart()
{
    $id = $this->param('id'); 
    $doctor = Doctor::find($id);

    if (!$doctor) {
        return;
    }

    // Set doctor details
    $doctor_app_id = $doctor->doctor_app_id;
    $locations = $doctor->locations;
    $doctor_locations = '';
    $locationIDs = [];

    foreach ($locations as $item) {
        $doctor_locations .= ' ' . $item->name . '<br>';
        $locationIDs[] = $item->id;
    }
    $doctor_locations = rtrim($doctor_locations, '<br>');
    $this['doctor_locations'] = $doctor_locations;

    $language = $doctor->languages;
    $doctor_language = '';
    foreach ($language as $item) {
        $doctor_language .= ' ' . $item->name . ',';
    }
    $doctor_language = rtrim($doctor_language, ',');
    $this['doctor_language'] = $doctor_language;

    $this['doctor'] = $doctor;

    // Handle specialties and determine button visibility
    $specialties = $doctor->specialties;
    $isBookNow = true;
    $isButtonVisible = true;

    $this['specialties'] = $specialties;
    $specialty_ids = [];
    foreach($specialties as $item){
        if($item->slug=='Dental' || $item->slug=='er' || $item->slug=='physiotherapy'){
            $isBookNow=false;
        }
        if($item->slug=='er'){
            $isButtonVisible=false;
        }
        $specialty_ids[]=$item->id;
    }

    // Fetch similar doctors
    $doctor_ids = DB::table('myclinic_doctor_doctor_specialty')
                    ->whereIn('specialty_id', $specialty_ids)
                    ->pluck('doctor_id')->toArray();
    $locationDoctors = DB::table('myclinic_doctor_doctor_location')
                         ->whereIn('location_id', $locationIDs)
                         ->pluck('doctor_id')->toArray();
    $mergedDoctors = array_intersect($doctor_ids, $locationDoctors);

    $similarDoctors = Doctor::whereIn('id', $mergedDoctors)
                            ->whereNotIn('id', [$doctor->id])
                            ->orderBy('name')
                            ->get();

    $this['similar_doctor'] = $similarDoctors;

    $testimonials = Testimonial::where('category', 'home')->get();
    $this['testimonials'] = $testimonials;
    $this['isBookNow'] = $isBookNow;
    $this['isButtonVisible'] = $isButtonVisible;

    // Fetch availability only for the main doctor (not for similar doctors)
    list($isAvailable, $availableDates, $bookingLinks) = $this->fetchDoctorAvailability($doctor_app_id);
    $this['availableDates'] = $availableDates;
    $this['bookingLinks'] = $bookingLinks;
    $this['isBookNow'] = $isBookNow && $isAvailable;
}

private function fetchDoctorAvailability($doctor_app_id)
{
    $cacheKey = 'doctor_availability_' . $doctor_app_id;
    $cacheDuration = 60; // 1 minute cache
    
    if (Cache::has($cacheKey)) {
        return Cache::get($cacheKey);
    }

    $companyMapping = [
        'nc01' => 'Jeddah Al Mohammadiyah',
        'safa' => 'Jeddah Al Safa',
        'prc' => 'Jeddah Al Khalidiyyah Dental Center',
        'ryd1' => 'Riyadh Al Sahafa',
    ];

    $response = Http::post('https://bamc.myclinic.com.sa/OS.WebAPI.External/api/OSExternal/ApptGetEarlistSlots', [
        "SecurityToken" => "e236d058-fa14-44e1-aa07-5415d8f062c2",
        "DoctorId" => $doctor_app_id,
        "IsTelemedicine" => false,
        "PreferredTime" => "0",
        "IsFollowUp" => false
    ]);

    $isAvailable = false;
    $availableDates = [];
    $bookingLinks = [];

    if ($response->successful()) {
        $earliestSlots = $response->json();

        if (!empty($earliestSlots['ApptGetEarlistSlotBySpecialityResponse'])) {
            $isAvailable = true;

            foreach ($earliestSlots['ApptGetEarlistSlotBySpecialityResponse'] as $doctorData) {
                $specialtyId = (int)$doctorData['SpecialtyId'];
                $slotDate = $doctorData['SlotDate'] ? new DateTime($doctorData['SlotDate']) : null;
                $slotTime = $doctorData['SlotTime'] ? new DateTime($doctorData['SlotTime']) : null;
                $companyId = (string)$doctorData['Company'];
                $companyName = $companyMapping[$companyId] ?? $companyId; 
                $doctorAppId = (int)$doctorData['DoctorId'];

                if ($slotDate && $slotTime) {
                    $dataToEncrypt = [
                        'speciality_id' => $specialtyId,
                        'doctor_id' => $doctorAppId,
                        'location' => $companyId,
                        'date' => $slotDate->format('Y-m-d'),
                    ];

                    $strJson = json_encode($dataToEncrypt);
                    $encryptedQueries = encryptData($strJson);

                    $weekDates = $doctorData['WeekDates'] ?? [];
                    $latestDate = $slotDate;
                    $slotsAvailable = count($weekDates);

                    $availableDates[$doctorAppId] = [
                        'doctor_id' => $doctorAppId,
                        'doctor_name' => $doctorData['DoctorName'],
                        'latest_date' => $latestDate,
                        'slots_available' => $slotsAvailable,
                        'latest_time' => $slotTime->format('H:i:s'),
                        'company_name' => $companyName
                    ];

                    $bookingLinks[$doctorAppId] = 'https://bamc.myclinic.com.sa:8443/search-results?p=' . $encryptedQueries;
                }
            }
        }
    }

    $result = [$isAvailable, $availableDates, $bookingLinks];
    Cache::put($cacheKey, $result, $cacheDuration);
    
    return $result;
}

public function onSimilarDoctorsAvailability()
{
    $doctorId = input('doctor_id');

    $cacheKey = 'doctor_avail_ar_' . $doctorId;
    if (Cache::has($cacheKey)) {
        return Cache::get($cacheKey);
    }

    $doctor = Doctor::find($doctorId);
    
    if (!$doctor) {
        return [];
    }
    
    $doctor_app_id = $doctor->doctor_app_id;
    list($isAvailable, $availableDates, $bookingLinks) = $this->fetchDoctorAvailability($doctor_app_id);
    
    return [
        'availableDates' => $availableDates[$doctor_app_id] ?? null,
        'bookingLink' => $bookingLinks[$doctor_app_id] ?? null
    ];
}
}
