<?php 
use MyClinic\Doctor\Models\Specialty;use MyClinic\Setting\Models\Testimonial;use MyClinic\Setting\Models\Location;use MyClinic\Setting\Models\Slider;use MyClinic\Setting\Models\PageContent;class Cms9504b35b9dedd6e6e5b85cfdc58b5b82e2668b50aa230c2b427e940dffac7e25Class extends Cms\Classes\PageCode
{





public function onStart()
{
    $testimonials=Testimonial::where('category','specialty')->orderBy('name')->get();
    $this['testimonials'] = $testimonials;
    $sliders = Slider::where('type','our_specialty')->get();
    $this['sliders'] = $sliders;
    $this['overview']=PageContent::where('page','our-specialty')->where('section','our-specialty-overview')->first();
    $fromMobile = Agent::isMobile();
    $this['fromMobile']= $fromMobile;
  
}
}
