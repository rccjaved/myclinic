<?php 
use MyClinic\Setting\Models\Location;use MyClinic\Doctor\Models\Specialty;class Cmsa98d9e6e662c8f97d32495691bc8aeeadfebbeb96b3897e1fd6f52d0ca2ab319Class extends Cms\Classes\PartialCode
{


public function onStart()
{
$this['specialties']=Specialty::orderBy('name')->get();
$this['locations']=Location::orderBy('id')->get(); 
}
}
