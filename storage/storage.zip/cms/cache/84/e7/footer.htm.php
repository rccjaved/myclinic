<?php 
use MyClinic\Setting\Models\PageContent;class Cms09a93a735bc8ad70e0d2459d7d380ad5aea950c295f2bcc1abe5b5801e1f14d5Class extends Cms\Classes\PartialCode
{

public function onStart()
{
    $this['footerLogo']=PageContent::where('page','footer')->where('section','footer-logo')->first();
    $this['footerAbout']=PageContent::where('page','footer')->where('section','footer-about')->first();
    $this['footerSocialMediaLinks']=PageContent::where('page','footer')->where('section','footer-socialmedia-links')->get();
    $this['footerCompanyLinks']=PageContent::where('page','footer')->where('section','footer-company-links')->get();
    $this['footerUsefulLinks']=PageContent::where('page','footer')->where('section','footer-useful-links')->get();
    $this['footerActionButton']=PageContent::where('page','footer')->where('section','footer-action-button')->first();
    $this['footerAppDownload']=PageContent::where('page','footer')->where('section','footer-app-download')->get();
    $this['footerClinicTimings']=PageContent::where('page','footer')->where('section','footer-clinic-timings')->first();
    $this['footerPhones']=PageContent::where('page','footer')->where('section','footer-phones')->get();

}
}
