<?php 
use MyClinic\Doctor\Models\Specialty;use MyClinic\Setting\Models\Testimonial;use MyClinic\Setting\Models\Location;use MyClinic\Setting\Models\Slider;use MyClinic\Setting\Models\PageContent;class Cms6f02946903016080503f14e0909e14a3b3eb08fd6cfd48f7ded0f04356585a4bClass extends Cms\Classes\PageCode
{





public function onStart()
{
    $testimonials=Testimonial::where('category','specialty')->orderBy('name')->get();
    $this['testimonials'] = $testimonials;
    $sliders = Slider::where('type','our_specialty')->get();
    $this['sliders'] = $sliders;
    $this['overview']=PageContent::where('page','our-specialty')->where('section','our-specialty-overview')->first();
    $fromMobile = Agent::isMobile();
    $this['fromMobile']= $fromMobile;
}
}
