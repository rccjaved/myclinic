<?php 
class Cmse70890ffe1c0d9ac753cbea4ce74ec06aefdcf34368b6b71b5d87d4ae831d21fClass extends Cms\Classes\LayoutCode
{

}
