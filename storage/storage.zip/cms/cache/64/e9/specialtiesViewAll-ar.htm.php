<?php 
use MyClinic\Setting\Models\Location;use MyClinic\Doctor\Models\Specialty;class Cms2a5e29a994ebc13fe0d9cf4f0ce0532c2064a2e79cc301d3cbef03078681cb0fClass extends Cms\Classes\PartialCode
{


public function onStart()
{
$this['specialties']=Specialty::orderBy('name')->get();
$this['locations']=Location::orderBy('id')->get(); 
}
}
