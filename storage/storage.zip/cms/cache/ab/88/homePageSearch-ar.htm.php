<?php 
use MyClinic\Doctor\Models\Specialty;use MyClinic\Doctor\Models\Doctor;use MyClinic\Setting\Models\Location;class Cmsc7ad8ab57e83c7004491faad29be1f5d04fd772f1dbc5269d8a399e850aa486eClass extends Cms\Classes\PartialCode
{



public function onStart()
{
    $this['specialties']=Specialty::orderBy('name_ar')->get();
    $this['locations']=Location::orderBy('id')->get(); 
    $this['doctors']=Doctor::orderBy('name_ar')->get(); 
}
}
