<?php 
use MyClinic\Setting\Models\PageContent;class Cmsa9ca3bb6222a247bcc1e6ffa3cbbd3d80b42190ccf319ab0bf6ca904dcea9209Class extends Cms\Classes\PartialCode
{

public function onStart()
{
  $this['headerLogo']=PageContent::where('page','header')->where('section','header-logo')->first();
  $this['headerLinks']=PageContent::where('page','header')->where('section','header-links')->get();
  $this['headerActionButton']=PageContent::where('page','header')->where('section','header-action-button')->first();
  $this['headerPhones']=PageContent::where('page','header')->where('section','header-action-button')->where('title', 'phone')->first();

}
}
