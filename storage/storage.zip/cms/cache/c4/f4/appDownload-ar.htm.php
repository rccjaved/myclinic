<?php 
use MyClinic\Setting\Models\CommonComponent;class Cms2f4e93942b9a260c1f4e32b23ef67a4f5d305583bc5bfde870db55eb2a59577bClass extends Cms\Classes\PartialCode
{

public function onStart()
{
$this['commonComponent']=CommonComponent::where('slug','app-download')->first();
}
}
