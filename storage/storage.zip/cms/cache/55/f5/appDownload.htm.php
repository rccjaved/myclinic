<?php 
use MyClinic\Setting\Models\CommonComponent;class Cms30b5bf78544edd5552f0e901014eb9b190e1aa79726c67efbfdb4193c9bb2509Class extends Cms\Classes\PartialCode
{

public function onStart()
{
$this['commonComponent']=CommonComponent::where('slug','app-download')->first();
}
}
