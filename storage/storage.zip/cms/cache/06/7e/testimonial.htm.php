<?php 
use MyClinic\Setting\Models\SectionHeading;class Cmsa3d1694a72b6cf2f667811516680864b2a7d56d55bcc1e752f5bdc598ff13285Class extends Cms\Classes\PartialCode
{

public function onStart()
{
$this['sectionHeading']=SectionHeading::where('section','testimonial')->first();
}
}
