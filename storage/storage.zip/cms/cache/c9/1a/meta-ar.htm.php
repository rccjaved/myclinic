<?php 
class Cms15c18c07bd5692aa889509bdcf2e4eee9ad652f93ef352038881264112255271Class extends Cms\Classes\PartialCode
{

}
