<?php 
use MyClinic\Doctor\Models\Doctor;use MyClinic\Setting\Models\Location;use Illuminate\Support\Facades\Http;use Illuminate\Support\Str;use MyClinic\Doctor\Helpers\Encryptionhelper;class Cmsfd470a76ee3becfc674f751906224f0acea5439f2b843fc74ca5d83b128972bbClass extends Cms\Classes\PageCode
{





public function onStart()
{
    $location = Location::find($this->param('id'));
    $this['location'] = $location;

    // Fetch all doctors for the location
    $doctors = $location->doctors()->orderBy('name')->get();

    // Check if each doctor has the required specialties ('Dental' or 'Physiotherapy')
    foreach ($doctors as $doc) {
        $specialties = $doc->specialties()->whereIn('name', ['Dental', 'physiotherapy'])->count();
        $doc->isHaveAskUsSpecialty = $specialties ? true : false;
    }
    $this['doctors'] = $doctors;

    $doctorAppIds = $doctors->pluck('doctor_app_id', 'id')->toArray();

    // Mapping location IDs to company IDs
    $companyIdMap = [
            1 => 'nc01',
            2 => 'safa',
            3 => 'prc',
            4 => 'ryd1'
        ];

        $companyId = $companyIdMap[$location->id];
        $allApiData = [];
        $nextRecordsFrom = 1;
        $recordsPerPage = 5;

        do {
            $apiParams = [
                'SecurityToken' => 'e236d058-fa14-44e1-aa07-5415d8f062c2',
                'CompanyId' => $companyId,
                'NextRecordsFrom' => $nextRecordsFrom,
                'IsTelemedicine' => false,
                'PreferredTime' => '0',
                'IsFollowUp' => false
            ];

            $response = Http::post('https://bamc.myclinic.com.sa/OS.WebAPI.External/api/OSExternal/ApptGetEarlistSlots', $apiParams);

            if ($response->successful()) {
                $apiData = $response->json();
                if (isset($apiData['ApptGetEarlistSlotBySpecialityResponse'])) {
                    $doctorsData = $apiData['ApptGetEarlistSlotBySpecialityResponse'];
                    $allApiData = array_merge($allApiData, $doctorsData);

                    if (count($doctorsData) < $recordsPerPage) {
                        break;
                    }
                    $nextRecordsFrom += $recordsPerPage;
                } else {
                    Log::error('ApptGetEarlistSlotBySpecialityResponse key not found in API response.');
                    break;
                }
            } else {
                Log::error('API request failed: ' . $response->body());
                break;
            }

        } while (true);

        $availableDates = [];
        $bookingLinks = [];

        $branchNameMap = array_flip($companyIdMap);
        $branchNameMap = [
            1 => 'جدة المحمدية',
            2 => 'جدة الصفا',
            3 => 'جدة الخالدية مركز طب الأسنان',
            4 => 'الرياض الصحافة'
        ];

        foreach ($allApiData as $doctorData) {
            $doctorId = array_search($doctorData['DoctorId'], $doctorAppIds);

            if ($doctorId !== false) {
                $specialtyId = (int)$doctorData['SpecialtyId'];
                $slotDate = isset($doctorData['SlotDate']) ? new DateTime($doctorData['SlotDate']) : null;
                $slotTime = isset($doctorData['SlotTime']) ? new DateTime($doctorData['SlotTime']) : null;
                $companyId = (string)$doctorData['Company'];
                $doctorAppId = (int)$doctorData['DoctorId'];

                // Check if slot date and time are null; if so, set them explicitly to null
                $latestDate = isset($doctorData['WeekDates'][0]['Date']) ? $doctorData['WeekDates'][0]['Date'] : null;
                $slotsAvailable = isset($doctorData['WeekDates']) ? count($doctorData['WeekDates']) : 0;

                // Convert API location code to branch name
                $branchName = isset($branchNameMap[array_search($companyId, $companyIdMap)]) 
                    ? $branchNameMap[array_search($companyId, $companyIdMap)] 
                    : 'Unknown';

                // Store data only if `latestDate` and `slotTime` are available; otherwise, set them to null
                $availableDates[$doctorId] = [
                    'doctor_id' => $doctorAppId,
                    'doctor_name' => $doctorData['DoctorName'],
                    'latest_date' => $latestDate,
                    'slots_available' => $slotsAvailable,
                    'latest_time' => $slotTime ? $slotTime->format('H:i:s') : null,
                    'company_name' => $branchName
                ];

                // Generate booking link only if `latestDate` is not null
                if ($latestDate) {
                    $dataToEncrypt = [
                        'speciality_id' => $specialtyId, 
                        'doctor_id' => $doctorAppId,
                        'location' => $companyId,
                        'date' => $slotDate ? $slotDate->format('Y-m-d') : null,
                    ];

                    $strJson = json_encode($dataToEncrypt);
                    $encryptedQueries = encryptData($strJson);
                    $bookingLinks[$doctorId] = 'https://bamc.myclinic.com.sa:8443/search-results?p=' . $encryptedQueries;
                } else {
                    $bookingLinks[$doctorId] = null;
                }
            }
        }

       
    // Assign results to view variables
    $this['availableDates'] = $availableDates;
    $this['bookingLinks'] = $bookingLinks;
    $this['specialties'] = $location->specialties->sortBy('name');
    $this['locations'] = Location::all();
}
}
