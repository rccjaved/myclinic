<?php 
class Cmsa700db84d2abcb57f680570b1e81daa4b1dd844df1b88647ed6aea6341ce67fbClass extends Cms\Classes\PartialCode
{

}
