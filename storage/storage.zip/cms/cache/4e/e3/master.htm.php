<?php 
class Cms628ab62637f22ed2d40089ec1081aabacc344e5b4542c24c292eda9f773c4ae0Class extends Cms\Classes\LayoutCode
{

}
