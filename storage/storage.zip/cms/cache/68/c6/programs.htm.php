<?php 
class Cms4bb82ad93cb3257ba1307c1ecedd4be4abdda26a792fbf31245e78df9deea6c4Class extends Cms\Classes\PartialCode
{

}
