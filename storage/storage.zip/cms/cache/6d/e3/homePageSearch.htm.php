<?php 
use MyClinic\Doctor\Models\Specialty;use MyClinic\Doctor\Models\Doctor;use MyClinic\Setting\Models\Location;class Cms3988691db875b2a3d1673c4467d60a4433b67c9553f392bb3cad94d98df3f630Class extends Cms\Classes\PartialCode
{



public function onStart()
{
    $this['specialties']=Specialty::orderBy('name')->get();
    $this['locations']=Location::orderBy('id')->get(); 
    $this['doctors']=Doctor::orderBy('name')->get(); 
}
}
