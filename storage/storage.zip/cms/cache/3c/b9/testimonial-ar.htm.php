<?php 
use MyClinic\Setting\Models\SectionHeading;class Cmsf9b5b115e8325b7f9f25cb2e6302aa41b67418b6354c81181dea36832582d12cClass extends Cms\Classes\PartialCode
{

public function onStart()
{
$this['sectionHeading']=SectionHeading::where('section','testimonial')->first();
}
}
