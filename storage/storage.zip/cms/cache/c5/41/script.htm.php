<?php 
class Cmsd50debf0120e5e81cbe68e36b1574651b19b9488bd2c0a282bfd87229e704c0aClass extends Cms\Classes\PartialCode
{

}
