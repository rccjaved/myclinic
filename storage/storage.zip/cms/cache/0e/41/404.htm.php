<?php 
class Cms629f919e0c3d5ac0f8baea4a181ceea036589342a57209b3694bcc0777750be0Class extends Cms\Classes\PageCode
{

}
