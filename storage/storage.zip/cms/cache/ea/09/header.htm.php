<?php 
use MyClinic\Setting\Models\PageContent;class Cmsbc0a2e5c6d0b82fa0a4f8147c7f4e8d6f82142595f71fd82a71e4c7a1e3b7e37Class extends Cms\Classes\PartialCode
{

public function onStart()
{
  $this['headerLogo']=PageContent::where('page','header')->where('section','header-logo')->first();
  $this['headerLinks']=PageContent::where('page','header')->where('section','header-links')->get();
  $this['headerActionButton']=PageContent::where('page','header')->where('section','header-action-button')->first();
  $this['headerPhones']=PageContent::where('page','header')->where('section','header-action-button')->where('title', 'phone')->first();

}
}
