<?php 
use MyClinic\Doctor\Models\Specialty;use MyClinic\Doctor\Models\Doctor;use MyClinic\Setting\Models\Location;use MyClinic\Doctor\Models\HealthConcern;use MyClinic\Setting\Models\Slider;use MyClinic\Doctor\Models\SpecialtySlider;use MyClinic\Doctor\Models\HodDoctor;use Illuminate\Support\Facades\Http;use Illuminate\Support\Str;use MyClinic\Doctor\Helpers\Encryptionhelper;class Cms571cdea1bc24337ef792228e8ab2dee4cbf6d759797bcab5f7673aae49179196Class extends Cms\Classes\PageCode
{










public function onStart()
{
    
    $location = Location::find($this->param('id'));
    $this['location'] = $location;
    $this['specialties'] = $location->specialties()->orderBy('name')->get();
    $slug = $this->param('slug');
    $this['slug'] = $slug;

    $isMobile = in_array($slug, ['physiotherapy', 'Dental']);
    $this['isMobile'] = $isMobile;

    $specialty = Specialty::where('slug', $slug)->first();
    $this['specialty'] = $specialty;
    $specialityId = $specialty->app_speciality_id;

    $locationDoctors = $location->doctors()->pluck('doctor_id')->toArray();
    $specialtyDoctors = $specialty->doctors()->pluck('doctor_id')->toArray();
    $mergedDoctors = array_intersect($locationDoctors, $specialtyDoctors);
    $doctors = Doctor::whereIn('id', $mergedDoctors)->orderBy('name')->get();
    $doctorAppIds = $doctors->pluck('doctor_app_id', 'id')->toArray();

    $sliders = SpecialtySlider::where('specialty_id',$specialty->id)->get();
    $this['sliders'] = $sliders;

    // Skip API call if not required for specific slugs
    if (!$isMobile) {
        $companyIdMap = [
            1 => 'nc01',
            2 => 'safa',
            3 => 'prc',
            4 => 'ryd1'
        ];

        $companyId = $companyIdMap[$location->id];
        $allApiData = [];
        $nextRecordsFrom = 1;
        $recordsPerPage = 5;

        do {
            $apiParams = [
                'SecurityToken' => 'e236d058-fa14-44e1-aa07-5415d8f062c2',
                'CompanyId' => $companyId,
                'SpecialityId' => $specialityId,
                'NextRecordsFrom' => $nextRecordsFrom,
                'IsTelemedicine' => false,
                'PreferredTime' => '0',
                'IsFollowUp' => false
            ];

            $response = Http::post('https://bamc.myclinic.com.sa/OS.WebAPI.External/api/OSExternal/ApptGetEarlistSlots', $apiParams);

            if ($response->successful()) {
                $apiData = $response->json();
                if (isset($apiData['ApptGetEarlistSlotBySpecialityResponse'])) {
                    $doctorsData = $apiData['ApptGetEarlistSlotBySpecialityResponse'];
                    $allApiData = array_merge($allApiData, $doctorsData);

                    if (count($doctorsData) < $recordsPerPage) {
                        break;
                    }
                    $nextRecordsFrom += $recordsPerPage;
                } else {
                    Log::error('ApptGetEarlistSlotBySpecialityResponse key not found in API response.');
                    break;
                }
            } else {
                Log::error('API request failed: ' . $response->body());
                break;
            }

        } while (true);

        $availableDates = [];
        $bookingLinks = [];

        $branchNameMap = array_flip($companyIdMap);
        $branchNameMap = [
            1 => 'جدة المحمدية',
            2 => 'جدة الصفا',
            3 => 'جدة الخالدية مركز طب الأسنان',
            4 => 'الرياض الصحافة'
        ];

        foreach ($allApiData as $doctorData) {
            $doctorId = array_search($doctorData['DoctorId'], $doctorAppIds);

            if ($doctorId !== false) {
                $specialtyId = (int)$doctorData['SpecialtyId'];
                $slotDate = isset($doctorData['SlotDate']) ? new DateTime($doctorData['SlotDate']) : null;
                $slotTime = isset($doctorData['SlotTime']) ? new DateTime($doctorData['SlotTime']) : null;
                $companyId = (string)$doctorData['Company'];
                $doctorAppId = (int)$doctorData['DoctorId'];

                // Check if slot date and time are null; if so, set them explicitly to null
                $latestDate = isset($doctorData['WeekDates'][0]['Date']) ? $doctorData['WeekDates'][0]['Date'] : null;
                $slotsAvailable = isset($doctorData['WeekDates']) ? count($doctorData['WeekDates']) : 0;

                // Convert API location code to branch name
                $branchName = isset($branchNameMap[array_search($companyId, $companyIdMap)]) 
                    ? $branchNameMap[array_search($companyId, $companyIdMap)] 
                    : 'Unknown';

                // Store data only if `latestDate` and `slotTime` are available; otherwise, set them to null
                $availableDates[$doctorId] = [
                    'doctor_id' => $doctorAppId,
                    'doctor_name' => $doctorData['DoctorName'],
                    'latest_date' => $latestDate,
                    'slots_available' => $slotsAvailable,
                    'latest_time' => $slotTime ? $slotTime->format('H:i:s') : null,
                    'company_name' => $branchName
                ];

                // Generate booking link only if `latestDate` is not null
                if ($latestDate) {
                    $dataToEncrypt = [
                        'speciality_id' => $specialtyId, 
                        'doctor_id' => $doctorAppId,
                        'location' => $companyId,
                        'date' => $slotDate ? $slotDate->format('Y-m-d') : null,
                    ];

                    $strJson = json_encode($dataToEncrypt);
                    $encryptedQueries = encryptData($strJson);
                    $bookingLinks[$doctorId] = 'https://bamc.myclinic.com.sa:8443/search-results?p=' . $encryptedQueries;
                } else {
                    $bookingLinks[$doctorId] = null;
                }
            }
        }

        $this['availableDates'] = $availableDates;
        $this['bookingLinks'] = $bookingLinks;

    } else {
        $this['availableDates'] = [];
        $this['bookingLinks'] = [];
    }

    $this['locations'] = Location::all();
    $hodExist = HodDoctor::where('location_id', $location->id)
        ->where('specialty_id', $specialty->id)
        ->whereIn('doctor_id', $mergedDoctors)
        ->first();

    $hod = $hodExist ? Doctor::find($hodExist->doctor_id) : null;

    if ($hod) {
        $this['hod'] = $hod;
        $this['doctors'] = $specialty->doctors()
            ->where('doctor_id', '!=', $hod->id)
            ->whereIn('doctor_id', $mergedDoctors)
            ->orderBy('name')
            ->get();
    } else {
        $this['doctors'] = $specialty->doctors()
            ->whereIn('doctor_id', $mergedDoctors)
            ->orderBy('name')
            ->get();
    }

    $this['optionDoctorList'] = $specialty->doctors()
        ->whereIn('doctor_id', $mergedDoctors)
        ->orderBy('name')
        ->get();

    $this['healthConcerns'] = HealthConcern::all();
    $this['canBook'] = ($slug !== 'er');
}
}
